<?php
/**
 * Pied de page : grille sur ordinateur, accordéons sur mobile, barre d'actions mobile.
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

$tel     = hs_opt( 'telephone' );
$tel_i   = hs_opt( 'telephone_intl' );
$email   = hs_opt( 'email' );
$rue     = hs_opt( 'rue' );
$ville   = trim( hs_opt( 'code_postal' ) . ' ' . hs_opt( 'ville' ) );
$contact = hs_url( 'Contact' );
$annee   = wp_date( 'Y' );
$badge   = hs_asset( 'img/logo-holo-surf-badge.webp' );
$cols    = array(
	array( 'Les cours', 'pied-cours' ),
	array( 'Infos surf', 'pied-infos' ),
	array( 'Les spots', 'pied-spots' ),
);
$legal   = hs_links( 'pied-legal' );

$socials = array();
if ( hs_opt( 'instagram' ) ) {
	$socials[] = array( hs_opt( 'instagram' ), 'Instagram', '<rect x="3" y="3" width="18" height="18" rx="5"></rect><circle cx="12" cy="12" r="4"></circle><circle cx="17.5" cy="6.5" r="0.8" fill="currentColor"></circle>' );
}
if ( hs_opt( 'facebook' ) ) {
	$socials[] = array( hs_opt( 'facebook' ), 'Facebook', '<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z"></path>' );
}
if ( hs_opt( 'whatsapp' ) ) {
	$socials[] = array( 'https://wa.me/' . preg_replace( '/\D/', '', hs_opt( 'whatsapp' ) ), 'WhatsApp', '<path d="M4 20l1.3-4A8 8 0 1 1 8 18.7z"></path>' );
}
$soc_html = '';
foreach ( $socials as $s ) {
	$soc_html .= '<a href="' . esc_url( $s[0] ) . '" class="soc" aria-label="' . esc_attr( $s[1] ) . '"><svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $s[2] . '</svg></a>' . "\n";
}
?>
<footer class="ft">
<div class="wrap ftd" style="padding-top: clamp(44px, 8vw, 72px); padding-bottom: 28px">
<div class="ftg" style="display: flex; flex-wrap: wrap; gap: 40px; justify-content: space-between">
<div style="flex: 1 1 260px; max-width: 300px">
<img width="208" height="208" loading="lazy" decoding="async" src="<?php echo esc_url( $badge ); ?>" alt="Holo Surf Capbreton" style="width: 104px; height: 104px; display: block; filter: invert(1)">
<p style="margin: 18px 0 0; line-height: 1.65">École de surf à Capbreton, labellisée Ecosafe Surfing. Cours collectifs, cours particuliers et coaching vidéo, dès 5 ans.</p>
<div style="display: flex; gap: 10px; margin-top: 20px">
<?php echo $soc_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>
</div>
<?php foreach ( $cols as $c ) : ?>
<nav aria-label="<?php echo esc_attr( $c[0] ); ?>" style="flex: 0 1 150px"><p class="fth"><?php echo esc_html( $c[0] ); ?></p><ul class="ftl"><?php foreach ( hs_links( $c[1] ) as $l ) : ?><li><a href="<?php echo esc_url( $l[1] ); ?>"><?php echo esc_html( $l[0] ); ?></a></li><?php endforeach; ?></ul></nav>
<?php endforeach; ?>
<div style="flex: 0 1 240px"><p class="fth">Contact</p><p style="margin: 0; line-height: 1.75"><?php echo esc_html( $rue ); ?><br><?php echo esc_html( $ville ); ?><br><a href="tel:<?php echo esc_attr( $tel_i ); ?>"><?php echo esc_html( $tel ); ?></a><br><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p></div>
</div>
<div style="margin-top: 56px; padding-top: 22px; border-top: 1px solid #2C4250; display: flex; flex-wrap: wrap; gap: 12px 24px; justify-content: space-between; font-size: 14px">
<span>© <?php echo esc_html( $annee ); ?> Holo Surf Capbreton</span>
<span style="display: flex; flex-wrap: wrap; gap: 8px 22px"><?php foreach ( $legal as $l ) : ?><a href="<?php echo esc_url( $l[1] ); ?>"><?php echo esc_html( $l[0] ); ?></a><?php endforeach; ?></span>
<span class="kcred">Site réalisé par <a href="https://agence-koino.com">Koino</a></span>
</div>
</div>
<div class="ftm" style="padding: 40px 20px 30px">
<img width="208" height="208" loading="lazy" decoding="async" src="<?php echo esc_url( $badge ); ?>" alt="Holo Surf Capbreton" style="width: 88px; height: 88px; display: block; margin: 0 auto; filter: invert(1)">
<a href="<?php echo esc_url( $contact ); ?>" class="btn b-sand" style="width: 100%; margin-top: 26px; min-height: 56px; font-size: 23px">Réserver mon cours</a>
<p class="fcontact" style="margin: 16px 0 0; text-align: center; line-height: 1.9"><a href="tel:<?php echo esc_attr( $tel_i ); ?>" style="color: #FFFFFF"><?php echo esc_html( $tel ); ?></a><br><a href="mailto:<?php echo esc_attr( $email ); ?>" style="color: #FFFFFF"><?php echo esc_html( $email ); ?></a></p>
<div style="margin-top: 26px; border-top: 1px solid #2C4250">
<?php foreach ( $cols as $i => $c ) : ?>
<details<?php echo 0 === $i ? ' open' : ''; ?>><summary><?php echo esc_html( $c[0] ); ?><span aria-hidden="true">+</span></summary><ul class="ftl"><?php foreach ( hs_links( $c[1] ) as $l ) : ?><li><a href="<?php echo esc_url( $l[1] ); ?>"><?php echo esc_html( $l[0] ); ?></a></li><?php endforeach; ?></ul></details>
<?php endforeach; ?>
<details><summary>Nous trouver<span aria-hidden="true">+</span></summary><p style="margin: 0; padding: 0 0 16px; line-height: 1.7"><?php echo esc_html( $rue . ', ' . $ville ); ?>. Les cours ont lieu le plus souvent au Santocha.</p></details>
</div>
<div style="display: flex; justify-content: center; gap: 10px; margin-top: 26px">
<?php echo $soc_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>
<div style="margin-top: 22px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 16px; font-size: 14.5px">
<?php foreach ( $legal as $l ) : ?>
<a href="<?php echo esc_url( $l[1] ); ?>" style="display: flex; align-items: center; min-height: 42px"><?php echo esc_html( $l[0] ); ?></a>
<?php endforeach; ?>
</div>
<p style="margin: 18px 0 0; text-align: center; font-size: 13.5px">© <?php echo esc_html( $annee ); ?> Holo Surf Capbreton</p>
<p class="kcred" style="margin: 2px 0 0; text-align: center; font-size: 13.5px">Site réalisé par <a href="https://agence-koino.com" style="display: inline-flex; align-items: center; min-height: 44px">Koino</a></p>
</div>
</footer>
<?php if ( 'Contact' !== hs_current_key() ) : ?>
<nav class="mbar" aria-label="Actions rapides">
<a href="tel:<?php echo esc_attr( $tel_i ); ?>" class="m-call"><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"></path></svg>Appeler</a>
<a href="<?php echo esc_url( $contact ); ?>" class="m-book">Réserver mon cours</a>
</nav>
<?php endif; ?>
