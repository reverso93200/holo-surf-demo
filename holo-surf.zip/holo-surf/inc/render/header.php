<?php
/**
 * En-tête : bandeau de contact, barre de navigation et menu mobile.
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

$tel     = hs_opt( 'telephone' );
$tel_i   = hs_opt( 'telephone_intl' );
$email   = hs_opt( 'email' );
$langues = hs_opt( 'langues' );
$links   = hs_links( 'principal' );
$contact = hs_url( 'Contact' );
$accueil = home_url( '/' );
?>
<div class="top"><div class="wrap" style="display: flex; flex-wrap: wrap; gap: 6px 24px; align-items: center; justify-content: space-between; padding-top: 9px; padding-bottom: 9px">
<span><?php echo esc_html( $langues ); ?></span>
<span style="display: flex; flex-wrap: wrap; gap: 6px 24px"><a href="tel:<?php echo esc_attr( $tel_i ); ?>"><?php echo esc_html( $tel ); ?></a><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></span>
</div></div>

<header class="hdr"><div class="wrap hrow">
<a href="<?php echo esc_url( $accueil ); ?>" class="logo" aria-label="Holo Surf Capbreton, accueil"><img width="240" height="240" decoding="async" src="<?php echo esc_url( hs_asset( 'img/logo-holo-surf-capbreton.webp' ) ); ?>" alt="" style="width: 50px; height: 50px; display: block"><span style="font-family: 'Bebas Neue', sans-serif; font-size: 30px; letter-spacing: 0.05em; line-height: 0.9">Holo Surf<span style="display: block; font-size: 17px; letter-spacing: 0.24em; color: #85652A">Capbreton</span></span></a>
<nav class="nav" aria-label="Navigation principale">
<?php foreach ( $links as $l ) : ?>
<a href="<?php echo esc_url( $l[1] ); ?>"<?php echo hs_current_attr( $l[1] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $l[0] ); ?></a>
<?php endforeach; ?>
</nav>
<div style="display: flex; align-items: center; gap: 10px">
<a href="<?php echo esc_url( $contact ); ?>" class="btn b-sand hcta">Réserver mon cours</a>
<button type="button" class="burger" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="hs-menu"><svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"></path></svg></button>
</div>
</div></header>

<div class="menu" id="hs-menu" role="dialog" aria-modal="true" aria-label="Menu" hidden>
<div style="max-width: 640px; margin: 0 auto; padding: 12px 20px 40px; box-sizing: border-box">
<div style="display: flex; align-items: center; justify-content: space-between; min-height: 64px">
<img width="480" height="480" decoding="async" loading="lazy" src="<?php echo esc_url( hs_asset( 'img/logo-holo-surf-badge.webp' ) ); ?>" alt="Holo Surf Capbreton" style="width: 64px; height: 64px; filter: invert(1)">
<button type="button" class="menu-close" aria-label="Fermer le menu" style="width: 48px; height: 48px; display: flex; align-items: center; justify-content: center; border: 0; background: #D4AA63; color: #192A33; cursor: pointer"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg></button>
</div>
<nav aria-label="Menu mobile"><ul>
<li><a href="<?php echo esc_url( $accueil ); ?>"<?php echo is_front_page() ? ' aria-current="page"' : ''; ?>>Accueil</a></li>
<?php foreach ( $links as $l ) : ?>
<li><a href="<?php echo esc_url( $l[1] ); ?>"<?php echo hs_current_attr( $l[1] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $l[0] ); ?></a></li>
<?php endforeach; ?>
</ul></nav>
<a href="<?php echo esc_url( $contact ); ?>" class="btn b-sand" style="width: 100%; margin-top: 32px; min-height: 58px; font-size: 23px">Réserver mon cours</a>
<p style="margin: 22px 0 0; font-size: 16px; line-height: 1.8; color: #B8C6CC"><a href="tel:<?php echo esc_attr( $tel_i ); ?>" style="color: #FFFFFF; text-decoration: none"><?php echo esc_html( $tel ); ?></a><br><a href="mailto:<?php echo esc_attr( $email ); ?>" style="color: #FFFFFF; text-decoration: none"><?php echo esc_html( $email ); ?></a><br><?php echo esc_html( $langues ); ?></p>
</div>
</div>
