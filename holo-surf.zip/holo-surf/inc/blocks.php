<?php
/**
 * Blocs dynamiques du thème (rendus en PHP, aperçu serveur dans l'éditeur).
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

/**
 * Déclaration des blocs.
 */
function hs_register_blocks() {
	$blocks = array(
		'header'        => array(),
		'footer'        => array(),
		'articles'      => array(
			'nombre' => array( 'type' => 'number', 'default' => 3 ),
			'titre'  => array( 'type' => 'string', 'default' => 'h3' ),
		),
		'blog-hero'     => array(),
		'blog-list'     => array(),
		'article-intro' => array(),
		'article-toc'   => array(),
		'article-toc-mobile' => array(),
		'author-box'    => array(),
		'related'       => array(),
		'search-form'   => array(),
	);
	foreach ( $blocks as $name => $attrs ) {
		register_block_type(
			'holo-surf/' . $name,
			array(
				'api_version'          => 3,
				'attributes'           => $attrs,
				'render_callback'      => 'hs_render_' . str_replace( '-', '_', $name ),
				'editor_script_handles' => array( 'holo-surf-editor' ),
				'uses_context'         => array( 'postId' ),
			)
		);
	}
}
add_action( 'init', 'hs_register_blocks' );

/**
 * Charge un gabarit de rendu.
 */
function hs_render_file( $file, $vars = array() ) {
	ob_start();
	extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract
	include get_theme_file_path( 'inc/render/' . $file . '.php' );
	return ob_get_clean();
}

function hs_render_header() {
	return hs_render_file( 'header' );
}

function hs_render_footer() {
	return hs_render_file( 'footer' );
}

/**
 * Image à la une d'un article, en remplissage de son cadre.
 */
function hs_post_thumb( $post, $alt = '', $sizes = '(max-width: 760px) 82vw, 400px' ) {
	$id = get_post_thumbnail_id( $post );
	if ( ! $id ) {
		return '';
	}
	return wp_get_attachment_image(
		$id,
		'large',
		false,
		array(
			'alt'     => $alt,
			'loading' => 'lazy',
			'style'   => 'position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; display: block',
			'sizes'   => $sizes,
		)
	);
}

/**
 * Carte d'article (modèle de la maquette).
 */
function hs_post_card( $post, $tag = 'h3', $minutes_suffix = ' min' ) {
	$post = get_post( $post );
	$url  = get_permalink( $post );
	$cat  = hs_post_category( $post );
	$out  = '<article class="post">' . "\n";
	$out .= '<a href="' . esc_url( $url ) . '" class="zoom post-img" tabindex="-1" aria-hidden="true">' . hs_post_thumb( $post ) . '</a>' . "\n";
	if ( 'post' === $post->post_type ) {
		$out .= '<p class="post-cat">' . ( $cat ? esc_html( $cat->name ) : '' ) . '<span>' . esc_html( hs_reading_time( $post ) . $minutes_suffix ) . '</span></p>' . "\n";
		$ex   = get_the_excerpt( $post );
	} else {
		$out .= '<p class="post-cat">Page</p>' . "\n";
		$ex   = get_post_meta( $post->ID, '_holo_description', true );
		$ex   = $ex ? $ex : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 24 );
	}
	$out .= '<' . $tag . ' class="post-t"><a href="' . esc_url( $url ) . '">' . esc_html( hs_typo( get_the_title( $post ) ) ) . '</a></' . $tag . '>' . "\n";
	$out .= '<p class="post-ex">' . esc_html( $ex ) . '</p>' . "\n";
	$out .= '</article>';
	return $out;
}

/**
 * Derniers articles (sections « Sur le blog »).
 */
function hs_render_articles( $attrs, $content = '', $block = null ) {
	$exclude = is_singular( 'post' ) ? array( get_queried_object_id() ) : array();
	$q       = new WP_Query(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => max( 1, (int) $attrs['nombre'] ),
			'post__not_in'        => $exclude,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
	if ( ! $q->have_posts() ) {
		return '';
	}
	$tag = in_array( $attrs['titre'], array( 'h2', 'h3' ), true ) ? $attrs['titre'] : 'h3';
	$out = '<div class="posts3 reveal">' . "\n";
	foreach ( $q->posts as $p ) {
		$out .= hs_post_card( $p, $tag ) . "\n";
	}
	return $out . '</div>';
}

/**
 * Articles liés en bas d'un article (« À lire aussi »), section masquée s'il n'y en a pas.
 */
function hs_render_related() {
	$cards = hs_render_articles( array( 'nombre' => 3, 'titre' => 'h3' ) );
	if ( '' === $cards ) {
		return '';
	}
	return '<section aria-labelledby="blog-t" style="background: #FCF9F2; padding: clamp(56px, 8vw, 96px) 0">
<div class="wrap">
<div class="reveal" style="display: flex; flex-wrap: wrap; gap: 12px 40px; align-items: flex-end; justify-content: space-between; margin-bottom: 36px">
<div><h2 id="blog-t" class="h2">À lire aussi</h2><p class="p" style="margin-top: 12px">Pour compléter ce guide avant votre prochaine session.</p></div>
<a href="' . esc_url( hs_url( 'Blog' ) ) . '" class="lnk">Tous les articles</a>
</div>
' . $cards . '
</div>
</section>';
}

/**
 * Fil d'Ariane.
 */
function hs_crumb( $items, $class = 'in crumb', $style = 'font-size: 14.5px; color: #55636A' ) {
	$out  = '<nav class="' . esc_attr( $class ) . '" aria-label="Fil d\'Ariane" style="' . esc_attr( $style ) . '">';
	$last = count( $items ) - 1;
	foreach ( $items as $i => $it ) {
		if ( $i ) {
			$out .= ' / ';
		}
		if ( $i === $last ) {
			$out .= '<span aria-current="page" style="color: #192A33">' . esc_html( $it[0] ) . '</span>';
		} else {
			$out .= '<a href="' . esc_url( $it[1] ) . '" style="color: #55636A">' . esc_html( $it[0] ) . '</a>';
		}
	}
	return $out . '</nav>';
}

/**
 * En-tête du blog : titre et filtres par thème.
 */
function hs_render_blog_hero() {
	$blog  = hs_url( 'Blog' );
	$items = array( array( 'Accueil', home_url( '/' ) ), array( 'Blog', $blog ) );
	$intro = 'Conditions, spots et conseils de Paul pour surfer à Capbreton, Hossegor et Seignosse.';
	if ( is_category() ) {
		$items[] = array( single_cat_title( '', false ), '' );
	}
	if ( is_search() ) {
		$items[] = array( 'Recherche', '' );
		/* translators: search terms */
		$intro = sprintf( 'Résultats pour « %s ».', get_search_query() );
	}
	$cats = array(
		array( 'Tous les articles', $blog, is_home() ),
	);
	foreach ( array( 'conditions', 'spots', 'apprendre', 'materiel', 'securite' ) as $slug ) {
		$term = get_category_by_slug( $slug );
		if ( $term ) {
			$cats[] = array( $term->name, get_category_link( $term ), is_category( $term->term_id ) );
		}
	}
	$out  = '<section style="background: #FCF9F2; padding: clamp(44px, 8vw, 80px) 0 0">' . "\n" . '<div class="wrap">' . "\n";
	$out .= hs_crumb( $items ) . "\n";
	$out .= '<div style="display: flex; flex-wrap: wrap; gap: 20px 64px; align-items: flex-end; justify-content: space-between; margin-top: 18px">' . "\n";
	$out .= '<h1 class="in d1" style="margin: 0; font-family: \'Bebas Neue\', sans-serif; font-weight: 400; font-size: clamp(60px, 8vw, 120px); line-height: 0.86">Le blog surf<span style="display: block; color: #85652A">de Capbreton</span></h1>' . "\n";
	$out .= '<p class="in d2" style="margin: 0; max-width: 480px; font-size: 18px; line-height: 1.65; color: #55636A">' . esc_html( $intro ) . '</p>' . "\n</div>\n";
	$out .= '<nav class="btabs in d2" aria-label="Filtrer par thème" style="margin-top: 44px">' . "\n";
	foreach ( $cats as $c ) {
		$out .= '<a href="' . esc_url( $c[1] ) . '"' . ( $c[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $c[0] ) . '</a>' . "\n";
	}
	$out .= "</nav>\n</div>\n</section>";
	return $out;
}

/**
 * Liste des articles : article à la une, grille et pagination.
 */
function hs_render_blog_list() {
	global $wp_query;
	$posts = $wp_query->posts;
	$out   = '';
	if ( ! $posts ) {
		return '<section style="padding: clamp(44px, 8vw, 72px) 0 clamp(57px, 8vw, 104px)"><div class="wrap"><p class="p">Aucun article pour le moment.</p></div></section>';
	}
	$paged = max( 1, (int) get_query_var( 'paged' ) );
	if ( 1 === $paged && ! is_search() ) {
		$f    = array_shift( $posts );
		$url  = get_permalink( $f );
		$cat  = hs_post_category( $f );
		$out .= '<section style="padding: clamp(44px, 8vw, 64px) 0 0">' . "\n" . '<div class="wrap">' . "\n" . '<article class="feat reveal">' . "\n";
		$out .= '<a href="' . esc_url( $url ) . '" class="zoom" tabindex="-1" aria-hidden="true" style="flex: 1 1 560px; min-width: 0; display: block; position: relative; aspect-ratio: 16 / 10; overflow: hidden; background: #192A33">' . hs_post_thumb( $f, '', '(max-width: 760px) calc(100vw - 32px), 640px' ) . '</a>' . "\n";
		$out .= '<div style="flex: 1 1 380px; min-width: 0">' . "\n";
		$out .= '<p class="post-cat" style="margin: 0">' . ( $cat ? esc_html( $cat->name ) : '' ) . '<span>' . esc_html( hs_reading_time( $f ) ) . ' min de lecture</span></p>' . "\n";
		$out .= '<h2 style="margin: 12px 0 0; font-family: \'Bebas Neue\', sans-serif; font-weight: 400; font-size: clamp(40px, 4vw, 60px); line-height: 0.95"><a href="' . esc_url( $url ) . '" style="color: #192A33; text-decoration: none">' . esc_html( hs_typo( get_the_title( $f ) ) ) . '</a></h2>' . "\n";
		$out .= '<p class="p" style="margin-top: 16px">' . esc_html( get_the_excerpt( $f ) ) . '</p>' . "\n";
		$out .= '<a href="' . esc_url( $url ) . '" class="lnk" style="margin-top: 22px; display: inline-flex">Lire l\'article</a>' . "\n";
		$out .= "</div>\n</article>\n</div>\n</section>\n";
	}
	$pager = paginate_links(
		array(
			'type'      => 'array',
			'prev_next' => true,
			'prev_text' => 'Précédent',
			'next_text' => 'Suivant',
			'mid_size'  => 1,
		)
	);
	if ( $posts || $pager ) {
		$out .= '<section style="padding: clamp(44px, 8vw, 72px) 0 clamp(57px, 8vw, 104px)">' . "\n" . '<div class="wrap">' . "\n";
		if ( $posts ) {
			$out .= '<div class="posts3 reveal" style="display: grid">' . "\n";
			foreach ( $posts as $p ) {
				$out .= hs_post_card( $p, 'h2' ) . "\n";
			}
			$out .= "</div>\n";
		}
		if ( $pager ) {
			$out .= '<nav class="pager" aria-label="Pages du blog">' . implode( '', array_map( 'hs_pager_item', $pager ) ) . '</nav>' . "\n";
		}
		$out .= "</div>\n</section>";
	} else {
		$out .= '<div style="height: clamp(57px, 8vw, 104px)"></div>';
	}
	return $out;
}

/**
 * Nettoie un lien de pagination pour le style de la maquette.
 */
function hs_pager_item( $html ) {
	if ( false !== strpos( $html, 'current' ) ) {
		return '<span aria-current="page">' . wp_strip_all_tags( $html ) . '</span>';
	}
	return preg_replace( '/ class="[^"]*"/', '', $html );
}

/**
 * Sommaire de l'article : titres de niveau 2 qui portent une ancre.
 */
function hs_toc_items( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return array();
	}
	preg_match_all( '/<h2[^>]*\sid="([^"]+)"[^>]*>(.*?)<\/h2>/s', $post->post_content, $m, PREG_SET_ORDER );
	$items = array();
	foreach ( $m as $h ) {
		$label = wp_strip_all_tags( $h[2] );
		$label = preg_replace( '/[\s\x{00A0}]+:\s.*$/u', '', $label );
		$items[] = array( $h[1], $label );
	}
	return $items;
}

function hs_toc_list( $items ) {
	$out = '<ol>';
	foreach ( $items as $it ) {
		$out .= '<li><a href="#' . esc_attr( $it[0] ) . '">' . esc_html( $it[1] ) . '</a></li>';
	}
	return $out . '</ol>';
}

/**
 * Introduction d'un article : fil d'Ariane, thème, titre, auteur, date, photo.
 */
function hs_render_article_intro( $attrs, $content = '', $block = null ) {
	$post = get_post( isset( $block->context['postId'] ) ? $block->context['postId'] : null );
	if ( ! $post ) {
		return '';
	}
	$cat   = hs_post_category( $post );
	$crumb = get_post_meta( $post->ID, '_holo_fil_ariane', true );
	$out   = '<section style="padding: clamp(44px, 8vw, 64px) 0 0">' . "\n" . '<div class="wrap">' . "\n";
	$fil   = array( array( 'Accueil', home_url( '/' ) ), array( 'Blog', hs_url( 'Blog' ) ) );
	if ( $cat ) {
		$fil[] = array( $cat->name, get_category_link( $cat ) );
	}
	$fil[] = array( $crumb ? $crumb : get_the_title( $post ), '' );
	$out  .= hs_crumb( $fil ) . "\n";
	$out  .= '<div style="max-width: 980px">' . "\n";
	if ( $cat ) {
		$out .= '<p class="in post-cat" style="margin: 26px 0 0; justify-content: flex-start">' . esc_html( $cat->name ) . '</p>' . "\n";
	}
	$out .= '<h1 class="in d1" style="margin: 10px 0 0; font-family: \'Bebas Neue\', sans-serif; font-weight: 400; font-size: clamp(46px, 6vw, 92px); line-height: 0.92">' . esc_html( hs_typo( get_the_title( $post ) ) ) . '</h1>' . "\n";
	$out .= '<div class="in d2" style="display: flex; flex-wrap: wrap; gap: 12px 28px; align-items: center; margin-top: 26px; font-size: 15px; color: #55636A">' . "\n";
	$out .= '<a href="' . esc_url( hs_url( 'APropos' ) ) . '" style="display: flex; align-items: center; gap: 12px; color: #192A33; text-decoration: none; font-weight: 600"><img width="88" height="88" loading="lazy" decoding="async" src="' . esc_url( hs_asset( 'img/paul-avatar.webp' ) ) . '" alt="" style="width: 44px; height: 44px; border-radius: 50%; object-fit: cover; object-position: center 20%">Par Paul, moniteur de surf à Capbreton</a>' . "\n";
	$out .= '<span>Publié le <time datetime="' . esc_attr( get_post_time( 'c', true, $post ) ) . '">' . esc_html( hs_date_fr( get_post_time( 'U', true, $post ) ) ) . '</time></span>' . "\n";
	$out .= '<span>Mis à jour le <time datetime="' . esc_attr( get_post_modified_time( 'c', true, $post ) ) . '">' . esc_html( hs_date_fr( get_post_modified_time( 'U', true, $post ) ) ) . '</time></span>' . "\n";
	$out .= '<span>' . esc_html( hs_reading_time( $post ) ) . ' min de lecture</span>' . "\n";
	$out .= "</div>\n</div>\n";
	$thumb = get_post_thumbnail_id( $post );
	if ( $thumb ) {
		$out .= '<div class="in d2" style="margin-top: 36px; aspect-ratio: 21 / 9; overflow: hidden; background: #192A33">' . wp_get_attachment_image(
			$thumb,
			'full',
			false,
			array(
				'style'         => 'width: 100%; height: 100%; object-fit: cover; display: block',
				'fetchpriority' => 'high',
				'loading'       => false,
				'sizes'         => '(max-width: 1240px) 100vw, 1192px',
			)
		) . '</div>' . "\n";
	}
	return $out . "</div>\n</section>";
}

/**
 * Colonne latérale de l'article : sommaire et encart de réservation.
 */
function hs_render_article_toc( $attrs, $content = '', $block = null ) {
	$post  = get_post( isset( $block->context['postId'] ) ? $block->context['postId'] : null );
	$items = hs_toc_items( $post );
	$out   = '<aside class="art-aside" aria-label="Sommaire et réservation">' . "\n";
	if ( $items ) {
		$out .= '<nav class="toc" aria-label="Sommaire"><p style="margin: 0 0 8px; font-family: \'Bebas Neue\', sans-serif; font-size: 24px; color: #192A33">Sommaire</p>' . hs_toc_list( $items ) . '</nav>' . "\n";
	}
	$out .= '<div style="margin-top: 32px; padding: 28px; background: #192A33; color: #FFFFFF">' . "\n";
	$out .= '<p style="margin: 0; font-family: \'Bebas Neue\', sans-serif; font-size: 30px; line-height: 1; color: #D4AA63">Surfer à la bonne marée</p>' . "\n";
	$out .= '<p style="margin: 10px 0 0; font-size: 15.5px; line-height: 1.6; color: #C9D4D9">Paul fixe l\'horaire et le spot de chaque cours selon la marée du jour.</p>' . "\n";
	$out .= '<a href="' . esc_url( hs_url( 'Contact' ) ) . '" class="btn b-sand" style="margin-top: 20px; width: 100%">Réserver mon cours</a>' . "\n";
	return $out . "</div>\n</aside>";
}

/**
 * Sommaire repliable affiché sur mobile, inséré après l'encart « L'essentiel ».
 */
function hs_toc_mobile_html( $post ) {
	$items = hs_toc_items( $post );
	if ( ! $items ) {
		return '';
	}
	return '<details class="toc-m toc" style="margin-top: 24px; border-top: 1px solid #ECE4D3; border-bottom: 1px solid #ECE4D3"><summary style="min-height: 52px; display: flex; align-items: center; font-family: \'Bebas Neue\', sans-serif; font-size: 24px; color: #192A33">Sommaire</summary>' . hs_toc_list( $items ) . '</details>';
}

function hs_render_article_toc_mobile( $attrs, $content = '', $block = null ) {
	return '';
}

/**
 * Encart auteur en fin d'article.
 */
function hs_render_author_box() {
	return '<div class="hs-author" style="margin-top: 40px; padding: 28px; background: #FCF9F2; display: flex; flex-wrap: wrap; gap: 20px; align-items: center">
<img width="192" height="192" loading="lazy" decoding="async" src="' . esc_url( hs_asset( 'img/paul-avatar.webp' ) ) . '" alt="Paul, moniteur de surf à Capbreton" style="width: 96px; height: 96px; border-radius: 50%; object-fit: cover; object-position: center 20%">
<div style="flex: 1 1 300px; min-width: 0">
<p style="margin: 0; font-family: \'Bebas Neue\', sans-serif; font-size: 28px; line-height: 1; color: #192A33">Paul, moniteur de surf à Capbreton</p>
<p style="margin: 8px 0 0; font-size: 16px; line-height: 1.6">Surfeur depuis plus de quinze ans, Paul a créé Holo Surf, école itinérante labellisée Ecosafe Surfing. Il choisit chaque jour le spot et l\'horaire des cours selon la houle et la marée.</p>
<a href="' . esc_url( hs_url( 'APropos' ) ) . '" class="lnk" style="margin-top: 10px; display: inline-flex">En savoir plus sur Paul</a>
</div>
</div>';
}

/**
 * Formulaire de recherche (page 404).
 */
function hs_render_search_form() {
	return '<form class="in d2" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '" style="margin-top: 28px; display: flex; gap: 10px; max-width: 520px"><label for="q404" class="lbl" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0)">Rechercher sur le site</label><input id="q404" name="s" type="search" placeholder="Rechercher sur le site" style="flex: 1 1 auto; min-width: 0; min-height: 52px; padding: 0 14px; border: 0; border-bottom: 1.5px solid #C9C2B2; background: #FFFFFF; font-family: inherit; font-size: 16px"><button type="submit" class="btn b-navy" style="width: auto; min-height: 52px">Rechercher</button></form>';
}

/**
 * Sur un article, le sommaire mobile se place après l'encart « L'essentiel ».
 */
function hs_insert_mobile_toc( $content ) {
	if ( ! is_singular( 'post' ) ) {
		return $content;
	}
	$toc = hs_toc_mobile_html( get_the_ID() );
	if ( ! $toc || false !== strpos( $content, 'toc-m' ) ) {
		return $content;
	}
	if ( preg_match( '/<div class="wp-block-group key[^"]*">.*?<\/ul>\s*<\/div>/s', $content, $m ) ) {
		return str_replace( $m[0], $m[0] . "\n" . $toc, $content );
	}
	return $toc . $content;
}
add_filter( 'the_content', 'hs_insert_mobile_toc', 20 );

/**
 * Masque une section « Sur le blog » tant qu'aucun article n'est publié.
 */
function hs_hide_empty_blog_section( $html, $block ) {
	if ( 'core/group' === $block['blockName'] && ! empty( $block['attrs']['className'] ) && false !== strpos( $block['attrs']['className'], 'hs-blog-sec' ) && false === strpos( $html, 'class="post"' ) ) {
		return '';
	}
	return $html;
}
add_filter( 'render_block', 'hs_hide_empty_blog_section', 10, 2 );
