<?php
/**
 * Fonctions utilitaires du thème Holo Surf.
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

/**
 * Chemins des pages du site (identiques à la maquette).
 */
function hs_paths() {
	return array(
		'Main'      => '/',
		'Tarifs'    => '/cours-de-surf-capbreton',
		'Location'  => '/location-surf-capbreton',
		'InfosSurf' => '/webcam-capbreton',
		'Spots'     => '/spots-surf-capbreton',
		'APropos'   => '/moniteur-surf-capbreton',
		'Contact'   => '/reserver-cours-surf-capbreton',
		'Concours'  => '/concours-planche-surf',
		'Legal'     => '/mentions-legales',
		'Blog'      => '/blog',
		'Article'   => '/blog/maree-capbreton',
	);
}

/**
 * Valeur d'un réglage. L'extension Holo Surf Core fournit les valeurs saisies par Paul,
 * le thème garde des valeurs par défaut pour s'afficher seul.
 */
function hs_opt( $key ) {
	if ( function_exists( 'holo_surf_reglage' ) ) {
		return holo_surf_reglage( $key );
	}
	$defaults = array(
		'telephone'      => '06 60 95 77 20',
		'telephone_intl' => '+33660957720',
		'email'          => 'holosurfcapbreton@gmail.com',
		'rue'            => '29b rue Jean-Baptiste Gabarra',
		'code_postal'    => '40130',
		'ville'          => 'Capbreton',
		'langues'        => 'We speak English / Hablamos español',
		'instagram'      => 'https://www.instagram.com/holosurfcapbreton/',
		'facebook'       => 'https://www.facebook.com/profile.php?id=61574016721386',
		'whatsapp'       => '33660957720',
	);
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
}

/**
 * Identifiants des pages créées par l'installation (clé de maquette => ID).
 */
function hs_page_ids() {
	$ids = get_option( 'holo_surf_pages', array() );
	return is_array( $ids ) ? $ids : array();
}

/**
 * Adresse d'une page du site à partir de sa clé de maquette.
 */
function hs_url( $key ) {
	$ids = hs_page_ids();
	if ( 'Main' === $key ) {
		return home_url( '/' );
	}
	if ( 'Blog' === $key && get_option( 'page_for_posts' ) ) {
		return get_permalink( get_option( 'page_for_posts' ) );
	}
	if ( ! empty( $ids[ $key ] ) && 'publish' === get_post_status( $ids[ $key ] ) ) {
		return get_permalink( $ids[ $key ] );
	}
	$paths = hs_paths();
	return home_url( isset( $paths[ $key ] ) ? $paths[ $key ] : '/' );
}

/**
 * Clé de maquette de la page affichée (sert aux classes du body).
 */
function hs_current_key() {
	if ( is_front_page() ) {
		return 'Main';
	}
	if ( is_home() || is_archive() || is_search() ) {
		return 'Blog';
	}
	if ( is_singular( 'post' ) ) {
		return 'Article';
	}
	if ( is_404() ) {
		return 'Erreur404';
	}
	if ( is_page() ) {
		$id  = get_queried_object_id();
		$key = array_search( $id, hs_page_ids(), true );
		if ( $key ) {
			return $key;
		}
		$slug = get_post_field( 'post_name', $id );
		foreach ( hs_paths() as $k => $p ) {
			if ( trim( $p, '/' ) === $slug ) {
				return $k;
			}
		}
	}
	return '';
}

/**
 * Date en français, quelle que soit la langue de l'administration.
 */
function hs_date_fr( $timestamp ) {
	$mois = array( 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre' );
	return (int) wp_date( 'j', $timestamp ) . ' ' . $mois[ (int) wp_date( 'n', $timestamp ) - 1 ] . ' ' . wp_date( 'Y', $timestamp );
}

/**
 * Temps de lecture estimé, en minutes.
 */
function hs_reading_time( $post = null ) {
	$post  = get_post( $post );
	$force = (int) get_post_meta( $post->ID, '_holo_temps_lecture', true );
	if ( $force > 0 ) {
		return $force;
	}
	$words = count( preg_split( '/\s+/u', trim( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) ), -1, PREG_SPLIT_NO_EMPTY ) );
	return max( 1, (int) ceil( $words / 230 ) );
}

/**
 * Première catégorie d'un article.
 */
function hs_post_category( $post = null ) {
	$cats = get_the_category( $post ? get_post( $post )->ID : 0 );
	return $cats ? $cats[0] : null;
}

/**
 * Adresse d'une image du thème.
 */
function hs_asset( $path ) {
	return get_theme_file_uri( 'assets/' . ltrim( $path, '/' ) );
}

/**
 * Liens d'un menu, avec une liste par défaut tant que le menu n'est pas créé.
 *
 * @param string $location Emplacement de menu.
 * @param array  $fallback Liste de [libellé, adresse].
 */
function hs_menu_links( $location, $fallback ) {
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ $location ] ) ) {
		$items = wp_get_nav_menu_items( $locations[ $location ] );
		if ( $items ) {
			$out = array();
			foreach ( $items as $item ) {
				if ( (int) $item->menu_item_parent ) {
					continue;
				}
				$out[] = array( $item->title, $item->url );
			}
			return $out;
		}
	}
	return $fallback;
}

/**
 * Attribut aria-current si le lien pointe vers la page affichée.
 */
function hs_current_attr( $url ) {
	if ( false !== strpos( $url, '#' ) ) {
		return '';
	}
	$req  = untrailingslashit( strtok( home_url( add_query_arg( array() ) ), '?' ) );
	$path = untrailingslashit( strtok( $url, '?' ) );
	if ( is_singular( 'post' ) || is_category() ) {
		$req = untrailingslashit( hs_url( 'Blog' ) );
	}
	return ( $req === $path || ( is_front_page() && untrailingslashit( home_url( '/' ) ) === $path ) ) ? ' aria-current="page"' : '';
}

/**
 * Menus par défaut (avant la création des menus par l'installation).
 */
function hs_default_menu( $which ) {
	switch ( $which ) {
		case 'principal':
			return array(
				array( 'Concours 2026', hs_url( 'Concours' ) ),
				array( 'Les cours et tarifs', hs_url( 'Tarifs' ) ),
				array( 'Location', hs_url( 'Location' ) ),
				array( 'Infos surf', hs_url( 'InfosSurf' ) ),
				array( 'Les spots', hs_url( 'Spots' ) ),
				array( 'À propos', hs_url( 'APropos' ) ),
				array( 'Blog', hs_url( 'Blog' ) ),
			);
		case 'pied-cours':
			return array(
				array( 'Cours et tarifs', hs_url( 'Tarifs' ) ),
				array( 'Location', hs_url( 'Location' ) ),
				array( 'Concours 2026', hs_url( 'Concours' ) ),
				array( 'À propos', hs_url( 'APropos' ) ),
			);
		case 'pied-infos':
			return array(
				array( 'Les baïnes', hs_url( 'InfosSurf' ) . '#baines' ),
				array( 'Les vagues', hs_url( 'InfosSurf' ) . '#vagues' ),
				array( 'Prévisions surf', hs_url( 'InfosSurf' ) . '#previsions' ),
				array( 'Webcam', hs_url( 'InfosSurf' ) . '#webcam' ),
				array( 'Blog', hs_url( 'Blog' ) ),
			);
		case 'pied-spots':
			return array(
				array( 'Capbreton', hs_url( 'Spots' ) . '#capbreton' ),
				array( 'Hossegor', hs_url( 'Spots' ) . '#hossegor' ),
				array( 'Seignosse', hs_url( 'Spots' ) . '#seignosse' ),
			);
		case 'pied-legal':
			return array(
				array( 'Mentions légales', hs_url( 'Legal' ) ),
				array( 'Cookies', hs_url( 'Legal' ) . '#cookies' ),
				array( 'Confidentialité', hs_url( 'Legal' ) . '#confidentialite' ),
				array( "Conditions d'utilisation", hs_url( 'Legal' ) . '#conditions' ),
			);
	}
	return array();
}

/**
 * Liens d'un emplacement de menu.
 */
function hs_links( $which ) {
	return hs_menu_links( $which, hs_default_menu( $which ) );
}

/**
 * Adresse d'une photo : celle de la médiathèque une fois importée, sinon le fichier du thème.
 */
function hs_img( $blob ) {
	static $files = null;
	$medias = get_option( 'holo_surf_medias', array() );
	if ( ! empty( $medias[ $blob ] ) ) {
		$u = wp_get_attachment_url( $medias[ $blob ] );
		if ( $u ) {
			return $u;
		}
	}
	if ( null === $files ) {
		$files = include get_theme_file_path( 'inc/medias.php' );
	}
	return isset( $files[ $blob ] ) ? hs_asset( 'img/media/' . $files[ $blob ] ) : '';
}

/**
 * Typographie française des titres : espaces insécables avant la ponctuation haute
 * et après les mots courts, comme dans la maquette.
 */
function hs_typo( $t ) {
	$nb = "\xc2\xa0";
	$t  = preg_replace( '/ ([:;?!»])/u', $nb . '$1', $t );
	$t  = preg_replace( '/« /u', '«' . $nb, $t );
	$short = 'à|de|du|des|en|et|le|la|les|un|une|au|aux|ta|ton|sa|son|mon|ma|votre|vos|nos|notre|pour|par|sur|ou|avec';
	return preg_replace( '/(?<![\p{L}\'’-])(' . $short . ') (?=\S)/iu', '$1' . $nb, $t );
}
