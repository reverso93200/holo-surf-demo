<?php
/**
 * Vitesse d'affichage côté visiteur :
 * - CSS de la page en ligne dans le head (aucune feuille bloquante), styles des sections limités à ceux de la page ;
 * - images en AVIF avec repli WebP, srcset responsives, image principale prioritaire et préchargée ;
 * - polices de repli aux mêmes métriques (pas de décalage de mise en page) ;
 * - retrait des scripts et styles WordPress inutiles aux visiteurs (emoji, oEmbed, styles des blocs non utilisés).
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

/**
 * Faut-il optimiser la page ? Seulement les pages publiques vues par un visiteur.
 */
function hs_perf_actif() {
	if ( is_admin() || wp_doing_ajax() || wp_is_json_request() || is_feed() || is_robots() || is_trackback() || is_embed() ) {
		return false;
	}
	if ( isset( $_GET['hs_perf'] ) && '0' === $_GET['hs_perf'] ) { // phpcs:ignore WordPress.Security.NonceVerification
		return false;
	}
	return ! ( function_exists( 'is_customize_preview' ) && is_customize_preview() );
}

/* ------------------------------------------------------------------ Nettoyage du head */

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_oembed_add_host_js' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'template_redirect', 'rest_output_link_header', 11 );
remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter(
	'wp_resource_hints',
	function ( $urls, $type ) {
		return 'dns-prefetch' === $type ? array() : $urls;
	},
	10,
	2
);
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_dequeue_script( 'wp-embed' );
		if ( ! is_user_logged_in() ) {
			wp_dequeue_style( 'dashicons' );
			wp_deregister_script( 'heartbeat' );
		}
	},
	100
);

/**
 * Préchargement des pages au survol (Speculation Rules, natives depuis WordPress 6.8).
 */
add_filter(
	'wp_speculation_rules_configuration',
	function ( $config ) {
		return is_array( $config ) || null === $config ? array( 'mode' => 'prefetch', 'eagerness' => 'moderate' ) : $config;
	}
);

/**
 * Moins d'images chargées tout de suite : seule l'image principale est prioritaire.
 */
add_filter(
	'wp_omit_loading_attr_threshold',
	function () {
		return 1;
	}
);

/* ------------------------------------------------------------------ CSS en ligne */

/**
 * Règles communes des blocs utilisés par le site (remplacent les feuilles des blocs du cœur).
 */
function hs_css_coeur() {
	return '.wp-block-image>a,.wp-block-image>figure>a{display:inline-block}.wp-block-image img{box-sizing:border-box;height:auto;max-width:100%;vertical-align:bottom}'
		. '.wp-block-image :where(figcaption){margin-bottom:1em;margin-top:.5em}.wp-block-image figure{margin:0}ol,ul{box-sizing:border-box}'
		. '.wp-block-group{box-sizing:border-box}.wp-block-details{box-sizing:border-box}.wp-block-details summary{cursor:pointer}.wp-block-post-content{display:flow-root}'
		. 'picture.hs-pic{display:contents}';
}

/**
 * Feuilles du thème lues une fois (déjà minifiées à la construction).
 */
function hs_css_fichier( $nom ) {
	$f = get_theme_file_path( 'assets/css/' . $nom );
	return is_readable( $f ) ? (string) file_get_contents( $f ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
}

/**
 * Styles des sections : seulement les classes présentes dans la page.
 */
function hs_css_sections( $html ) {
	static $regles = null;
	if ( null === $regles ) {
		$f      = get_theme_file_path( 'inc/blocks-css.php' );
		$regles = is_readable( $f ) ? include $f : array();
	}
	if ( ! preg_match_all( '/\bui?-[0-9a-f]{6}\b/', $html, $m ) ) {
		return '';
	}
	$out = '';
	foreach ( array_unique( $m[0] ) as $c ) {
		if ( isset( $regles[ $c ] ) ) {
			$out .= $regles[ $c ];
		}
	}
	return $out;
}

/* ------------------------------------------------------------------ Images */

/**
 * Pièce jointe correspondant à une adresse d'image de la médiathèque (taille réduite comprise).
 */
function hs_image_id( $src ) {
	static $cache = array();
	if ( isset( $cache[ $src ] ) ) {
		return $cache[ $src ];
	}
	$up = wp_get_upload_dir();
	$id = 0;
	if ( 0 === strpos( $src, $up['baseurl'] ) ) {
		$id = attachment_url_to_postid( $src );
		if ( ! $id ) {
			$plein = preg_replace( '/-(\d+x\d+|\d+)(\.(?:webp|avif|jpe?g|png))$/i', '$2', $src );
			$id    = attachment_url_to_postid( $plein );
		}
	}
	$cache[ $src ] = (int) $id;
	return $cache[ $src ];
}

/**
 * Variantes d'une image : largeur => [webp, avif] (adresses).
 */
function hs_image_variantes( $id ) {
	static $cache = array();
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$meta = wp_get_attachment_metadata( $id );
	$out  = array();
	if ( is_array( $meta ) && ! empty( $meta['file'] ) && ! empty( $meta['width'] ) ) {
		$base = trailingslashit( dirname( wp_get_attachment_url( $id ) ) );
		$avif = (array) get_post_meta( $id, '_holo_avif', true );
		$out[ (int) $meta['width'] ] = array( wp_get_attachment_url( $id ), isset( $avif['full'] ) ? $base . $avif['full'] : '' );
		$ratio = $meta['height'] / $meta['width'];
		foreach ( (array) ( isset( $meta['sizes'] ) ? $meta['sizes'] : array() ) as $nom => $s ) {
			if ( 0 !== strpos( $nom, 'hs-' ) && 'medium_large' !== $nom ) {
				continue;
			}
			if ( abs( $s['height'] / $s['width'] - $ratio ) > 0.02 ) {
				continue;
			}
			$out[ (int) $s['width'] ] = array( $base . $s['file'], isset( $avif[ $nom ] ) ? $base . $avif[ $nom ] : '' );
		}
		ksort( $out );
	}
	$cache[ $id ] = $out;
	return $out;
}

function hs_srcset( $variantes, $i ) {
	$p = array();
	foreach ( $variantes as $w => $v ) {
		if ( $v[ $i ] ) {
			$p[] = $v[ $i ] . ' ' . $w . 'w';
		}
	}
	return implode( ', ', $p );
}

function hs_attr( $tag, $nom ) {
	return preg_match( '/\s' . $nom . '="([^"]*)"/', $tag, $m ) ? $m[1] : null;
}

function hs_set_attr( $tag, $nom, $val ) {
	if ( null === $val ) {
		return preg_replace( '/\s' . $nom . '="[^"]*"/', '', $tag );
	}
	if ( null !== hs_attr( $tag, $nom ) ) {
		return preg_replace( '/(\s' . $nom . '=")[^"]*(")/', '${1}' . str_replace( '$', '\$', esc_attr( $val ) ) . '$2', $tag );
	}
	return preg_replace( '/^<img\b/', '<img ' . $nom . '="' . esc_attr( $val ) . '"', $tag );
}

/**
 * Réécrit une balise img : srcset WebP, source AVIF, chargement différé ou prioritaire.
 * Renvoie [html, données de préchargement ou null].
 */
function hs_image( $tag, $principale ) {
	$src = hs_attr( $tag, 'src' );
	if ( ! $src || false !== strpos( $tag, 'data-hs-brut' ) ) {
		return array( $tag, null );
	}
	$id   = hs_image_id( $src );
	$vars = $id ? hs_image_variantes( $id ) : array();
	$w    = (int) hs_attr( $tag, 'width' );
	if ( $principale ) {
		$tag = hs_set_attr( $tag, 'loading', null );
		$tag = hs_set_attr( $tag, 'fetchpriority', 'high' );
	} else {
		$tag = hs_set_attr( $tag, 'fetchpriority', null );
		if ( null === hs_attr( $tag, 'loading' ) ) {
			$tag = hs_set_attr( $tag, 'loading', 'lazy' );
		}
	}
	if ( null === hs_attr( $tag, 'decoding' ) ) {
		$tag = hs_set_attr( $tag, 'decoding', 'async' );
	}
	if ( count( $vars ) < 1 ) {
		return array( $tag, null );
	}
	$webp = hs_srcset( $vars, 0 );
	$avif = hs_srcset( $vars, 1 );
	$base = preg_replace( '/^auto,\s*/', '', (string) hs_attr( $tag, 'sizes' ) );
	if ( '' === $base ) {
		$base = $w ? '(max-width: ' . $w . 'px) 100vw, ' . $w . 'px' : '100vw';
	}
	$sizes = ( ! $principale && 'lazy' === hs_attr( $tag, 'loading' ) ) ? 'auto, ' . $base : $base;
	$tag   = hs_set_attr( $tag, 'srcset', $webp );
	$tag   = hs_set_attr( $tag, 'sizes', $sizes );
	$pre = array( 'webp' => $webp, 'avif' => $avif, 'sizes' => $sizes );
	if ( $avif ) {
		$tag = '<picture class="hs-pic"><source type="image/avif" srcset="' . esc_attr( $avif ) . '" sizes="' . esc_attr( $sizes ) . '">' . $tag . '</picture>';
	}
	return array( $tag, $pre );
}

/**
 * Toutes les images de la page : la première image du contenu principal est l'image prioritaire.
 */
function hs_images_page( $html, &$precharge ) {
	$main = strpos( $html, '<main' );
	if ( false === $main ) {
		$main = 0;
	}
	$avant = substr( $html, 0, $main );
	$apres = substr( $html, $main );
	$premier = true;
	$apres   = preg_replace_callback(
		'/<picture\b.*?<\/picture>|<img\b[^>]*>/s',
		function ( $m ) use ( &$premier, &$precharge ) {
			if ( 0 === strpos( $m[0], '<picture' ) ) {
				return $m[0];
			}
			$w    = (int) hs_attr( $m[0], 'width' );
			$prio = $premier && ( ! $w || $w >= 300 ) && false === strpos( $m[0], 'aria-hidden' );
			if ( $prio ) {
				$premier = false;
			}
			list( $tag, $pre ) = hs_image( $m[0], $prio );
			if ( $prio && $pre ) {
				$precharge = $pre;
			}
			return $tag;
		},
		$apres
	);
	// En-tête : le logo s'affiche tout de suite mais n'est pas prioritaire.
	$avant = preg_replace( '/\sfetchpriority="high"/', '', $avant );
	return $avant . $apres;
}

/* ------------------------------------------------------------------ Polices */

function hs_css_polices() {
	return '@font-face{font-family:"Barlow Fallback";src:local("Arial"),local("Liberation Sans"),local("Helvetica");size-adjust:97.5%;ascent-override:102.6%;descent-override:20.5%;line-gap-override:0%}'
		. '@font-face{font-family:"Bebas Neue Fallback";src:local("Arial"),local("Liberation Sans"),local("Helvetica");size-adjust:76.6%;ascent-override:117.5%;descent-override:39.2%;line-gap-override:0%}';
}

/**
 * Ajoute la police de repli après chaque famille du site.
 */
function hs_polices_repli( $html ) {
	$html = preg_replace( '/([\'"])Bebas Neue\1(\s*,\s*)(?![\'"]Bebas Neue Fallback)/', "'Bebas Neue','Bebas Neue Fallback'$2", $html );
	return preg_replace( '/(font-family:\s*)Barlow(\s*,)(?!\s*[\'"]Barlow Fallback)/', "$1Barlow,'Barlow Fallback'$2", $html );
}

/* ------------------------------------------------------------------ Traitement de la page */

/**
 * Styles WordPress inutiles retirés : feuilles des blocs du cœur, emoji.
 */
function hs_retirer_styles( $html ) {
	$ids = 'wp-block-(?:image|image-theme|heading|paragraph|group|group-theme|list|details|post-content|template-part-theme)-inline-css|wp-emoji-styles-inline-css|classic-theme-styles-inline-css';
	return preg_replace( '/<style id="(?:' . $ids . ')"[^>]*>.*?<\/style>\s*/s', '', $html );
}

function hs_traiter_page( $html ) {
	if ( false === strpos( $html, '</head>' ) || false === strpos( $html, '<body' ) ) {
		return $html;
	}
	$html      = hs_retirer_styles( $html );
	$precharge = null;
	$html      = hs_images_page( $html, $precharge );
	// CSS de la page, en ligne
	$css  = hs_css_polices() . hs_css_coeur() . hs_css_fichier( 'maquette.min.css' ) . hs_css_sections( $html ) . hs_css_fichier( 'theme.min.css' );
	$head = '<style id="hs-css">' . $css . '</style>' . "\n";
	if ( $precharge ) {
		$type = $precharge['avif'] ? 'image/avif' : 'image/webp';
		$set  = $precharge['avif'] ? $precharge['avif'] : $precharge['webp'];
		$head = '<link rel="preload" as="image" type="' . $type . '" imagesrcset="' . esc_attr( $set ) . '" imagesizes="' . esc_attr( $precharge['sizes'] ) . '" fetchpriority="high">' . "\n" . $head;
	}
	$html = str_replace( '<!--hs-css-->', $head, $html );
	return hs_polices_repli( $html );
}

add_action(
	'template_redirect',
	function () {
		if ( hs_perf_actif() ) {
			ob_start( 'hs_traiter_page' );
		}
	},
	-1000
);

/**
 * Emplacement du CSS en ligne, juste après les préchargements de polices.
 */
add_action(
	'wp_head',
	function () {
		echo "<!--hs-css-->\n";
	},
	2
);

/**
 * Préréglages par défaut de WordPress (couleurs, dégradés, tailles) retirés : le site n'utilise que les siens.
 */
add_filter(
	'wp_theme_json_data_default',
	function ( $theme_json ) {
		$data = $theme_json->get_data();
		unset( $data['settings']['color']['palette'], $data['settings']['color']['gradients'], $data['settings']['color']['duotone'] );
		unset( $data['settings']['typography']['fontSizes'], $data['settings']['spacing']['spacingSizes'], $data['settings']['shadow']['presets'], $data['settings']['dimensions']['aspectRatios'] );
		return new WP_Theme_JSON_Data( $data, 'default' );
	}
);

/**
 * Icône du site par défaut (tant qu'aucune n'est choisie dans le Customizer) : évite la requête /favicon.ico en erreur.
 */
add_filter(
	'get_site_icon_url',
	function ( $url, $size ) {
		if ( $url ) {
			return $url;
		}
		$f = $size <= 32 ? 'favicon-32.png' : ( $size <= 180 ? 'apple-touch-icon.png' : 'icon-512.png' );
		return hs_asset( 'img/' . $f );
	},
	10,
	2
);
