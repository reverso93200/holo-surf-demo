<?php
/**
 * Photos livrées avec le thème (identifiant de la maquette => fichier).
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

return array(
	'038cdb79f92c60fc87e4bde1fc2e1bf6' => 'plage-santocha-capbreton-vue-du-ciel.webp',
	'e4fe848118a1099a3a24a2e83acd3ed7' => 'plage-santocha-blockhaus-capbreton.webp',
	'c1658a8054f881a4d5d2929fda8cbc74' => 'cours-collectif-surf-santocha.webp',
	'1b7193192cca65022ca515c64d773f39' => 'paul-moniteur-surf-capbreton.webp',
	'364b827c81e2a9ff461ab7e676448788' => 'surfeurs-coucher-soleil-capbreton.webp',
	'dabea7a64c36488fdd75a01412fbf2bf' => 'cours-particulier-surf-capbreton.webp',
	'8824bd5b6a80e68ef34a4fee0f6fbca0' => 'cours-surf-enfants-santocha.webp',
	'17edbc4d06c815d93bce895ab0c1fe5d' => 'enfant-debout-planche-capbreton.webp',
	'c6e90b27fe474c9ebd785e4276dfdeba' => 'tube-culs-nus-hossegor.webp',
	'a67cb1a03e4015e525f7e0eb9f452cc5' => 'vague-hossegor-pyrenees.webp',
	'ea460ba8de49e9474e6af6d1e0b445ee' => 'surfeur-vague-seignosse.webp',
	'cfab3bf3216fad58ce90fb60649a54a6' => 'enfants-rament-cours-collectif.webp',
	'd7998c9e816d82c8acf6c8b945419594' => 'paul-encourage-eleve-surf.webp',
	'7c0cb50b1d57d0d2fc0badb0efec5fa2' => 'paul-enfants-vagues-santocha.webp',
	'a1df94dc5233aa7c13086952257fb04e' => 'fresque-protege-ta-dune-santocha.webp',
	'3b31185d96af976bfec3e210631bcb36' => 'tube-oceanides-capbreton.webp',
	'e8d41159726ca97b3fe3268639ef8b92' => 'label-ecosafe-surfing.webp',
	'bb43cda8887e1d734f5acb7b23489f72' => 'location-planche-hybride.webp',
	'59d3f1e3fd6cb3df15a96a74d2346e7c' => 'location-combinaison-integrale.webp',
	'0cacc250d6b5da153f4fdc740318545d' => 'location-planche-mousse-ocean-storm.webp',
	'7deae58f184d2ff169cef3dbc6227b2d' => 'planche-ocean-storm-7-6-weekender.webp',
	'386c78c0b287cf3189b2887ab78cd0af' => 'location-combinaison-courte.webp',
	'a923f007d594b1f2873440aed578cb43' => 'surfeur-eau-turquoise-vue-du-ciel.webp',
);
