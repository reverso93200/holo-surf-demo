/* Holo Surf : menu mobile, « Voir plus », onglets, galerie, carte. */
(function () {
	'use strict';
	var d = document;

	/* Menu mobile */
	var burger = d.querySelector('.burger');
	var menu = d.getElementById('hs-menu');
	if (burger && menu) {
		var close = menu.querySelector('.menu-close');
		var open = function (state) {
			menu.hidden = !state;
			burger.setAttribute('aria-expanded', state ? 'true' : 'false');
			d.documentElement.style.overflow = state ? 'hidden' : '';
			if (state) {
				var first = menu.querySelector('nav a');
				if (first) { first.focus({ preventScroll: true }); }
			} else {
				burger.focus({ preventScroll: true });
			}
		};
		burger.addEventListener('click', function () { open(menu.hidden); });
		if (close) { close.addEventListener('click', function () { open(false); }); }
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) { open(false); } });
		menu.addEventListener('click', function (e) { if (e.target.closest('a')) { open(false); } });
		window.addEventListener('resize', function () { if (window.innerWidth >= 1280 && !menu.hidden) { open(false); } });
	}

	/* Textes repliables */
	d.querySelectorAll('.fold').forEach(function (fold, i) {
		if (!fold.id) { fold.id = 'hs-fold-' + i; }
		fold.setAttribute('data-open', 'false');
		var btn = d.createElement('button');
		btn.type = 'button';
		btn.className = 'more';
		btn.setAttribute('aria-controls', fold.id);
		btn.setAttribute('aria-expanded', 'false');
		var label = d.createTextNode('Voir plus');
		var plus = d.createElement('span');
		plus.setAttribute('aria-hidden', 'true');
		plus.textContent = '+';
		btn.appendChild(label);
		btn.appendChild(plus);
		btn.addEventListener('click', function () {
			var o = fold.getAttribute('data-open') !== 'true';
			fold.setAttribute('data-open', o ? 'true' : 'false');
			btn.setAttribute('aria-expanded', o ? 'true' : 'false');
			label.nodeValue = o ? 'Voir moins' : 'Voir plus';
			if (!o) { fold.scrollIntoView({ block: 'start' }); }
		});
		fold.parentNode.insertBefore(btn, fold.nextSibling);
	});

	/* Onglets de saison des cours collectifs */
	d.querySelectorAll('.hs-saisons').forEach(function (box) {
		var tabs = box.querySelectorAll('.tab');
		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				tabs.forEach(function (t) {
					var on = t === tab;
					t.setAttribute('aria-pressed', on ? 'true' : 'false');
					var panel = d.getElementById(t.getAttribute('aria-controls'));
					if (panel) { panel.hidden = !on; }
				});
			});
		});
	});

	/* Pages légales : un onglet par texte, l'adresse suit l'onglet */
	var tablist = d.querySelector('.tabs[role=tablist]');
	if (tablist) {
		var tabsL = Array.prototype.slice.call(tablist.querySelectorAll('[role=tab]'));
		var h1 = d.querySelector('h1');
		var crumbs = d.querySelectorAll('.crumb');
		var show = function (tab, push) {
			tabsL.forEach(function (t) {
				var on = t === tab;
				t.setAttribute('aria-selected', on ? 'true' : 'false');
				t.tabIndex = on ? 0 : -1;
				var p = d.getElementById(t.getAttribute('aria-controls'));
				if (p) { p.hidden = !on; p.setAttribute('role', 'tabpanel'); p.setAttribute('aria-labelledby', t.id); }
			});
			if (h1) { h1.textContent = tab.textContent; }
			crumbs.forEach(function (c) {
				var last = c.lastChild;
				if (last && last.nodeType === 3) { last.nodeValue = ' / ' + tab.textContent; }
				var cur = c.querySelector('[aria-current]');
				if (cur) { cur.textContent = tab.textContent; }
			});
			if (push) { history.replaceState(null, '', tabsL.indexOf(tab) ? '#' + tab.getAttribute('aria-controls') : location.pathname); }
		};
		tabsL.forEach(function (t, i) {
			t.addEventListener('click', function () { show(t, true); });
			t.addEventListener('keydown', function (e) {
				var k = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
				if (k) { var n = tabsL[(i + k + tabsL.length) % tabsL.length]; n.focus(); show(n, true); }
			});
		});
		var fromHash = function () {
			var h = location.hash.slice(1);
			var t = tabsL.filter(function (x) { return x.getAttribute('aria-controls') === h; })[0] || tabsL[0];
			show(t, false);
		};
		window.addEventListener('hashchange', fromHash);
		fromHash();
	}

	/* Galerie défilante : la suite d'images est doublée pour boucler */
	d.querySelectorAll('.strip').forEach(function (strip) {
		Array.prototype.slice.call(strip.children).forEach(function (el) {
			var c = el.cloneNode(true);
			c.setAttribute('aria-hidden', 'true');
			c.querySelectorAll('img').forEach(function (img) { img.alt = ''; img.removeAttribute('fetchpriority'); });
			strip.appendChild(c);
		});
	});

	/* Carte Google chargée au clic */
	d.querySelectorAll('.mapf button').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var box = btn.closest('.mapf');
			var f = d.createElement('iframe');
			f.src = 'https://www.google.com/maps?q=' + encodeURIComponent('Plage du Santocha, Capbreton') + '&output=embed';
			f.title = 'Carte : plage du Santocha, Capbreton';
			f.loading = 'lazy';
			f.referrerPolicy = 'no-referrer-when-downgrade';
			box.appendChild(f);
			btn.parentNode.style.display = 'none';
		});
	});
})();
