/* Blocs du thème Holo Surf : aperçu rendu par le serveur dans l'éditeur. */
(function (wp) {
	var el = wp.element.createElement;
	var SSR = wp.serverSideRender;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var blocs = {
		'header': 'En-tête Holo Surf',
		'footer': 'Pied de page Holo Surf',
		'articles': 'Derniers articles',
		'blog-hero': 'En-tête du blog',
		'blog-list': 'Liste des articles',
		'article-intro': "Introduction de l'article",
		'article-toc': "Sommaire de l'article",
		'article-toc-mobile': 'Sommaire mobile',
		'author-box': 'Encart auteur',
		'related': 'À lire aussi',
		'search-form': 'Recherche'
	};
	Object.keys(blocs).forEach(function (k) {
		wp.blocks.registerBlockType('holo-surf/' + k, {
			apiVersion: 3,
			title: blocs[k],
			category: 'theme',
			icon: 'admin-site-alt3',
			supports: { html: false, reusable: false },
			edit: function (props) {
				return el('div', useBlockProps({ style: { pointerEvents: 'none' } }), el(SSR, { block: 'holo-surf/' + k, attributes: props.attributes }));
			},
			save: function () { return null; }
		});
	});
})(window.wp);
