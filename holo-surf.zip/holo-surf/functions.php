<?php
/**
 * Thème Holo Surf.
 *
 * @package holo-surf
 */

defined( 'ABSPATH' ) || exit;

define( 'HS_THEME_VERSION', '1.0.0' );

require get_theme_file_path( 'inc/helpers.php' );
require get_theme_file_path( 'inc/blocks.php' );

/**
 * Réglages du thème.
 */
function hs_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'disable-layout-styles' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	remove_theme_support( 'core-block-patterns' );
	add_editor_style( array( 'assets/css/maquette.css', 'assets/css/theme.css', 'assets/css/editor.css' ) );
	register_nav_menus(
		array(
			'principal'  => 'Menu principal',
			'pied-cours' => 'Pied de page : Les cours',
			'pied-infos' => 'Pied de page : Infos surf',
			'pied-spots' => 'Pied de page : Les spots',
			'pied-legal' => 'Pied de page : liens légaux',
		)
	);
}
add_action( 'after_setup_theme', 'hs_setup' );

/**
 * Styles et scripts du site.
 */
function hs_assets() {
	$v = HS_THEME_VERSION;
	wp_enqueue_style( 'holo-surf-maquette', hs_asset( 'css/maquette.css' ), array(), $v );
	wp_enqueue_style( 'holo-surf-blocs', hs_asset( 'css/blocks.css' ), array( 'holo-surf-maquette' ), $v );
	wp_enqueue_style( 'holo-surf', hs_asset( 'css/theme.css' ), array( 'holo-surf-blocs' ), $v );
	wp_enqueue_script( 'holo-surf', hs_asset( 'js/site.js' ), array(), $v, array( 'strategy' => 'defer', 'in_footer' => true ) );
	// La mise en page vient entièrement du thème : la feuille générique des blocs n'est pas chargée.
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'classic-theme-styles' );
}
add_action( 'wp_enqueue_scripts', 'hs_assets', 20 );
add_filter( 'should_load_separate_core_block_assets', '__return_false' );

/**
 * Préchargement des polices principales.
 */
function hs_preload_fonts() {
	foreach ( array( 'bebas-neue-latin-400-normal', 'barlow-latin-400-normal' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( hs_asset( 'fonts/' . $f . '.woff2' ) ) );
	}
}
add_action( 'wp_head', 'hs_preload_fonts', 1 );

function hs_theme_color() {
	echo '<meta name="theme-color" content="#192A33">' . "\n";
}
add_action( 'wp_head', 'hs_theme_color', 2 );

/**
 * Script de l'éditeur pour les blocs du thème.
 */
function hs_editor_script() {
	wp_register_script( 'holo-surf-editor', hs_asset( 'js/editor.js' ), array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor' ), HS_THEME_VERSION, true );
}
add_action( 'init', 'hs_editor_script', 5 );

/**
 * Les textes gardent leur typographie d'origine (espaces insécables, apostrophes).
 */
add_filter( 'run_wptexturize', '__return_false' );

/**
 * Classes du body : page de la maquette et barre d'actions mobile.
 */
function hs_body_class( $classes ) {
	$key = hs_current_key();
	if ( $key ) {
		$classes[] = 'hs-k-' . strtolower( $key );
	}
	if ( 'Contact' !== $key ) {
		$classes[] = 'hasbar';
	}
	return $classes;
}
add_filter( 'body_class', 'hs_body_class' );

/**
 * Catégorie de compositions.
 */
function hs_pattern_category() {
	register_block_pattern_category( 'holo-surf', array( 'label' => 'Holo Surf' ) );
	register_block_pattern_category( 'holo-surf-pages', array( 'label' => 'Holo Surf : sections des pages' ) );
}
add_action( 'init', 'hs_pattern_category', 9 );

/**
 * Taille d'image adaptée aux cartes d'articles.
 */
add_filter(
	'big_image_size_threshold',
	function () {
		return 2000;
	}
);
