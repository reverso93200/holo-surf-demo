<?php
/**
 * Title: Infos surf : Hero
 * Slug: holo-surf/infos-surf-hero
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-6543c4"} -->
<section class="wp-block-group u-6543c4">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kb ui-4a3c4f"} -->
<figure class="wp-block-image size-full kb ui-4a3c4f"><img src="<?php echo esc_url( hs_img( 'a67cb1a03e4015e525f7e0eb9f452cc5' ) ); ?>" alt="Une vague à Hossegor avec les Pyrénées à l'horizon"/></figure>
<!-- /wp:image -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(180deg, rgba(25,42,51,0.25) 20%, rgba(25,42,51,0.86) 100%)"></div>
<!-- /wp:html -->

<!-- wp:group {"className":"wrap u-8acf14"} -->
<div class="wp-block-group wrap u-8acf14">
<!-- wp:html -->
<nav aria-label="Fil d'Ariane" class="in crumb" style="margin-bottom: 22px; font-size: 14.5px; color: #C9D4D9"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #C9D4D9">Accueil</a> / <span aria-current="page" style="color: #FFFFFF">Infos surf</span></nav>
<!-- /wp:html -->

<!-- wp:heading {"level":1,"className":"in u-102208"} -->
<h1 class="wp-block-heading in u-102208">Webcam Capbreton</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 u-15a0f9"} -->
<p class="in d1 u-15a0f9">La plage du Santocha en direct, les prévisions surf et l'essentiel sur les baïnes et les vagues, à regarder avant d'aller à l'eau.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d1 u-495ac5"} -->
<p class="in d1 u-495ac5">[holo_mise_a_jour]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d2 anch u-e90f6f"} -->
<p class="in d2 anch u-e90f6f"><a class="lnk" href="#webcam" style="font-weight: 400; color: #FFFFFF">Webcam</a><a class="lnk" href="#lire-webcam" style="font-weight: 400; color: #FFFFFF">Lire la webcam</a><a class="lnk" href="#previsions" style="font-weight: 400; color: #FFFFFF">Prévisions surf</a><a class="lnk" href="#baines" style="font-weight: 400; color: #FFFFFF">Les baïnes</a><a class="lnk" href="#vagues" style="font-weight: 400; color: #FFFFFF">Les vagues</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: -1px; height: 40px; overflow: hidden">
<svg class="wave" preserveAspectRatio="none" style="position: absolute; left: 0; bottom: 0; width: 200%; height: 40px" viewBox="0 0 2880 64"><path d="M0 32 C120 12 240 12 360 32 S600 52 720 32 S960 12 1080 32 S1320 52 1440 32 S1680 12 1800 32 S2040 52 2160 32 S2400 12 2520 32 S2760 52 2880 32 V64 H0 Z" fill="#FFFFFF"></path></svg>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
