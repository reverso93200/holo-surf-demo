<?php
/**
 * Title: Location : Guide SEO
 * Slug: holo-surf/location-guide-seo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-503146"} -->
<section id="guide" class="wp-block-group u-503146">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"stick reveal u-67a893"} -->
<div class="wp-block-group stick reveal u-67a893">
<!-- wp:heading {"className":"h2"} -->
<h2 id="guide-t" class="wp-block-heading h2">Bien choisir sa location de surf à Capbreton</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Mousse ou hybride, 3/2 ou 4/3, deux heures ou deux jours : ce qu'il faut savoir avant de louer.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver mon matériel</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-f6967f"} -->
<div class="wp-block-group u-f6967f">
<!-- wp:group {"className":"seo fold"} -->
<div id="seo-s1" class="wp-block-group seo fold">
<!-- wp:paragraph -->
<p>La location Holo Surf vous équipe pour aller surfer à Capbreton sans transporter votre matériel : planches en mousse Ocean Storm et Zeus, planches hybrides et combinaisons Hurricane, à l'heure, à la journée ou pour plusieurs jours. Voici comment choisir selon votre niveau, la saison et les vagues du jour.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Planche en mousse ou hybride ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La planche en mousse reste la meilleure planche pour débuter et pour les premières sessions en autonomie. Son volume la rend stable et facile à ramer, ce qui permet de prendre plus de vagues, et son revêtement souple limite les risques de blessure en cas de chute. Les modèles Ocean Storm et Zeus ont de la résine à l'intérieur : ils gardent le confort d'une mousse tout en étant plus rigides, donc plus vivants sur la vague.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>La planche hybride est l'étape suivante. Plus réactive, elle garde du volume et un revêtement en mousse plus sécurisant qu'une planche en résine. Elle s'adresse aux surfeurs qui vont chercher les vagues au large et veulent un peu plus de manœuvrabilité pour prendre de la vitesse et tracer leurs premières courbes.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Si vous hésitez entre les deux, prenez la mousse. On progresse plus vite sur une planche qui pardonne les erreurs que sur une planche trop exigeante.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quelle taille de planche ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Plus vous débutez, plus il vous faut de volume. Une planche longue et épaisse flotte mieux, se rame plus facilement et reste stable au moment de se lever. Le gabarit compte aussi : à niveau égal, un surfeur plus grand ou plus lourd a besoin de plus de volume. Au moment de réserver, indiquez votre taille, votre poids et votre niveau pour être orienté vers la bonne planche.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quelle combinaison selon la saison ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>L'eau des Landes passe d'environ 12 °C en hiver à plus de 20 °C au cœur de l'été. L'épaisseur d'une combinaison s'exprime en millimètres : le premier chiffre correspond au torse, le second aux bras et aux jambes, plus fins pour garder de la souplesse.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>En été, une combinaison 2/2 à manches courtes suffit le plus souvent.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Au printemps et à l'automne, la 3/2 est la plus polyvalente.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>En hiver, passez à la 4/3 et ajoutez des chaussons.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Une combinaison doit être bien ajustée : trop large, l'eau circule à l'intérieur et vous refroidit ; trop serrée, elle gêne pour ramer. Les combinaisons de l'école existent pour femmes, hommes et enfants, en plusieurs tailles. Elles sont entretenues et renouvelées régulièrement pour garantir hygiène et performance.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Combien de temps louer ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Une session dure rarement plus de deux heures pour un débutant : ramer fatigue vite, et c'est quand on est fatigué qu'on prend des risques. La location de deux heures convient donc à la plupart des sessions. La demi-journée et la journée laissent le temps de surfer deux fois, à la marée qui vous convient. Si vous restez plusieurs jours, la formule deux jours puis le jour supplémentaire reviennent bien moins cher que plusieurs locations à l'heure.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Surfer en sécurité avec du matériel de location</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Si vous débutez, ne partez jamais seul et restez là où vous avez pied.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Renseignez-vous sur les <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#baines">courants de baïne</a> avant d'aller à l'eau, et demandez conseil aux sauveteurs en cas de doute.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Regardez la <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>">webcam de Capbreton</a> et les prévisions pour choisir le bon moment.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>En été, surfez dans les zones réservées au surf, en dehors des zones de baignade.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Attachez le leash à la cheville du pied arrière, et ne lâchez jamais votre planche : elle peut blesser un autre surfeur.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Respectez les priorités : le surfeur le plus proche du pic, là où la vague casse en premier, est prioritaire.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Location ou cours ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Si vous n'avez jamais surfé, commencez par un <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">cours de surf à Capbreton</a>. Le matériel est compris, vous apprenez les bons gestes dès le départ et vous évitez les erreurs qui font perdre du temps, ou qui mettent en danger. La location prend le relais quand vous savez vous lever, choisir une plage et repérer les courants. Pour savoir où aller, notre guide des <a href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>">spots de surf de Capbreton, Hossegor et Seignosse</a> indique le niveau conseillé pour chaque plage.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Réserver votre matériel</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Écrivez à Paul ou appelez-le en précisant le matériel souhaité, les tailles et les dates. Il vous confirme la disponibilité et le lieu de retrait.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
