<?php
/**
 * Title: Les spots : FAQ
 * Slug: holo-surf/spots-faq
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-1b92fa"} -->
<section class="wp-block-group u-1b92fa">
<!-- wp:group {"className":"wrap u-0a2e57"} -->
<div class="wp-block-group wrap u-0a2e57">
<!-- wp:heading {"className":"h2 reveal u-919b25"} -->
<h2 class="wp-block-heading h2 reveal u-919b25">Questions fréquentes sur les spots</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"faq reveal u-194198"} -->
<div class="wp-block-group faq reveal u-194198">
<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>Quel est le meilleur spot de surf à Capbreton pour débuter ?</summary>
<!-- wp:paragraph -->
<p>Le Santocha, La Centrale et Le Prévent, par petite ou moyenne houle : pente douce, vagues qui déferlent en mousse et courants généralement modérés. C'est au Santocha qu'ont lieu la plupart des cours de l'école.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Où surfer quand les vagues sont trop grosses ?</summary>
<!-- wp:paragraph -->
<p>Sur les spots plus abrités : La Centrale et Le Prévent à Capbreton, prisés quand ça rentre gros ailleurs, ou La Sud à Hossegor, protégée des grosses houles. Ils sont alors très fréquentés : patience et respect des priorités.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Où trouver des vagues quand la houle est petite ?</summary>
<!-- wp:paragraph -->
<p>Les Estagnots, à Seignosse, captent plus de houle que les plages voisines. Les jours calmes, c'est souvent là que les vagues sont les plus grosses du secteur.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Les plages sont-elles surveillées ?</summary>
<!-- wp:paragraph -->
<p>En été, les principales plages de Capbreton, Hossegor et Seignosse sont surveillées, avec des zones de baignade et des zones de surf séparées. Hors saison, il n'y a pas de surveillance : ne surfez jamais seul si vous débutez.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Peut-on surfer toute l'année à Capbreton ?</summary>
<!-- wp:paragraph -->
<p>Oui. L'eau descend autour de 12 °C en hiver, ce qui demande une combinaison 4/3 et des chaussons, mais les vagues sont souvent plus belles d'octobre à avril. Les houles d'hiver sont aussi plus puissantes : choisissez votre plage avec soin.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Où ont lieu les cours de Holo Surf ?</summary>
<!-- wp:paragraph -->
<p>Généralement au Santocha, à Capbreton. L'école est itinérante : selon la houle et votre niveau, Paul peut vous emmener à Hossegor ou à Seignosse. Vous connaissez le lieu à l'avance.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
