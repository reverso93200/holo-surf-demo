<?php
/**
 * Title: Accueil : Réassurance
 * Slug: holo-surf/accueil-reassurance
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-99cf07"} -->
<section class="wp-block-group u-99cf07">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:list {"className":"trust reveal"} -->
<ul class="wp-block-list trust reveal"><!-- wp:list-item -->
<li><span class="tr-t">Moniteur diplômé</span><span class="tr-d">Paul encadre lui-même chaque cours</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t">Matériel compris</span><span class="tr-d">Planche, combinaison et assurance</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t">Dès 5 ans</span><span class="tr-d">Enfants, ados et adultes</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t">Label Ecosafe</span><span class="tr-d">Sécurité et respect du littoral</span></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
