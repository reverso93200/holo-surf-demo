<?php
/**
 * Title: Les cours et tarifs : Intro
 * Slug: holo-surf/cours-intro
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-2885f3"} -->
<section class="wp-block-group u-2885f3">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:html -->
<nav aria-label="Fil d'Ariane" class="crumb" style="font-size: 14.5px; color: #55636A"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #55636A">Accueil</a> / <span aria-current="page" style="color: #192A33">Les cours et tarifs</span></nav>
<!-- /wp:html -->

<!-- wp:group {"className":"u-cb2445"} -->
<div class="wp-block-group u-cb2445">
<!-- wp:group {"className":"u-8d7a8c"} -->
<div class="wp-block-group u-8d7a8c">
<!-- wp:heading {"level":1,"className":"in u-1a54f7"} -->
<h1 class="wp-block-heading in u-1a54f7">Cours de surf à Capbreton</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 kicker u-3c5e3c"} -->
<p class="in d1 kicker u-3c5e3c">Formules et tarifs [holo_info k="annee_tarifs"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d1 u-31f682"} -->
<p class="in d1 u-31f682">Une école de surf itinérante à taille humaine, avec un accompagnement passionné dans et hors de l'eau. Ici, on va au-delà de la technique : apprendre à lire l'océan, comprendre son environnement et surfer en toute sécurité.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d2 anch u-26b8d7"} -->
<p class="in d2 anch u-26b8d7"><a class="lnk" href="#collectifs" style="font-weight: 400">Cours collectifs</a><a class="lnk" href="#particuliers" style="font-weight: 400">Cours particuliers</a><a class="lnk" href="#coaching" style="font-weight: 400">Coaching vidéo</a><a class="lnk" href="#sur-mesure" style="font-weight: 400">Sur mesure</a><a class="lnk" href="#guide" style="font-weight: 400">Bien choisir</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"in d2 zoom u-45c29d"} -->
<div class="wp-block-group in d2 zoom u-45c29d">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"mimg-s ui-7c8e4b"} -->
<figure class="wp-block-image size-full mimg-s ui-7c8e4b"><img src="<?php echo esc_url( hs_img( 'd7998c9e816d82c8acf6c8b945419594' ) ); ?>" alt="Paul encourage une élève debout sur sa planche"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
