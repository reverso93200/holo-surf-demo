<?php
/**
 * Title: Mentions légales : section
 * Slug: holo-surf/mentions-legales-section
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-a9c210"} -->
<section class="wp-block-group u-a9c210">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"lg u-a4d899"} -->
<div class="wp-block-group lg u-a4d899">
<!-- wp:group {"className":"lg-panel"} -->
<div id="mentions" class="wp-block-group lg-panel">
<!-- wp:paragraph {"className":"u-2f4220"} -->
<p class="u-2f4220">Holo Surf Capbreton est une école de surf proposant des cours collectifs, des cours particuliers et du coaching vidéo. Les cours ont lieu principalement à la plage du Santocha et peuvent se dérouler sur d'autres plages selon les conditions, le niveau et les objectifs des élèves.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">1. Éditeur du site</h2>
<!-- /wp:heading -->

<!-- wp:html -->
<dl>
<div><dt>Raison sociale</dt><dd>Holo Surf Capbreton</dd></div>
<div><dt>Statut</dt><dd>Auto-entreprise</dd></div>
<div><dt>Siège</dt><dd>[holo_adresse]</dd></div>
<div><dt>SIRET</dt><dd>911 735 546 00028</dd></div>
<div><dt>Directeur de la publication</dt><dd>Paul Roquier</dd></div>
<div><dt>Contact</dt><dd>[holo_info k="email"], [holo_info k="telephone"]</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2. Hébergement</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>[holo_hebergeur]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">3. Propriété intellectuelle</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sauf mention contraire, l'ensemble des contenus du site appartient à Holo Surf Capbreton. Toute reproduction ou utilisation sans autorisation est interdite.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">4. Données personnelles</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les données transmises via les formulaires du site sont utilisées uniquement par Holo Surf Capbreton et ne sont jamais vendues. Vous pouvez y accéder, les rectifier ou demander leur suppression par e-mail.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">5. Cookies</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site peut utiliser des cookies à des fins de statistiques et d'amélioration de l'expérience. Vous pouvez les refuser depuis les paramètres de votre navigateur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">6. Responsabilité</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Holo Surf Capbreton veille à l'exactitude des informations publiées mais ne peut être tenu responsable des erreurs ou omissions. L'utilisation du site se fait sous la responsabilité de l'utilisateur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">7. Droit applicable</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les présentes mentions sont soumises au droit français. Tout litige relève des tribunaux de Dax.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="cookies" class="wp-block-group lg-panel">
<!-- wp:paragraph {"className":"u-2f4220"} -->
<p class="u-2f4220">Cette page explique quels cookies et traceurs le site holosurfcapbreton.com utilise, et comment garder la main sur les contenus d'autres services qui peuvent en déposer.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">1. Ce qu'est un cookie</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Un cookie est un petit fichier enregistré par votre navigateur quand vous consultez un site. Il peut servir au fonctionnement du site, à mesurer sa fréquentation ou à suivre votre navigation d'un site à l'autre.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2. Mesure d'audience sans cookie</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site compte ses visites avec Koko Analytics, une extension installée sur le serveur du site. Elle est réglée pour fonctionner sans cookie et sans enregistrer votre adresse IP : elle ne conserve que des totaux, comme le nombre de pages vues ou les sites d'où arrivent les visiteurs. Aucune donnée n'est transmise à un service extérieur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">3. Cookies techniques</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site ne dépose aucun cookie publicitaire. Des cookies techniques de WordPress sont déposés uniquement lorsque l'équipe de l'école se connecte à l'administration du site. Les visiteurs ne sont pas concernés.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">4. Contenus d'autres services, chargés à votre demande</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Certaines pages proposent des contenus fournis par d'autres sites. Rien n'est chargé tant que vous ne cliquez pas sur le bouton prévu :</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>la carte Google de la plage du Santocha (bouton « Afficher la carte »), fournie par Google : <a href="https://policies.google.com/privacy?hl=fr" rel="noopener">règles de confidentialité de Google</a> ;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>le tableau de prévisions Windguru (bouton « Afficher les prévisions »), fourni par Windguru : <a href="https://www.windguru.cz/help.php?sec=privacy" rel="noopener">politique de confidentialité de Windguru</a> ;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>la vignette des marées du SHOM (bouton « Afficher les marées ») : <a href="https://diffusion.shom.fr/donnees-personnelles" rel="noopener">données personnelles sur le site du SHOM</a>.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>En cliquant, votre navigateur se connecte au service concerné, qui reçoit votre adresse IP et peut déposer ses propres cookies selon sa politique. Si vous ne cliquez pas, aucun échange n'a lieu avec ces services. Le choix vaut pour la page affichée : rien n'est mémorisé.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">5. Liens vers les réseaux sociaux</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les icônes Instagram, Facebook et WhatsApp sont de simples liens. Elles ne chargent aucun contenu de ces réseaux tant que vous ne cliquez pas dessus.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">6. Gérer les cookies dans votre navigateur</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Vous pouvez à tout moment consulter, bloquer ou supprimer les cookies depuis les réglages de votre navigateur. Le site reste entièrement consultable sans cookie.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="confidentialite" class="wp-block-group lg-panel">
<!-- wp:paragraph {"className":"u-2f4220"} -->
<p class="u-2f4220">Holo Surf Capbreton respecte vos données. Cette page décrit les informations recueillies sur le site, ce qu'elles deviennent et les droits dont vous disposez, conformément au règlement général sur la protection des données (RGPD) et à la loi Informatique et Libertés.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">1. Responsable du traitement</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Holo Surf Capbreton, auto-entreprise de Paul Roquier, SIRET 911 735 546 00028, [holo_adresse]. Contact : [holo_email].</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2. Le formulaire de réservation</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Quand vous écrivez à Paul depuis le site, le formulaire recueille : votre prénom, votre nom, votre adresse e-mail, votre numéro de téléphone, la formule qui vous intéresse, la date souhaitée, le nombre de surfeurs, le niveau et votre message.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Ces informations servent uniquement à répondre à votre demande et à organiser votre cours. La base légale est l'exécution de mesures précontractuelles prises à votre demande (article 6, paragraphe 1, point b du RGPD).</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Votre demande est envoyée par e-mail à l'adresse de l'école.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Elle est aussi enregistrée dans l'administration du site WordPress, accessible seulement à l'école et à son prestataire technique.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Vous recevez aussitôt un e-mail « Demande bien reçue » qui récapitule votre demande.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Les demandes enregistrées sur le site sont supprimées automatiquement au bout de [holo_conservation] mois. Le formulaire ne fait appel à aucun service anti-robot extérieur : un champ invisible et un délai minimal suffisent, sans transmission à un tiers.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">3. Destinataires</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Vos informations ne sont lues que par Paul. Elles ne sont jamais vendues ni cédées. Les prestataires techniques qui font fonctionner le site et la messagerie de l'école y ont accès dans la limite de leur mission : l'hébergeur du site ([holo_hebergeur]) et le fournisseur de la messagerie de l'école.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">4. Mesure d'audience</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La fréquentation du site est mesurée avec Koko Analytics, installé sur le serveur du site, sans cookie et sans enregistrement de votre adresse IP. Seuls des totaux anonymes sont conservés (pages vues, sites d'origine).</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">5. Contenus d'autres services</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La carte Google, les prévisions Windguru et les marées du SHOM ne se chargent que si vous cliquez sur le bouton correspondant. Le détail figure dans l'onglet Politique en matière de cookies.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">6. Vos droits</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Vous pouvez demander l'accès à vos données, leur rectification, leur effacement ou la limitation de leur traitement, vous opposer à leur traitement et demander leur portabilité. Écrivez à [holo_email] ou à l'adresse ci-dessus. Une réponse vous est apportée dans un délai d'un mois.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Si vous estimez que vos droits ne sont pas respectés, vous pouvez adresser une réclamation à la CNIL, en ligne sur <a href="https://www.cnil.fr/fr/plaintes" rel="noopener">cnil.fr/fr/plaintes</a> ou par courrier : Commission nationale de l'informatique et des libertés, Service des plaintes, 3 Place de Fontenoy, 75007 Paris.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="conditions" class="wp-block-group lg-panel">
<!-- wp:paragraph {"className":"u-2f4220"} -->
<p class="u-2f4220">Les présentes conditions encadrent l'utilisation du site holosurfcapbreton.com, édité par Holo Surf Capbreton. En naviguant sur le site, vous les acceptez.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">1. Objet du site</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site présente l'école de surf Holo Surf Capbreton, ses cours, ses tarifs, la location de matériel et des informations sur le surf à Capbreton, Hossegor et Seignosse. Son accès est gratuit.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2. Demandes de réservation</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Il n'y a pas de réservation en ligne. Le formulaire permet d'envoyer une demande à Paul : elle ne vaut pas réservation. Le cours est confirmé par e-mail, avec le créneau, le lieu et le tarif. Les tarifs affichés sur le site sont ceux en vigueur ; le tarif appliqué est celui confirmé lors de la réservation.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">3. Informations sur les conditions de surf</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les informations sur les plages, les marées, les prévisions et les courants sont données à titre indicatif. Elles ne remplacent ni les consignes des nageurs sauveteurs ni les drapeaux de baignade. Les prévisions Windguru et les horaires de marée du SHOM restent sous la responsabilité de leurs éditeurs.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">4. Propriété intellectuelle</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sauf mention contraire, l'ensemble des contenus du site (textes, photos, logo) appartient à Holo Surf Capbreton. Toute reproduction ou utilisation sans autorisation est interdite.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">5. Liens vers d'autres sites</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site contient des liens vers d'autres sites, dont Holo Surf Capbreton ne contrôle pas le contenu et n'est pas responsable.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">6. Responsabilité et disponibilité</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Holo Surf Capbreton veille à l'exactitude des informations publiées et à la disponibilité du site, sans pouvoir garantir l'absence d'erreur ou d'interruption. L'utilisation du site se fait sous la responsabilité de l'utilisateur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">7. Données personnelles</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le traitement de vos données est décrit dans l'onglet Politique de confidentialité.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">8. Droit applicable</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les présentes conditions sont soumises au droit français. Tout litige relève des tribunaux de Dax.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">9. Contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Pour toute question : [holo_email], [holo_tel].</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"aside","className":"u-ece8be"} -->
<aside class="wp-block-group u-ece8be">
<!-- wp:paragraph {"className":"u-5bfe98"} -->
<p class="u-5bfe98">Une question sur vos données ?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"u-86999f"} -->
<p class="u-86999f">Écrivez à [holo_email style="color: #FFFFFF"]</p>
<!-- /wp:paragraph -->
</aside>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
