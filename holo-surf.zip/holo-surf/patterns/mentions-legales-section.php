<?php
/**
 * Title: Mentions légales : section
 * Slug: holo-surf/mentions-legales-section
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-a9c210"} -->
<section class="wp-block-group u-a9c210">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"lg u-a4d899"} -->
<div class="wp-block-group lg u-a4d899">
<!-- wp:group {"className":"lg-panel"} -->
<div id="mentions" class="wp-block-group lg-panel">
<!-- wp:paragraph {"className":"u-2f4220"} -->
<p class="u-2f4220">Holo Surf Capbreton est une école de surf proposant des cours collectifs, des cours particuliers et du coaching vidéo. Les cours ont lieu principalement à la plage du Santocha et peuvent se dérouler sur d'autres plages selon les conditions, le niveau et les objectifs des élèves.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">1. Éditeur du site</h2>
<!-- /wp:heading -->

<!-- wp:html -->
<dl>
<div><dt>Raison sociale</dt><dd>Holo Surf Capbreton</dd></div>
<div><dt>Statut</dt><dd>Auto-entreprise</dd></div>
<div><dt>Siège</dt><dd>[holo_adresse]</dd></div>
<div><dt>SIRET</dt><dd>911 735 546 00028</dd></div>
<div><dt>Directeur de la publication</dt><dd>Paul Roquier</dd></div>
<div><dt>Contact</dt><dd>[holo_info k="email"], [holo_info k="telephone"]</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2. Hébergement</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>[Hébergeur du site WordPress : raison sociale, adresse et téléphone, à compléter à la mise en ligne.]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">3. Propriété intellectuelle</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sauf mention contraire, l'ensemble des contenus du site appartient à Holo Surf Capbreton. Toute reproduction ou utilisation sans autorisation est interdite.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">4. Données personnelles</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les données transmises via les formulaires du site sont utilisées uniquement par Holo Surf Capbreton et ne sont jamais vendues. Vous pouvez y accéder, les rectifier ou demander leur suppression par e-mail.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">5. Cookies</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le site peut utiliser des cookies à des fins de statistiques et d'amélioration de l'expérience. Vous pouvez les refuser depuis les paramètres de votre navigateur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">6. Responsabilité</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Holo Surf Capbreton veille à l'exactitude des informations publiées mais ne peut être tenu responsable des erreurs ou omissions. L'utilisation du site se fait sous la responsabilité de l'utilisateur.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">7. Droit applicable</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les présentes mentions sont soumises au droit français. Tout litige relève des tribunaux de Dax.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="cookies" class="wp-block-group lg-panel">
<!-- wp:group {"className":"u-8fd83d"} -->
<div class="wp-block-group u-8fd83d">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span style="font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #85652A">Texte actuel de la page</span>
<span style="font-size: 15px; color: #55636A">Mentions légales, repris tel quel dans cette mise en page</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="confidentialite" class="wp-block-group lg-panel">
<!-- wp:group {"className":"u-8fd83d"} -->
<div class="wp-block-group u-8fd83d">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span style="font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #85652A">Texte actuel de la page</span>
<span style="font-size: 15px; color: #55636A">Mentions légales, repris tel quel dans cette mise en page</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"lg-panel"} -->
<div id="conditions" class="wp-block-group lg-panel">
<!-- wp:group {"className":"u-8fd83d"} -->
<div class="wp-block-group u-8fd83d">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span style="font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #85652A">Texte actuel de la page</span>
<span style="font-size: 15px; color: #55636A">Mentions légales, repris tel quel dans cette mise en page</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"aside","className":"u-ece8be"} -->
<aside class="wp-block-group u-ece8be">
<!-- wp:paragraph {"className":"u-5bfe98"} -->
<p class="u-5bfe98">Une question sur vos données ?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"u-86999f"} -->
<p class="u-86999f">Écrivez à [holo_email style="color: #FFFFFF"]</p>
<!-- /wp:paragraph -->
</aside>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
