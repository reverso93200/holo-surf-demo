<?php
/**
 * Title: Infos surf : Baïnes
 * Slug: holo-surf/infos-surf-baines
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-c55f2c"} -->
<section id="baines" class="wp-block-group u-c55f2c">
<!-- wp:group {"className":"wrap u-653ddb"} -->
<div class="wp-block-group wrap u-653ddb">
<!-- wp:group {"className":"reveal u-588d45"} -->
<div class="wp-block-group reveal u-588d45">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Les courants de baïnes</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-1d08f6"} -->
<p class="u-1d08f6">Sur les plages de sable des Landes, les baïnes sont des courants qui entraînent nageurs et surfeurs vers le large. Elles sont l'une des premières causes de sauvetage en mer.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-0dc91c"} -->
<p class="p u-0dc91c">Les vagues déferlent sur les bancs de sable. L'eau accumulée près du bord repart ensuite vers le large par les passages entre ces bancs : c'est là que le courant se forme.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"h3 u-db8ccc"} -->
<h3 class="wp-block-heading h3 u-db8ccc">Pris dans une baïne ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-bccd11"} -->
<p class="p u-bccd11">Restez calme et restez à la surface. Si vous avez une planche, restez dessus : elle vous fait flotter. Ne nagez pas contre le courant, il finit par faiblir.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<figure class="reveal" style="flex: 1 1 460px; min-width: 0; margin: 0">
<svg aria-label="Schéma d'une baïne : l'eau ramenée par les vagues repart vers le large par le passage entre deux bancs de sable" role="img" style="width: 100%; height: auto; display: block" viewBox="0 0 520 500">
<rect fill="#2E5F73" height="500" width="520" x="0" y="0"></rect>
<g class="swell"><path d="M0 60 C60 44 120 44 180 60 S300 76 360 60 S460 44 520 60" fill="none" stroke="#9CC3D1" stroke-width="3"></path><path d="M0 110 C60 94 120 94 180 110 S300 126 360 110 S460 94 520 110" fill="none" stroke="#9CC3D1" stroke-width="3"></path></g>
<path d="M20 230 C60 190 170 185 205 225 C220 245 210 275 180 285 C120 300 40 290 20 270 Z" fill="#C9B48A"></path>
<path d="M315 225 C350 185 460 190 500 230 L500 270 C480 290 400 300 340 285 C310 275 300 245 315 225 Z" fill="#C9B48A"></path>
<path d="M0 390 C120 370 400 370 520 390 L520 500 L0 500 Z" fill="#E9D9B4"></path>
<path d="M150 352 C200 342 230 330 252 310 M370 352 C320 342 290 330 268 310" fill="none" stroke="#FFFFFF" stroke-dasharray="2 8" stroke-linecap="round" stroke-width="3"></path>
<path class="flow" d="M260 320 L260 120" stroke="#D4AA63" stroke-linecap="round" stroke-width="10"></path>
<path d="M238 140 L260 100 L282 140 Z" fill="#D4AA63"></path>
<text fill="#192A33" font-family="Barlow, sans-serif" font-size="15" font-weight="700" text-anchor="middle" x="112" y="250">Banc de sable</text>
<text fill="#192A33" font-family="Barlow, sans-serif" font-size="15" font-weight="700" text-anchor="middle" x="408" y="250">Banc de sable</text>
<text fill="#FFFFFF" font-family="Barlow, sans-serif" font-size="16" font-weight="700" x="300" y="190">Baïne</text>
<text fill="#192A33" font-family="Barlow, sans-serif" font-size="16" font-weight="700" text-anchor="middle" x="260" y="455">Plage</text>
<text fill="#FFFFFF" font-family="Barlow, sans-serif" font-size="14" font-weight="600" text-anchor="middle" x="260" y="36">Large</text>
</svg>
<figcaption style="margin-top: 12px; font-size: 14.5px; color: #55636A">L'eau ramenée par les vagues repart vers le large par le chenal entre les bancs.</figcaption>
</figure>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
