<?php
/**
 * Title: À propos : Partenaires
 * Slug: holo-surf/a-propos-partenaires
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-f9970f"} -->
<section class="wp-block-group u-f9970f">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:heading {"className":"h2 reveal"} -->
<h2 id="part-t" class="wp-block-heading h2 reveal">Partenaires et matériel</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"trust reveal u-3d941b"} -->
<ul class="wp-block-list trust reveal u-3d941b"><!-- wp:list-item -->
<li><span class="tr-t">Ecosafe Surfing</span><span class="tr-d">Label qui associe sécurité des surfeurs et respect de l'environnement.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t">Ocean Storm</span><span class="tr-d">Les planches en mousse de la location et le lot du concours 2026.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t"><a href="https://waved-retreats.com" style="color: inherit; text-decoration: underline; text-decoration-color: #D4AA63; text-underline-offset: 4px">Waved Retreats</a></span><span class="tr-d">Paul est le coach surf de leurs retraites à Hossegor.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><span class="tr-t">Hurricane</span><span class="tr-d">Les combinaisons proposées à la location.</span></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
