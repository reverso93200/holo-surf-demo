<?php
/**
 * Title: Les cours et tarifs : Avis
 * Slug: holo-surf/cours-avis
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-48070e"} -->
<section class="wp-block-group u-48070e">
<!-- wp:group {"className":"wrap reveal u-a8f497"} -->
<div class="wp-block-group wrap reveal u-a8f497">
<!-- wp:heading {"className":"h2 u-6f4d96"} -->
<h2 class="wp-block-heading h2 u-6f4d96">L'avis de nos surfeurs</h2>
<!-- /wp:heading -->

<!-- wp:quote {"className":"u-97cd78"} -->
<blockquote class="wp-block-quote u-97cd78">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c">« Une organisation remarquable et une grande souplesse. Merci beaucoup, Paul, pour ta joie de vivre communicative, ta pédagogie et le partage généreux de ta passion qui a su faire germer la graine de deux futurs passionnés. »</p>
<!-- /wp:paragraph -->
</blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph {"className":"u-2ffa33"} -->
<p class="u-2ffa33">Guillaume</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
