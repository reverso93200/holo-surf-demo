<?php
/**
 * Title: Les cours et tarifs : Avis
 * Slug: holo-surf/cours-avis
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-48070e"} -->
<section class="wp-block-group u-48070e">
<!-- wp:group {"className":"wrap reveal u-a8f497"} -->
<div class="wp-block-group wrap reveal u-a8f497">
<!-- wp:shortcode -->
[holo_avis variante="simple"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
