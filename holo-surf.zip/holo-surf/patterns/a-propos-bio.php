<?php
/**
 * Title: À propos : Bio
 * Slug: holo-surf/a-propos-bio
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-1b92fa"} -->
<section class="wp-block-group u-1b92fa">
<!-- wp:group {"className":"wrap u-bbce1c"} -->
<div class="wp-block-group wrap u-bbce1c">
<!-- wp:heading {"className":"h2 reveal stick u-7fd512"} -->
<h2 class="wp-block-heading h2 reveal stick u-7fd512">Ma façon d'enseigner le surf</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"reveal u-8d7a8c"} -->
<div class="wp-block-group reveal u-8d7a8c">
<!-- wp:group {"className":"seo fold"} -->
<div id="seo-sa" class="wp-block-group seo fold">
<!-- wp:paragraph -->
<p>Moniteur de surf diplômé, j'ai créé Holo Surf à Capbreton pour transmettre le surf comme je le vis : un sport, mais surtout une façon de vivre avec l'océan. Voici ce qui guide chacun de mes cours.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Apprendre l'océan avant d'apprendre la vague</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Savoir se lever sur une planche ne suffit pas pour surfer. Il faut comprendre ce qui se passe autour de soi : d'où viennent les vagues, pourquoi elles cassent à cet endroit, où l'eau repart vers le large. À chaque cours, on prend le temps d'observer la mer avant d'y entrer. Peu à peu, vous apprenez à lire les courants, à anticiper les séries et à choisir vos vagues. C'est ce qui vous rendra autonome, bien plus que la technique seule.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Le plaisir comme moteur</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>On progresse plus vite quand on s'amuse. Mes cours sont exigeants sur la sécurité et la technique, mais l'ambiance reste détendue : on rit des chutes, on célèbre la première vague debout, on encourage ceux qui bloquent. Chacun avance à son rythme, et j'adapte les exercices à ce que je vois dans l'eau.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Des petits groupes, toujours</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Un cours collectif accueille huit surfeurs au maximum, un cours particulier quatre personnes du même groupe. Ce n'est pas un hasard : au-delà, il devient difficile de suivre chacun, de corriger une position ou de garder un œil sur tout le monde. Avec un groupe réduit, je peux donner un conseil précis à chaque surfeur, sur chaque vague.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Une école itinérante</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Holo Surf n'est pas attachée à une seule plage, et c'est un choix. Avant chaque séance, je regarde la houle, le vent et la marée pour emmener le groupe là où les vagues lui conviennent. Le plus souvent, on se retrouve au Santocha, mais si les conditions sont meilleures à Hossegor ou à Seignosse, on y va. Cela demande un peu plus d'organisation, et cela fait toute la différence dans l'eau.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">La sécurité, sans compromis</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les plages landaises sont magnifiques, et exigeantes. Chaque séance commence par un temps sur le sable consacré aux courants, aux baïnes et aux bons réflexes. Le matériel est adapté à chaque gabarit et l'assurance est comprise dans le prix. Pour les enfants, dès 5 ans, je choisis le spot et l'horaire selon la marée, et ils portent des lycras de couleur pour que je les repère d'un coup d'œil.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Le respect du littoral</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>L'école est labellisée Ecosafe Surfing. Concrètement, la préservation du littoral fait partie du cours au même titre que la technique : on emprunte les accès balisés pour ne pas abîmer la dune, on ne laisse rien derrière soi, et on explique pourquoi ces gestes simples comptent. C'est notre terrain de jeu, et nous n'en avons qu'un.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Le regard extérieur du coaching vidéo</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Quand on surfe, on ne se voit pas. Le coaching vidéo permet enfin de voir ce que l'on fait vraiment : je vous filme dans l'eau, puis on analyse vos vagues ensemble à la sortie. C'est souvent le déclic pour les surfeurs qui stagnent. Je suis aussi le coach surf des retraites Waved à Hossegor, avec la même approche : filmer, analyser, corriger.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Trois langues, un même accueil</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Je donne mes cours en français, en anglais et en espagnol. We speak English, hablamos español : les familles et les voyageurs étrangers sont les bienvenus, et je reste joignable 24h/24 et 7j/7 pour répondre à vos questions.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Envie de venir surfer avec moi ? Découvrez les <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">cours de surf à Capbreton</a> de l'école, ou <a href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>">écrivez-moi</a> pour réserver.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<dl class="facts">
<div><dt>Spot principal</dt><dd>Le Santocha, Capbreton</dd></div>
<div><dt>Langues</dt><dd>Français, anglais, espagnol</dd></div>
<div><dt>Cours</dt><dd>Collectifs, particuliers et coaching vidéo, dès 5 ans</dd></div>
<div><dt>Format</dt><dd>Séances de 1h30, matériel et assurance compris</dd></div>
<div><dt>Groupes</dt><dd>8 surfeurs maximum en collectif, 4 en particulier</dd></div>
<div><dt>Zone</dt><dd>Capbreton, Hossegor et Seignosse, selon la houle</dd></div>
<div><dt>Label</dt><dd>Ecosafe Surfing</dd></div>
<div><dt>Diplôme</dt><dd>BPJEPS Surf et sports associés</dd></div>
</dl>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
