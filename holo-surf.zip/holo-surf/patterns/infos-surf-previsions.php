<?php
/**
 * Title: Infos surf : Prévisions
 * Slug: holo-surf/infos-surf-previsions
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-afed12"} -->
<section id="previsions" class="wp-block-group u-afed12">
<!-- wp:group {"className":"wrap u-491820"} -->
<div class="wp-block-group wrap u-491820">
<!-- wp:group {"className":"reveal u-b6b9bc"} -->
<div class="wp-block-group reveal u-b6b9bc">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Prévisions surf</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-0de1f9"} -->
<p class="p u-0de1f9">Houle, période, vent et marée : regardez les conditions avant chaque session. En cours, c'est Paul qui choisit le spot selon le jour et votre niveau.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 28px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Emplacement prévu pour le widget de prévisions surf" class="reveal" role="img" style="flex: 1 1 560px; min-width: 0; min-height: 300px; border: 1.5px dashed #C9B88F; background: #FCF9F2; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; padding: 24px; box-sizing: border-box; text-align: center">
<span style="font-family: 'Bebas Neue', sans-serif; font-size: 32px; color: #85652A">Widget prévisions</span>
<span style="font-size: 15px; color: #55636A">Prévisions du Santocha, à intégrer</span>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
