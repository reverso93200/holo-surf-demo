<?php
/**
 * Title: Location : Sur le blog
 * Slug: holo-surf/location-sur-le-blog
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"hs-blog-sec u-7ea810"} -->
<section class="wp-block-group hs-blog-sec u-7ea810">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-458980"} -->
<div class="wp-block-group reveal u-458980">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"className":"h2"} -->
<h2 id="blog-t" class="wp-block-heading h2">Sur le blog</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Bien choisir son matériel et sa plage avant de louer.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Blog' ) ); ?>">Tous les articles</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:holo-surf/articles {"nombre":3,"titre":"h3"} /-->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
