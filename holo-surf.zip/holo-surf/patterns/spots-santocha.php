<?php
/**
 * Title: Les spots : Santocha
 * Slug: holo-surf/spots-santocha
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-56ab91"} -->
<section class="wp-block-group u-56ab91">
<!-- wp:group {"className":"wrap u-323c5d"} -->
<div class="wp-block-group wrap u-323c5d">
<!-- wp:paragraph {"className":"reveal leadb u-27a1f8"} -->
<p class="reveal leadb u-27a1f8">Les cours se déroulent généralement au Santocha, à Capbreton. Selon la houle et votre niveau, Paul peut vous emmener sur un autre spot.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"reveal u-55b9aa"} -->
<div class="wp-block-group reveal u-55b9aa">
<!-- wp:paragraph {"className":"p u-d06090"} -->
<p class="p u-d06090">Santocha, Capbreton, Hossegor ou Seignosse : on va là où les vagues conviennent à votre niveau.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 20px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
