<?php
/**
 * Title: À propos : Galerie
 * Slug: holo-surf/a-propos-galerie
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-bfa3ae"} -->
<section class="wp-block-group u-bfa3ae">
<!-- wp:group {"className":"wrap reveal u-458980"} -->
<div class="wp-block-group wrap reveal u-458980">
<!-- wp:heading {"className":"h2"} -->
<h2 id="galerie" class="wp-block-heading h2">Dans l'eau avec Holo</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="https://www.instagram.com/holosurfcapbreton/">@holosurfcapbreton</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"strip u-755074"} -->
<div class="wp-block-group strip u-755074">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( '17edbc4d06c815d93bce895ab0c1fe5d' ) ); ?>" alt="Un enfant debout sur sa planche à Capbreton"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( 'c6e90b27fe474c9ebd785e4276dfdeba' ) ); ?>" alt="Paul dans un tube aux Culs Nus"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( 'cfab3bf3216fad58ce90fb60649a54a6' ) ); ?>" alt="Des enfants rament avec Paul pendant un cours au Santocha"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( '364b827c81e2a9ff461ab7e676448788' ) ); ?>" alt="Deux surfeurs au coucher du soleil à Capbreton"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( '3b31185d96af976bfec3e210631bcb36' ) ); ?>" alt="Un tube aux Océanides à Capbreton"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( hs_img( '7c0cb50b1d57d0d2fc0badb0efec5fa2' ) ); ?>" alt="Paul accompagne des enfants dans les vagues du Santocha"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
