<?php
/**
 * Title: Les cours et tarifs : Cours particuliers
 * Slug: holo-surf/cours-cours-particuliers
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5dd5ac"} -->
<section id="particuliers" class="wp-block-group u-5dd5ac">
<!-- wp:group {"className":"wrap u-85a8d9"} -->
<div class="wp-block-group wrap u-85a8d9">
<!-- wp:group {"className":"reveal u-d1c8df"} -->
<div class="wp-block-group reveal u-d1c8df">
<!-- wp:shortcode -->
[holo_tarifs type="particulier"]
<!-- /wp:shortcode -->

<!-- wp:paragraph {"className":"p u-155f08"} -->
<p class="p u-155f08">Soit [holo_prix k="particulier_pp3"] par personne à partir de trois.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 24px">Réserver un cours particulier</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-7a0035"} -->
<div class="wp-block-group reveal u-7a0035">
<!-- wp:group {"className":"zoom"} -->
<div class="wp-block-group zoom">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-9753a5"} -->
<figure class="wp-block-image size-full ui-9753a5"><img src="<?php echo esc_url( hs_img( 'dabea7a64c36488fdd75a01412fbf2bf' ) ); ?>" alt="Paul guide une élève dans la vague pendant un cours particulier"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h2 u-3d941b"} -->
<h2 class="wp-block-heading h2 u-3d941b">Cours de surf particuliers</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-2d4996"} -->
<p class="u-2d4996">Progressez à votre rythme avec nos cours particuliers !</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Encadré par un moniteur diplômé, vous bénéficiez d'un accompagnement personnalisé pour apprendre ou perfectionner votre technique en toute sécurité. Cours d'1h30, jusqu'à 4 personnes du même groupe. Le prix inclut le matériel, ou vous venez avec le vôtre, et l'assurance.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Idéal pour un coaching sur mesure et une progression rapide.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
