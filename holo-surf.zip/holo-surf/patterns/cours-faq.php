<?php
/**
 * Title: Les cours et tarifs : FAQ
 * Slug: holo-surf/cours-faq
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-1b92fa"} -->
<section class="wp-block-group u-1b92fa">
<!-- wp:group {"className":"wrap u-0a2e57"} -->
<div class="wp-block-group wrap u-0a2e57">
<!-- wp:heading {"className":"h2 reveal u-919b25"} -->
<h2 class="wp-block-heading h2 reveal u-919b25">Questions fréquentes</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"faq reveal u-194198"} -->
<div class="wp-block-group faq reveal u-194198">
<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>Comment réserver mon cours ?</summary>
<!-- wp:paragraph -->
<p>Écrivez à Paul depuis la page Réserver mon cours ou à [holo_info k="email"], avec la formule, vos dates et votre niveau. Il vous répond par e-mail pour fixer le créneau.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Quelle différence entre basse et haute saison ?</summary>
<!-- wp:paragraph -->
<p>Les cours collectifs passent au tarif haute saison en juillet et août. Les cours particuliers et le coaching vidéo gardent le même prix toute l'année.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Puis-je venir avec mon propre matériel ?</summary>
<!-- wp:paragraph -->
<p>Oui, pour les cours particuliers et le coaching vidéo. Sinon, planche et combinaison sont fournies.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
