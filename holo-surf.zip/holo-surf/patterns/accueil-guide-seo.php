<?php
/**
 * Title: Accueil : Guide SEO
 * Slug: holo-surf/accueil-guide-seo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5dd5ac"} -->
<section id="ecole" class="wp-block-group u-5dd5ac">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"stick reveal u-67a893"} -->
<div class="wp-block-group stick reveal u-67a893">
<!-- wp:heading {"className":"h2"} -->
<h2 id="ecole-t" class="wp-block-heading h2">Une école de surf à Capbreton à taille humaine</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Un moniteur, des petits groupes et des cours qui suivent la houle : comment fonctionne Holo Surf, et pourquoi Capbreton est un bon endroit pour apprendre.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-f6967f"} -->
<div class="wp-block-group u-f6967f">
<!-- wp:group {"className":"seo fold oncream"} -->
<div id="seo-s1" class="wp-block-group seo fold oncream">
<!-- wp:paragraph -->
<p>Holo Surf est une école de surf itinérante basée à Capbreton, dans le sud des Landes. Paul encadre lui-même chaque cours, en groupes de huit surfeurs au maximum, et choisit chaque jour la plage où les vagues conviennent le mieux à votre niveau : le Santocha la plupart du temps, Hossegor ou Seignosse quand les conditions y sont meilleures. On y apprend à surfer, mais aussi à lire l'océan.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Une école de surf itinérante, concrètement</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Une école installée sur une seule plage y donne ses cours quelles que soient les conditions. Holo Surf fonctionne à l'inverse. Avant chaque séance, Paul regarde la houle, le vent et la marée, puis choisit le spot le plus adapté au groupe : un débutant n'a pas besoin des mêmes vagues qu'un surfeur qui travaille ses premiers virages. Le lieu et l'heure sont fixés avec vous par e-mail au moment de la réservation.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Le plus souvent, le rendez-vous est au Santocha. Cette plage de Capbreton offre une pente douce, des vagues régulières et, en général, des courants faibles : de bonnes conditions pour tenir debout longtemps et enchaîner les vagues. Le détail de chaque plage se trouve dans notre guide des <a href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>">spots de surf de Capbreton, Hossegor et Seignosse</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Des cours pour tous, dès 5 ans</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">cours de surf à Capbreton</a> de l'école se déclinent en quatre formules. Les cours durent 1h30, matériel et assurance compris.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Le cours collectif, jusqu'à huit surfeurs, pour découvrir le surf ou progresser dans une ambiance conviviale. [holo_prix k="collectif_bs_1"] la séance, et [holo_prix k="collectif_bs_6"] par cours à partir de six hors juillet-août.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Le cours particulier, seul ou jusqu'à quatre personnes du même groupe, pour un accompagnement entièrement adapté à vos objectifs. [holo_prix k="particulier_1"] pour une personne, [holo_prix k="particulier_pp3"] par personne à partir de trois.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Le coaching vidéo, pour les surfeurs qui tiennent déjà debout : vous êtes filmé dans l'eau, puis vos vagues sont analysées ensemble à la sortie.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Le sur mesure, pour les EVG, EVJF, entreprises, colonies de vacances et campings, sur devis.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Les enfants commencent dès 5 ans, dans des vagues adaptées et en petit groupe. Ils portent des lycras de couleur pour être repérés d'un coup d'œil, et le spot comme l'horaire sont choisis selon la marée. Les familles peuvent aussi réserver un cours particulier jusqu'à quatre personnes.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">La sécurité avant la première vague</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Comme toutes les plages landaises, celles de Capbreton font face à l'Atlantique : la houle y est puissante et les <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#baines">courants de baïne</a> peuvent entraîner vers le large. Chaque cours commence donc sur le sable. On parle des courants et de la façon de les repérer, de l'endroit où se placer, de la manière de tomber et de remonter sur sa planche. Puis on s'échauffe et on répète au sol le passage de la position allongée à la position debout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Le matériel est adapté à chaque gabarit : planche en mousse pour débuter, combinaison à la bonne taille et à la bonne épaisseur selon la saison. L'école est labellisée Ecosafe Surfing, un label qui associe la sécurité des surfeurs au respect de l'environnement.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Pourquoi apprendre le surf à Capbreton ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Capbreton a un atout que peu de villes de la côte possèdent : en quelques minutes de route, on passe des plages accueillantes du Santocha aux spots réputés d'Hossegor et de Seignosse. Les bancs de sable bougent au fil des marées et des tempêtes, si bien qu'il y a presque toujours une plage où les vagues sont à taille humaine. Pour un débutant, c'est la garantie de trouver plus souvent des conditions d'apprentissage. Pour un surfeur qui progresse, c'est l'occasion de découvrir des vagues plus techniques sans changer d'école.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Avant de venir, regardez la <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>">webcam de Capbreton</a> pour voir à quoi ressemblent les vagues du jour.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quelle saison pour prendre un cours ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>L'été apporte des vagues souvent plus petites et une eau qui monte autour de 20 °C : c'est la période la plus simple pour une initiation, mais aussi la plus fréquentée, et les cours collectifs passent au tarif haute saison en juillet et en août. Le printemps et l'automne offrent des houles plus régulières, des plages plus calmes et une eau encore agréable avec une combinaison 3/2. En hiver, la mer est plus puissante et l'eau plus froide : c'est la saison des surfeurs qui ont déjà les bases, et le cours particulier ou le coaching vidéo y prennent tout leur sens.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Pour surfer entre deux cours, l'école propose aussi la <a href="<?php echo esc_url( hs_url( 'Location' ) ); ?>">location de planches et de combinaisons à Capbreton</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Un moniteur qui vous suit d'un cours à l'autre</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Chez Holo Surf, vous savez qui vous accueille. <a href="<?php echo esc_url( hs_url( 'APropos' ) ); ?>">Paul, votre moniteur de surf</a>, surfe depuis plus de quinze ans et encadre lui-même les cours. Il parle français, anglais et espagnol, et reste joignable 24h/24 et 7j/7 pour toute question. D'une séance à l'autre, il sait où vous en êtes et ce qu'il reste à travailler : c'est ce suivi qui fait progresser vite.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Réserver un cours</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Il n'y a pas de réservation en ligne. Vous <a href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>">écrivez directement à Paul</a> avec vos dates, le nombre de surfeurs, leur âge et leur niveau. Il vous répond par e-mail pour fixer le créneau, le spot et la formule la plus adaptée.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
