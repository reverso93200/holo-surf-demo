<?php
/**
 * Title: À propos : Intro
 * Slug: holo-surf/a-propos-intro
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-6d3d56"} -->
<section class="wp-block-group u-6d3d56">
<!-- wp:group {"className":"wrap u-f8e142"} -->
<div class="wp-block-group wrap u-f8e142">
<!-- wp:group {"className":"u-588d45"} -->
<div class="wp-block-group u-588d45">
<!-- wp:paragraph {"className":"in crumb u-d75df9"} -->
<p class="in crumb u-d75df9"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #55636A">Accueil</a> / À propos</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"in d1 u-5fe07a"} -->
<h1 class="wp-block-heading in d1 u-5fe07a">Paul, moniteur de surf <span style="color: #85652A">à Capbreton</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 kicker u-3ccb64"} -->
<p class="in d1 kicker u-3ccb64">Bien plus qu'un sport, un style de vie</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d2 u-487750"} -->
<p class="in d2 u-487750">Je suis Paul, surfeur passionné depuis plus de 15 ans. Mon objectif : vous faire découvrir le surf dans un esprit de plaisir, de sécurité et de respect de l'océan.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"in d3 u-1122c4"} -->
<div class="wp-block-group in d3 u-1122c4">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>">Réserver mon cours</a>
<a class="lnk" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">Les cours et tarifs</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"in d1 zoom u-8e756e"} -->
<div class="wp-block-group in d1 zoom u-8e756e">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-1413c9"} -->
<figure class="wp-block-image size-full ui-1413c9"><img src="<?php echo esc_url( hs_img( '45a3a6161a91bf95911b9a6167430a34' ) ); ?>" alt="Paul, moniteur de Holo Surf, sa planche sous le bras sur la plage"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span class="hs-photo-credit" style="position: absolute; right: 10px; bottom: 10px; padding: 3px 8px; font-size: 12px; color: #FFFFFF; background: rgba(25, 42, 51, 0.6)">Photo : Hugo Mouille</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
