<?php
/**
 * Title: Accueil : Galerie
 * Slug: holo-surf/accueil-galerie
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-070931"} -->
<section class="wp-block-group u-070931">
<!-- wp:group {"className":"wrap u-beefb6"} -->
<div class="wp-block-group wrap u-beefb6">
<!-- wp:heading {"className":"h2"} -->
<h2 id="galerie" class="wp-block-heading h2">Galerie</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="https://www.instagram.com/holosurfcapbreton/">@holosurfcapbreton</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"strip u-755074"} -->
<div class="wp-block-group strip u-755074">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-5f5d75"} -->
<figure class="wp-block-image size-full ui-5f5d75"><img src="<?php echo esc_url( hs_img( 'c6e90b27fe474c9ebd785e4276dfdeba' ) ); ?>" alt="Paul dans un tube à la plage des Culs Nus"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-5fd00a"} -->
<figure class="wp-block-image size-full ui-5fd00a"><img src="<?php echo esc_url( hs_img( '8824bd5b6a80e68ef34a4fee0f6fbca0' ) ); ?>" alt="Cours de surf enfants au Santocha"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-2dac34"} -->
<figure class="wp-block-image size-full ui-2dac34"><img src="<?php echo esc_url( hs_img( '3b31185d96af976bfec3e210631bcb36' ) ); ?>" alt="Un tube à la plage des Océanides à Capbreton"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-5fd00a"} -->
<figure class="wp-block-image size-full ui-5fd00a"><img src="<?php echo esc_url( hs_img( 'a1df94dc5233aa7c13086952257fb04e' ) ); ?>" alt="La fresque Protège ta dune sur un blockhaus du Santocha"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-73d1e2"} -->
<figure class="wp-block-image size-full ui-73d1e2"><img src="<?php echo esc_url( hs_img( 'd7998c9e816d82c8acf6c8b945419594' ) ); ?>" alt="Paul encourage une élève dans l'eau"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-1485e6"} -->
<figure class="wp-block-image size-full ui-1485e6"><img src="<?php echo esc_url( hs_img( 'a67cb1a03e4015e525f7e0eb9f452cc5' ) ); ?>" alt="Une vague d'hiver à Hossegor"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
