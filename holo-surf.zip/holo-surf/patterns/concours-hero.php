<?php
/**
 * Title: Concours 2026 : Hero
 * Slug: holo-surf/concours-hero
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-843517"} -->
<section class="wp-block-group u-843517">
<!-- wp:group {"className":"wrap u-8a8da7"} -->
<div class="wp-block-group wrap u-8a8da7">
<!-- wp:group {"className":"u-ac68db"} -->
<div class="wp-block-group u-ac68db">
<!-- wp:heading {"level":1,"className":"in h1c u-3bf111"} -->
<h1 class="wp-block-heading in h1c u-3bf111">Concours 2026<span style="display: block; color: #D4AA63">Gagne ta planche</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 u-dc76f1"} -->
<p class="in d1 u-dc76f1">Pour remercier ses élèves et toute la communauté, Holo Surf organise un jeu concours toute la saison. À gagner : une planche Ocean Storm et des cours de surf.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"in d2 u-40b7b7"} -->
<div class="wp-block-group in d2 u-40b7b7">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="min-height: 58px; padding: 0 30px; font-size: 23px">Je gagne ma planche</a>
<a class="btn b-ow" href="https://www.instagram.com/holosurfcapbreton/" style="min-height: 58px; padding: 0 30px; font-size: 23px">Je joue sur Insta</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"in d3 u-119d10"} -->
<p class="in d3 u-119d10">Édition 2026 terminée le 30 septembre. Gagnants annoncés sur Instagram, prochaine édition au printemps 2027.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"in d2 u-b126e6"} -->
<div class="wp-block-group in d2 u-b126e6">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"bob ui-c5e477"} -->
<figure class="wp-block-image size-full bob ui-c5e477"><img src="<?php echo esc_url( hs_img( '7deae58f184d2ff169cef3dbc6227b2d' ) ); ?>" alt="Planches Ocean Storm 7'6 Weekender"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: -1px; height: 44px; overflow: hidden">
<svg class="wave" preserveAspectRatio="none" style="position: absolute; left: 0; bottom: 0; width: 200%; height: 44px" viewBox="0 0 2880 64"><path d="M0 32 C120 12 240 12 360 32 S600 52 720 32 S960 12 1080 32 S1320 52 1440 32 S1680 12 1800 32 S2040 52 2160 32 S2400 12 2520 32 S2760 52 2880 32 V64 H0 Z" fill="#FFFFFF"></path></svg>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
