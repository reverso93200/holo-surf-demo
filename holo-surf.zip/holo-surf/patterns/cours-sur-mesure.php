<?php
/**
 * Title: Les cours et tarifs : Sur mesure
 * Slug: holo-surf/cours-sur-mesure
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5fc072"} -->
<section id="sur-mesure" class="wp-block-group u-5fc072">
<!-- wp:group {"className":"wrap reveal u-145faa"} -->
<div class="wp-block-group wrap reveal u-145faa">
<!-- wp:group {"className":"u-8d7a8c"} -->
<div class="wp-block-group u-8d7a8c">
<!-- wp:heading {"className":"h2 u-179e48"} -->
<h2 class="wp-block-heading h2 u-179e48">Sur mesure</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-f5ed95"} -->
<p class="u-f5ed95">EVG, EVJF, évènements d'entreprise, colonies de vacances, campings… Contactez-nous pour un devis, tout est possible !</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="min-height: 58px; font-size: 23px">Demander un devis</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
