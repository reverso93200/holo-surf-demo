<?php
/**
 * Title: Réserver mon cours : Intro
 * Slug: holo-surf/reserver-intro
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-aa15a7"} -->
<section class="wp-block-group u-aa15a7">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:paragraph {"className":"in crumb u-d75df9"} -->
<p class="in crumb u-d75df9"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #55636A">Accueil</a> / Réserver mon cours</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"u-d4bc83"} -->
<div class="wp-block-group u-d4bc83">
<!-- wp:heading {"level":1,"className":"in d1 u-58af5b"} -->
<h1 class="wp-block-heading in d1 u-58af5b">Réserver un cours de surf à Capbreton</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d2 u-ad20a1"} -->
<p class="in d2 u-ad20a1">Écrivez directement à Paul avec vos dates, le nombre de surfeurs et leur niveau. Il vous répond par e-mail pour fixer le créneau.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
