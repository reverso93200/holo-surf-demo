<?php
/**
 * Title: Accueil : Hero
 * Slug: holo-surf/accueil-hero
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-f7c64d"} -->
<section class="wp-block-group u-f7c64d">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kb ui-b5dac4"} -->
<figure class="wp-block-image size-full kb ui-b5dac4"><img src="<?php echo esc_url( hs_img( '038cdb79f92c60fc87e4bde1fc2e1bf6' ) ); ?>" alt="La plage du Santocha à Capbreton vue du ciel"/></figure>
<!-- /wp:image -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(180deg, rgba(25,42,51,0.2) 25%, rgba(25,42,51,0.82) 100%)"></div>
<!-- /wp:html -->

<!-- wp:group {"className":"wrap u-a6e189"} -->
<div class="wp-block-group wrap u-a6e189">
<!-- wp:heading {"level":1,"className":"in u-1e633f"} -->
<h1 class="wp-block-heading in u-1e633f">École de surf à Capbreton</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 u-b8f806"} -->
<p class="in d1 u-b8f806">Un accompagnement sur mesure pour apprendre, progresser et vibrer au rythme des vagues !</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"in d2 u-218fee"} -->
<div class="wp-block-group in d2 u-218fee">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="min-height: 58px; padding: 0 32px; font-size: 23px">Réserver mon cours</a>
<a class="btn b-ow" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="min-height: 58px; padding: 0 32px; font-size: 23px">Les cours et tarifs</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: -1px; height: 44px; overflow: hidden">
<svg class="wave" preserveAspectRatio="none" style="position: absolute; left: 0; bottom: 0; width: 200%; height: 44px" viewBox="0 0 2880 64"><path d="M0 32 C120 12 240 12 360 32 S600 52 720 32 S960 12 1080 32 S1320 52 1440 32 S1680 12 1800 32 S2040 52 2160 32 S2400 12 2520 32 S2760 52 2880 32 V64 H0 Z" fill="#FFFFFF"></path></svg>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
