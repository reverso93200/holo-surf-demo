<?php
/**
 * Title: Location : Vers les cours
 * Slug: holo-surf/location-vers-les-cours
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-0859e3"} -->
<section class="wp-block-group u-0859e3">
<!-- wp:group {"className":"wrap reveal u-89dd66"} -->
<div class="wp-block-group wrap reveal u-89dd66">
<!-- wp:group {"className":"u-d1c8df"} -->
<div class="wp-block-group u-d1c8df">
<!-- wp:heading {"className":"h2 u-6caf50"} -->
<h2 class="wp-block-heading h2 u-6caf50">Envie d'apprendre ?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-0903dc"} -->
<p class="u-0903dc">Planche, combinaison et assurance sont comprises dans tous les cours.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="min-height: 58px; font-size: 23px">Les cours et tarifs</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
