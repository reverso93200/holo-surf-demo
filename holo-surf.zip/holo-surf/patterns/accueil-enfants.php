<?php
/**
 * Title: Accueil : Enfants
 * Slug: holo-surf/accueil-enfants
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-636f5c"} -->
<section id="enfants" class="wp-block-group u-636f5c">
<!-- wp:group {"className":"wrap u-653ddb"} -->
<div class="wp-block-group wrap u-653ddb">
<!-- wp:group {"className":"reveal kids u-5b117a"} -->
<div class="wp-block-group reveal kids u-5b117a">
<!-- wp:group {"className":"zoom u-e7c4c5"} -->
<div class="wp-block-group zoom u-e7c4c5">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-4a3c4f"} -->
<figure class="wp-block-image size-full ui-4a3c4f"><img src="<?php echo esc_url( hs_img( '17edbc4d06c815d93bce895ab0c1fe5d' ) ); ?>" alt="Un enfant debout sur sa planche pendant un cours de surf à Capbreton"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"zoom u-12c59c"} -->
<div class="wp-block-group zoom u-12c59c">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'cfab3bf3216fad58ce90fb60649a54a6' ) ); ?>" alt="Des enfants rament avec Paul pendant un cours collectif"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"zoom u-12c59c"} -->
<div class="wp-block-group zoom u-12c59c">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( '7c0cb50b1d57d0d2fc0badb0efec5fa2' ) ); ?>" alt="Paul accompagne des enfants dans les vagues du Santocha"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-7a0035"} -->
<div class="wp-block-group reveal u-7a0035">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Cours de surf enfant dès 5 ans</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-6a2215"} -->
<p class="p u-6a2215">Les enfants découvrent le surf dans des vagues adaptées, en petit groupe, avec un moniteur qui prend le temps. Lycras de couleur pour les repérer facilement, spot et horaire choisis selon la marée : ils apprennent en sécurité et repartent avec l'envie de revenir.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-0dc91c"} -->
<p class="p u-0dc91c">En cours collectif, ou en famille jusqu'à 4 personnes en cours particulier.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 30px">Réserver un cours enfant</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
