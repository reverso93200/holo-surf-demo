<?php
/**
 * Title: À propos : Ecosafe
 * Slug: holo-surf/a-propos-ecosafe
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-0859e3"} -->
<section class="wp-block-group u-0859e3">
<!-- wp:group {"className":"u-fc795e"} -->
<div class="wp-block-group u-fc795e">
<!-- wp:group {"className":"zoom eco u-ea35d6"} -->
<div class="wp-block-group zoom eco u-ea35d6">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-4a3c4f"} -->
<figure class="wp-block-image size-full ui-4a3c4f"><img src="<?php echo esc_url( hs_img( 'a1df94dc5233aa7c13086952257fb04e' ) ); ?>" alt="La fresque Protège ta dune sur un blockhaus de la plage du Santocha"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-87b5a9"} -->
<div class="wp-block-group reveal u-87b5a9">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-c12243"} -->
<figure class="wp-block-image size-full ui-c12243"><img src="<?php echo esc_url( hs_img( 'e8d41159726ca97b3fe3268639ef8b92' ) ); ?>" alt="Label Ecosafe Surfing"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"className":"h2 u-e285eb"} -->
<h2 class="wp-block-heading h2 u-e285eb">Labellisée Ecosafe Surfing</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-0f4f0a"} -->
<p class="u-0f4f0a">L'école allie sécurité et respect de l'environnement. La préservation du littoral fait partie de chaque cours, au même titre que la technique : c'est notre terrain de jeu.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
