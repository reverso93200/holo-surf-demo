<?php
/**
 * Title: Page 404
 * Slug: holo-surf/erreur-404
 * Categories: holo-surf
 * Viewport Width: 1440
 * Inserter: no
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-4ebf3d"} -->
<section class="wp-block-group u-4ebf3d">
<!-- wp:group {"className":"wrap u-2703d2"} -->
<div class="wp-block-group wrap u-2703d2">
<!-- wp:group {"className":"u-d1c8df"} -->
<div class="wp-block-group u-d1c8df">
<!-- wp:paragraph {"className":"in u-c615c7"} -->
<p class="in u-c615c7">Erreur 404</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"in d1 u-939b71"} -->
<h1 class="wp-block-heading in d1 u-939b71">Cette vague est passée</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d2 u-ce4834"} -->
<p class="in d2 u-ce4834">La page que vous cherchez n'existe plus ou a changé d'adresse. Le site a été refait : voici les pages les plus consultées.</p>
<!-- /wp:paragraph -->

<!-- wp:holo-surf/search-form /-->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<nav aria-label="Pages principales" class="in d3" style="flex: 1 1 360px; min-width: 0">
<ul class="ftl" style="gap: 0; border-top: 1px solid #E4DACA">
<li style="border-bottom: 1px solid #E4DACA"><a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="display: flex; justify-content: space-between; align-items: center; min-height: 64px; font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #192A33; text-decoration: none">Cours de surf à Capbreton<svg aria-hidden="true" fill="none" height="22" stroke="#85652A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="22"><path d="M9 6l6 6-6 6"></path></svg></a></li>
<li style="border-bottom: 1px solid #E4DACA"><a href="<?php echo esc_url( hs_url( 'Location' ) ); ?>" style="display: flex; justify-content: space-between; align-items: center; min-height: 64px; font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #192A33; text-decoration: none">Location surf<svg aria-hidden="true" fill="none" height="22" stroke="#85652A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="22"><path d="M9 6l6 6-6 6"></path></svg></a></li>
<li style="border-bottom: 1px solid #E4DACA"><a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>" style="display: flex; justify-content: space-between; align-items: center; min-height: 64px; font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #192A33; text-decoration: none">Webcam Capbreton<svg aria-hidden="true" fill="none" height="22" stroke="#85652A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="22"><path d="M9 6l6 6-6 6"></path></svg></a></li>
<li style="border-bottom: 1px solid #E4DACA"><a href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>" style="display: flex; justify-content: space-between; align-items: center; min-height: 64px; font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #192A33; text-decoration: none">Les spots<svg aria-hidden="true" fill="none" height="22" stroke="#85652A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="22"><path d="M9 6l6 6-6 6"></path></svg></a></li>
<li style="border-bottom: 1px solid #E4DACA"><a href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="display: flex; justify-content: space-between; align-items: center; min-height: 64px; font-family: 'Bebas Neue', sans-serif; font-size: 30px; color: #192A33; text-decoration: none">Réserver mon cours<svg aria-hidden="true" fill="none" height="22" stroke="#85652A" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="22"><path d="M9 6l6 6-6 6"></path></svg></a></li>
</ul>
</nav>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
