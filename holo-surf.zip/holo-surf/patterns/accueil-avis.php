<?php
/**
 * Title: Accueil : Avis
 * Slug: holo-surf/accueil-avis
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-94b224"} -->
<section class="wp-block-group u-94b224">
<!-- wp:group {"className":"wrap u-9ce1d5"} -->
<div class="wp-block-group wrap u-9ce1d5">
<!-- wp:group {"className":"reveal u-05e5e7"} -->
<div class="wp-block-group reveal u-05e5e7">
<!-- wp:heading {"className":"h2 u-6f4d96"} -->
<h2 class="wp-block-heading h2 u-6f4d96">L'avis de nos surfeurs</h2>
<!-- /wp:heading -->

<!-- wp:quote {"className":"u-79bc93"} -->
<blockquote class="wp-block-quote u-79bc93">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c">« Une organisation remarquable et une grande souplesse. Merci beaucoup, Paul, pour ta joie de vivre communicative, ta pédagogie et le partage généreux de ta passion qui a su faire germer la graine de deux futurs passionnés. »</p>
<!-- /wp:paragraph -->
</blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph {"className":"u-2ffa33"} -->
<p class="u-2ffa33">Guillaume</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-a217dc"} -->
<div class="wp-block-group reveal u-a217dc">
<!-- wp:html -->
<div aria-label="Emplacement prévu pour le widget d'avis Google" role="img" style="min-height: 300px; box-sizing: border-box; border: 1.5px dashed #4A6373; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; padding: 28px; text-align: center">
<span style="font-family: 'Bebas Neue', sans-serif; font-size: 32px; color: #FFFFFF">Avis Google</span>
<span style="font-size: 15px; line-height: 1.5; color: #B8C6CC">Les avis de la fiche Google s'affichent ici, chargés au défilement</span>
</div>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="[holo_lien_avis]" style="display: inline-block; margin-top: 18px; color: #FFFFFF">Laisser un avis sur Google</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
