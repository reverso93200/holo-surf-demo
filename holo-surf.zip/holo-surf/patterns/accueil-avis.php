<?php
/**
 * Title: Accueil : Avis
 * Slug: holo-surf/accueil-avis
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-94b224"} -->
<section class="wp-block-group u-94b224">
<!-- wp:group {"className":"wrap u-9ce1d5"} -->
<div class="wp-block-group wrap u-9ce1d5">
<!-- wp:shortcode -->
[holo_avis]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
