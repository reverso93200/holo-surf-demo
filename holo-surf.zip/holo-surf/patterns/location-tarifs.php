<?php
/**
 * Title: Location : Tarifs
 * Slug: holo-surf/location-tarifs
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-ffae2f"} -->
<section id="tarifs" class="wp-block-group u-ffae2f">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-7c3220"} -->
<div class="wp-block-group reveal u-7c3220">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Tarifs de location</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-e80025"} -->
<p class="p u-e80025">Prix par article. Pour louer, appelez Paul au [holo_info k="telephone"] ou écrivez-lui.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-190334"} -->
<div class="wp-block-group reveal u-190334">
<!-- wp:shortcode -->
[holo_tarifs type="mousse"]
<!-- /wp:shortcode -->

<!-- wp:shortcode -->
[holo_tarifs type="hybride"]
<!-- /wp:shortcode -->

<!-- wp:shortcode -->
[holo_tarifs type="combinaison"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
