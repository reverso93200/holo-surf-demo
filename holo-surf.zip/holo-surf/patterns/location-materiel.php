<?php
/**
 * Title: Location : Matériel
 * Slug: holo-surf/location-materiel
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-afed12"} -->
<section class="wp-block-group u-afed12">
<!-- wp:group {"className":"wrap reveal u-3ad448"} -->
<div class="wp-block-group wrap reveal u-3ad448">
<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-02b528"} -->
<div class="wp-block-group zoom u-02b528">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-31fe40"} -->
<figure class="wp-block-image size-full ui-31fe40"><img src="<?php echo esc_url( hs_img( '0cacc250d6b5da153f4fdc740318545d' ) ); ?>" alt="Planches en mousse Ocean Storm"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h3 u-566685"} -->
<h2 class="wp-block-heading h3 u-566685">Planche en mousse</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">Découvrez les gammes Ocean Storm et Zeus en location. Ces planches en mousse avec de la résine à l'intérieur gardent de la stabilité et du confort tout en étant plus rigides que des mousses classiques.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-1e487c"} -->
<div class="wp-block-group zoom u-1e487c">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'bb43cda8887e1d734f5acb7b23489f72' ) ); ?>" alt="Planche hybride sur l'eau"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h3 u-566685"} -->
<h2 class="wp-block-heading h3 u-566685">Les hybrides</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">Louer une planche hybride, c'est surfer une planche plus réactive sans se priver du volume ni du revêtement mousse, plus sécurisant. Elle s'adresse aux surfeurs qui vont au large et cherchent plus de manœuvrabilité pour prendre de la vitesse et tracer leurs premières courbes.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-f3abed"} -->
<div class="wp-block-group zoom u-f3abed">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-d2210c"} -->
<figure class="wp-block-image size-full ui-d2210c"><img src="<?php echo esc_url( hs_img( '386c78c0b287cf3189b2887ab78cd0af' ) ); ?>" alt="Combinaison courte"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-31fe40"} -->
<figure class="wp-block-image size-full ui-31fe40"><img src="<?php echo esc_url( hs_img( '59d3f1e3fd6cb3df15a96a74d2346e7c' ) ); ?>" alt="Combinaison intégrale"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h3 u-566685"} -->
<h2 class="wp-block-heading h3 u-566685">Les combinaisons</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">En néoprène de qualité, les combinaisons Hurricane isolent bien tout en restant souples. Pour femmes, enfants et hommes, en plusieurs tailles et épaisseurs selon la saison, entretenues et renouvelées régulièrement.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-0a1b27"} -->
<p class="p u-0a1b27">En 3/2 et en 2/2 manches courtes. Chaussons et 4/3 également à la location.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
