<?php
/**
 * Title: Infos surf : Webcam
 * Slug: holo-surf/infos-surf-webcam
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-cbd47c"} -->
<section id="webcam" class="wp-block-group u-cbd47c">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-235474"} -->
<div class="wp-block-group reveal u-235474">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">La plage du Santocha en direct</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-e80025"} -->
<p class="p u-e80025">Le spot principal de nos cours, filmé en temps réel. Regardez les séries, la surface de l'eau et la marée avant de partir.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Emplacement prévu pour la webcam du Santocha" class="reveal" role="img" style="position: relative; aspect-ratio: 16 / 9; max-height: 680px; width: 100%; overflow: hidden; background: #192A33">
<img alt="" decoding="async" height="683" loading="lazy" src="<?php echo esc_url( hs_img( 'e4fe848118a1099a3a24a2e83acd3ed7' ) ); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0.6" width="1024"/>
<span style="position: absolute; left: 0; right: 0; top: 50%; transform: translateY(-50%); display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center; color: #FFFFFF"><a aria-label="Voir la webcam du Santocha en direct" href="https://www.surf-report.com/webcams/santocha-capbreton-s1099.html" rel="noopener" style="width: 84px; height: 84px; border-radius: 50%; background: #D4AA63; color: #192A33; display: flex; align-items: center; justify-content: center; text-decoration: none" target="_blank"><svg aria-hidden="true" fill="currentColor" height="30" viewBox="0 0 24 24" width="30"><path d="M8 5v14l11-7z"></path></svg></a><span style="font-family: 'Bebas Neue', sans-serif; font-size: 30px; letter-spacing: 0.03em">Voir le direct</span><span style="font-size: 14.5px; color: #C9D4D9">Webcam du Santocha sur surf-report.com</span></span>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
