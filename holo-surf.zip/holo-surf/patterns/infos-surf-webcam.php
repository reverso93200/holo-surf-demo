<?php
/**
 * Title: Infos surf : Webcam
 * Slug: holo-surf/infos-surf-webcam
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-cbd47c"} -->
<section id="webcam" class="wp-block-group u-cbd47c">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-235474"} -->
<div class="wp-block-group reveal u-235474">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">La plage du Santocha en direct</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-e80025"} -->
<p class="p u-e80025">Le spot principal de nos cours, filmé en temps réel. Regardez les séries, la surface de l'eau et la marée avant de partir.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal"} -->
<div class="wp-block-group reveal">
<!-- wp:shortcode -->
[holo_webcam image="<?php echo esc_url( hs_img( 'e4fe848118a1099a3a24a2e83acd3ed7' ) ); ?>"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
