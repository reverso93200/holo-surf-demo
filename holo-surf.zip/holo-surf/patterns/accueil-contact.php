<?php
/**
 * Title: Accueil : Contact
 * Slug: holo-surf/accueil-contact
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-3511ab"} -->
<section id="contact" class="wp-block-group u-3511ab">
<!-- wp:group {"className":"wrap u-4dac3e"} -->
<div class="wp-block-group wrap u-4dac3e">
<!-- wp:group {"className":"reveal u-b6b9bc"} -->
<div class="wp-block-group reveal u-b6b9bc">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Nous contacter</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-0de1f9"} -->
<p class="p u-0de1f9">Pour réserver un cours ou poser une question, écrivez à Paul. Il vous répond par e-mail.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"u-c9e8cb"} -->
<p class="u-c9e8cb">[holo_adresse]<br/>[holo_tel class="lnk"]<br/>[holo_email class="lnk"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-155f08"} -->
<p class="p u-155f08">Disponible 24h/7j pour tout appel ou information.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"mapf u-1c8092"} -->
<div class="wp-block-group mapf u-1c8092">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-de14c8"} -->
<figure class="wp-block-image size-full ui-de14c8"><img src="<?php echo esc_url( hs_img( '038cdb79f92c60fc87e4bde1fc2e1bf6' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"u-794ff7"} -->
<div class="wp-block-group u-794ff7">
<!-- wp:html -->
<button class="btn b-sand" style="width: auto; min-height: 50px" type="button">Afficher la carte</button>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span style="font-size: 14.5px; color: #FFFFFF">Plage du Santocha, Capbreton. La carte Google se charge au clic.</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:shortcode -->
[holo_reservation variante="accueil"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
