<?php
/**
 * Title: Les spots : Prévention
 * Slug: holo-surf/spots-prevention
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-971ba6"} -->
<section class="wp-block-group u-971ba6">
<!-- wp:group {"className":"wrap reveal u-4bddbc"} -->
<div class="wp-block-group wrap reveal u-4bddbc">
<!-- wp:group {"className":"u-d1c8df"} -->
<div class="wp-block-group u-d1c8df">
<!-- wp:heading {"className":"h2 u-20aed7"} -->
<h2 class="wp-block-heading h2 u-20aed7">Baïnes et courants : renseignez-vous avant d'aller à l'eau</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-27e808"} -->
<p class="u-27e808">En cas de doute, demandez conseil aux sauveteurs ou aux surfeurs expérimentés.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#baines">Comprendre les baïnes</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
