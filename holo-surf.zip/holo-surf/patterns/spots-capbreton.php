<?php
/**
 * Title: Les spots : capbreton
 * Slug: holo-surf/spots-capbreton
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-cbd47c"} -->
<section id="capbreton" class="wp-block-group u-cbd47c">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-b7f6ed"} -->
<div class="wp-block-group reveal u-b7f6ed">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Les spots de surf de Capbreton</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-c83bd2"} -->
<p class="p u-c83bd2">Un spot emblématique aux vagues variées et puissantes, avec des bancs de sable qui bougent au fil des marées : il y en a pour tous les niveaux.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"zoom reveal townimg u-730f19"} -->
<div class="wp-block-group zoom reveal townimg u-730f19">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'e4fe848118a1099a3a24a2e83acd3ed7' ) ); ?>" alt="La plage du Santocha à Capbreton et ses blockhaus"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="sp">
<li><div class="nm"><h3>La Centrale</h3><span class="lv">Débutant à intermédiaire</span></div><p>En plein centre-ville, accessible et animé. Les courants y sont plus doux que sur les plages voisines, et le spot est vite fréquenté quand les autres sont trop gros.</p></li>
<li><div class="nm"><h3>Le Prévent</h3><span class="lv">Débutant à intermédiaire</span></div><p>Polyvalent et tout près du centre, idéal pour apprendre et progresser. Facile d'accès, courants modérés, prisé quand ça rentre gros ailleurs.</p></li>
<li class="ours"><div class="nm"><span class="tag">Le spot de nos cours</span><h3>Le Santocha</h3><span class="lv">Débutant à intermédiaire</span></div><p>Des vagues douces et une pente faible pour tenir longtemps debout. Les courants sont généralement faibles mais peuvent se renforcer par grosse houle ou mauvais temps.</p></li>
<li><div class="nm"><h3>La Piste</h3><span class="lv">Intermédiaire à confirmé</span></div><p>Des vagues plus creuses et plus techniques. Attention aux blockhaus peu profonds et aux baïnes.</p></li>
<li><div class="nm"><h3>Les Océanides</h3><span class="lv">Confirmé</span></div><p>Vagues creuses et rapides, avec des tubes par houle bien orientée. Peut être très agité : les débutants n'y vont que par petite houle, après avoir demandé conseil aux sauveteurs.</p></li>
</ul>
<!-- /wp:html -->

<!-- wp:group {"className":"reveal u-c628b3"} -->
<div class="wp-block-group reveal u-c628b3">
<!-- wp:group {"className":"seo fold"} -->
<div id="seo-sc" class="wp-block-group seo fold">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Surfer à Capbreton : ce qu'il faut savoir</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Capbreton aligne ses plages au sud de son port, de l'estacade jusqu'à Labenne. Ce sont des beach breaks : les vagues cassent sur des bancs de sable et non sur un récif, ce qui explique leur grande variété d'un jour à l'autre. Voici ce qu'il faut savoir avant d'y surfer.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Des bancs de sable qui changent tout</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>À Capbreton, la forme des vagues dépend des bancs de sable. Les tempêtes d'hiver les déplacent, les marées les modèlent, et une plage excellente en octobre peut devenir moyenne au printemps. C'est pour cela qu'il faut regarder les conditions chaque jour plutôt que se fier à la réputation d'un spot. Les épis, ces digues de pierre perpendiculaires à la plage, retiennent une partie du sable et créent des pics plus réguliers autour d'eux. Ils imposent aussi de la prudence : on ne surfe jamais trop près des enrochements.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Le Gouf de Capbreton</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Au large du port commence le Gouf de Capbreton, l'un des plus grands canyons sous-marins d'Europe. Sa tête se trouve à quelques centaines de mètres du rivage, puis il plonge à plusieurs milliers de mètres de profondeur. Les houles qui passent au-dessus de ces grands fonds ne sont pas freinées comme ailleurs : elles gardent leur énergie jusqu'à la côte, ce qui explique en partie la puissance des vagues d'Hossegor, juste au nord. Capbreton profite de la même houle, avec des plages qui vont des plus accessibles aux plus techniques.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Quelle marée et quel vent ?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Il n'existe pas de règle valable toute l'année, mais quelques repères aident. La plupart des plages de Capbreton donnent leurs meilleures vagues autour de la mi-marée. À marée basse, les vagues ferment plus facilement sur les bancs ; à marée haute, elles cassent parfois sur le bord. Le vent idéal vient de l'est, de la terre : il lisse la mer et creuse les vagues. Un vent d'ouest, venu du large, rend les conditions désordonnées. En été, la mer est souvent plus belle le matin, avant que la brise ne se lève.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Le Santocha, notre plage de cours</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le Santocha accueille la plupart des cours de l'école pour de bonnes raisons. Sa pente douce donne des vagues qui déferlent progressivement, ce qui laisse le temps de se lever et de tenir debout. Les courants y sont généralement faibles, même s'ils peuvent se renforcer par grosse houle ou mauvais temps. La plage est large, ce qui permet de travailler en groupe sans gêner les autres surfeurs. Les blockhaus, vestiges du mur de l'Atlantique, servent de repères depuis l'eau, et l'un d'eux porte la fresque « Protège ta dune », un rappel que la plage se préserve.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Se garer et venir à vélo</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En été, les parkings proches des plages se remplissent tôt. Le vélo est souvent la meilleure solution : la Vélodyssée, l'itinéraire cyclable de la côte atlantique, passe par Capbreton. Hors saison, l'accès est beaucoup plus simple et les plages presque désertes en semaine.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Surveillance et règles</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En été, les principales plages de Capbreton sont surveillées par des sauveteurs. Des drapeaux indiquent l'état de la mer et délimitent les zones de baignade, où le surf est interdit. Hors de ces périodes, vous êtes seul responsable : ne surfez jamais seul quand vous débutez, et renseignez-vous auprès des surfeurs présents avant d'aller à l'eau.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
