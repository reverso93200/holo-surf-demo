<?php
/**
 * Title: Concours 2026 : Règlements
 * Slug: holo-surf/concours-reglements
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-e67a5d"} -->
<section class="wp-block-group u-e67a5d">
<!-- wp:group {"className":"wrap u-0a2e57"} -->
<div class="wp-block-group wrap u-0a2e57">
<!-- wp:group {"className":"reveal u-0007d2"} -->
<div class="wp-block-group reveal u-0007d2">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Règlements</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Organisateur : Holo Surf Capbreton, [holo_adresse]. Participer implique l'acceptation du règlement.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"faq reveal u-194198"} -->
<div class="wp-block-group faq reveal u-194198">
<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>Jeu clients, lot n°1</summary>
<!-- wp:html -->
<dl>
<dt>Qui participe</dt><dd>Les élèves ayant suivi au moins un cours payant entre le 1er avril et le 30 septembre inclus. Une participation par personne.</dd>
<dt>Tirage au sort</dt><dd>Dans les 10 jours suivant le 30 septembre, par logiciel ou au papier, idéalement filmé. Le gagnant est contacté par e-mail, téléphone ou réseaux sociaux. Sans réponse sous 7 jours, un nouveau tirage peut avoir lieu.</dd>
<dt>Remise du lot</dt><dd>À Capbreton. Le gagnant accepte la publication de son prénom, de l'initiale de son nom et des photos ou vidéos de la remise.</dd>
<dt>Données personnelles</dt><dd>Conservées 24 mois au plus. Accès, rectification ou suppression sur simple demande par e-mail.</dd>
</dl>
<!-- /wp:html -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Jeu Instagram, lots n°2 et 3</summary>
<!-- wp:html -->
<dl>
<dt>Qui participe</dt><dd>Toute personne qui participe pendant la période annoncée. Gratuit et sans obligation d'achat.</dd>
<dt>Tirage au sort</dt><dd>Parmi les commentaires, dans les 5 jours suivant la clôture. Gagnants annoncés sur Instagram et contactés en message privé.</dd>
<dt>Validité des lots</dt><dd>12 mois après le tirage, sur réservation et selon les disponibilités. Juillet et août peuvent être exclus.</dd>
<dt>Données personnelles</dt><dd>Utilisées uniquement pour la gestion du jeu.</dd>
</dl>
<!-- /wp:html -->
</details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
