<?php
/**
 * Title: Concours 2026 : Partenaire
 * Slug: holo-surf/concours-partenaire
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-67b27d"} -->
<section class="wp-block-group u-67b27d">
<!-- wp:group {"className":"wrap reveal u-4418f1"} -->
<div class="wp-block-group wrap reveal u-4418f1">
<!-- wp:paragraph {"className":"u-9854f1"} -->
<p class="u-9854f1">En partenariat avec Ocean Storm</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"u-0f6828"} -->
<p class="u-0f6828">La planche du lot n°1 est choisie avec Ocean Storm, l'une des marques proposées à la location chez Holo Surf.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
