<?php
/**
 * Title: Les cours et tarifs : Cours collectifs
 * Slug: holo-surf/cours-cours-collectifs
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-1b92fa"} -->
<section id="collectifs" class="wp-block-group u-1b92fa">
<!-- wp:group {"className":"wrap u-9ce1d5"} -->
<div class="wp-block-group wrap u-9ce1d5">
<!-- wp:group {"className":"reveal u-7a0035"} -->
<div class="wp-block-group reveal u-7a0035">
<!-- wp:group {"className":"zoom"} -->
<div class="wp-block-group zoom">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-9753a5"} -->
<figure class="wp-block-image size-full ui-9753a5"><img src="<?php echo esc_url( hs_img( 'c1658a8054f881a4d5d2929fda8cbc74' ) ); ?>" alt="Groupe d'élèves sur le sable avant un cours collectif à Capbreton"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h2 u-3d941b"} -->
<h2 class="wp-block-heading h2 u-3d941b">Cours de surf collectifs</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-2d4996"} -->
<p class="u-2d4996">Découvrez le surf dans une ambiance conviviale avec nos cours collectifs !</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Encadré par un moniteur diplômé, vous apprendrez les bases ou perfectionnerez votre technique en toute sécurité. Cours d'1h30, 8 personnes maximum. Le prix inclut le matériel (planches et combinaisons adaptées) et l'assurance.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Idéal pour progresser tout en partageant les vagues avec d'autres passionnés dans une atmosphère motivante !</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-d1c8df"} -->
<div class="wp-block-group reveal u-d1c8df">
<!-- wp:shortcode -->
[holo_tarifs type="collectif"]
<!-- /wp:shortcode -->

<!-- wp:paragraph {"className":"p u-155f08"} -->
<p class="p u-155f08">À partir de 6 cours, chaque séance revient à [holo_prix k="collectif_bs_6"] hors juillet-août.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 24px">Réserver un cours collectif</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
