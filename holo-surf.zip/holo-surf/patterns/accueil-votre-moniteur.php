<?php
/**
 * Title: Accueil : Votre moniteur
 * Slug: holo-surf/accueil-votre-moniteur
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-bc8502"} -->
<section id="moniteur" class="wp-block-group u-bc8502">
<!-- wp:group {"className":"wrap u-a7b188"} -->
<div class="wp-block-group wrap u-a7b188">
<!-- wp:group {"className":"reveal zoom u-7a0035"} -->
<div class="wp-block-group reveal zoom u-7a0035">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"mimg-h ui-058e39"} -->
<figure class="wp-block-image size-full mimg-h ui-058e39"><img src="<?php echo esc_url( hs_img( '1b7193192cca65022ca515c64d773f39' ) ); ?>" alt="Paul, moniteur de surf diplômé et fondateur de Holo Surf Capbreton"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-588d45"} -->
<div class="wp-block-group reveal u-588d45">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Votre moniteur</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-9ce4fa"} -->
<p class="u-9ce4fa">Je suis Paul, surfeur passionné depuis plus de 15 ans et moniteur dédié à vous enseigner bien plus qu'une simple technique.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-4de99d"} -->
<p class="p u-4de99d">Mon objectif ? Vous faire découvrir le surf dans un esprit de plaisir, de sécurité et de respect de l'océan. Apprendre à surfer, c'est aussi apprendre l'océan : observer la mer, lire les courants, anticiper les séries… Je vous donne les clés pour évoluer avec confiance et autonomie, que ce soit votre première vague ou en perfectionnement.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"u-ee6c6a"} -->
<p class="u-ee6c6a">Bien plus qu'un sport, un style de vie.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"u-475659"} -->
<div class="wp-block-group u-475659">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>">Réserver avec Paul</a>
<a class="lnk" href="<?php echo esc_url( hs_url( 'APropos' ) ); ?>">À propos de nous</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
