<?php
/**
 * Title: Accueil : Infos surf
 * Slug: holo-surf/accueil-infos-surf
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-3d01c2"} -->
<section class="wp-block-group u-3d01c2">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:heading {"className":"h2 reveal"} -->
<h2 class="wp-block-heading h2 reveal">Infos surf</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"reveal links4 u-94277a"} -->
<div class="wp-block-group reveal links4 u-94277a">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#baines" style="flex: 1 1 250px; min-width: 0; padding: 26px 0; border-bottom: 1px solid #ECE4D3; text-decoration: none; color: #192A33"><span class="h3" style="display: block; font-size: 32px">Les baïnes</span><span class="p" style="display: block; margin-top: 8px; font-size: 16px">Comprendre ces courants et savoir comment réagir.</span></a>
<a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#vagues" style="flex: 1 1 250px; min-width: 0; padding: 26px 0; border-bottom: 1px solid #ECE4D3; text-decoration: none; color: #192A33"><span class="h3" style="display: block; font-size: 32px">Les vagues</span><span class="p" style="display: block; margin-top: 8px; font-size: 16px">Comment elles naissent au large et déferlent sur nos plages.</span></a>
<a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#previsions" style="flex: 1 1 250px; min-width: 0; padding: 26px 0; border-bottom: 1px solid #ECE4D3; text-decoration: none; color: #192A33"><span class="h3" style="display: block; font-size: 32px">Prévisions surf</span><span class="p" style="display: block; margin-top: 8px; font-size: 16px">Houle, vent et marée avant d'aller à l'eau.</span></a>
<a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#webcam" style="flex: 1 1 250px; min-width: 0; padding: 26px 0; border-bottom: 1px solid #ECE4D3; text-decoration: none; color: #192A33"><span class="h3" style="display: block; font-size: 32px">Webcam</span><span class="p" style="display: block; margin-top: 8px; font-size: 16px">Le Santocha en direct.</span></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
