<?php
/**
 * Title: Infos surf : Guide SEO
 * Slug: holo-surf/infos-surf-guide-seo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5dd5ac"} -->
<section id="lire-webcam" class="wp-block-group u-5dd5ac">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"stick reveal u-67a893"} -->
<div class="wp-block-group stick reveal u-67a893">
<!-- wp:heading {"className":"h2"} -->
<h2 id="lire-webcam-t" class="wp-block-heading h2">Comment lire la webcam de Capbreton</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Taille, séries, vent, marée, courants : ce que Paul regarde avant de choisir le spot du cours.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-f6967f"} -->
<div class="wp-block-group u-f6967f">
<!-- wp:group {"className":"seo fold oncream"} -->
<div id="seo-s1" class="wp-block-group seo fold oncream">
<!-- wp:paragraph -->
<p>Une webcam ne sert pas seulement à savoir s'il y a des vagues. Bien regardée, elle dit si le vent est bon, si la marée est la bonne, si la plage est chargée et si le spot convient à votre niveau. Voici, point par point, comment lire la webcam du Santocha avant d'aller surfer à Capbreton.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">1. Estimer la taille des vagues</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sur une image de webcam, les vagues paraissent souvent plus petites qu'en réalité. Le meilleur repère, ce sont les surfeurs eux-mêmes : une vague qui atteint la taille d'un surfeur debout fait à peu près sa hauteur, soit plus d'un mètre et demi. Pour une initiation, les conditions idéales se situent entre les genoux et la taille, avec des vagues qui déferlent en mousse près du bord. Au-delà d'un mètre, la barre devient difficile à passer pour un débutant.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">2. Observer les séries</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les vagues n'arrivent pas en continu mais par séries, séparées par des moments plus calmes. Regardez la webcam pendant dix minutes : vous verrez la taille des plus grosses vagues, et pas seulement celle du moment, ainsi que le temps entre deux séries. Des séries espacées et régulières annoncent une houle venue de loin, plus puissante. Des vagues rapprochées et désordonnées signalent souvent une mer formée par le vent près de la côte.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">3. Lire le vent à la surface de l'eau</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La surface de l'eau trahit le vent. Une mer lisse, presque huilée, indique peu ou pas de vent : ce sont les conditions les plus agréables. Sur la côte landaise, le vent de terre souffle de l'est : il lisse la face des vagues et les creuse. Le vent de mer, d'ouest, crée du clapot et des vagues molles qui cassent dans tous les sens. Si vous voyez des moutons blancs loin du bord, le vent est fort et les conditions seront difficiles.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">4. Tenir compte de la marée</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sur les plages de sable de Capbreton, la marée change complètement les vagues en quelques heures. À marée basse, elles peuvent fermer d'un coup sur des bancs peu profonds. À marée haute, elles cassent parfois directement sur le bord, ce que l'on appelle le shorebreak. Entre les deux, on trouve souvent les meilleures vagues, mais tout dépend de la forme des bancs, qui évolue au fil des tempêtes. Les jours de gros coefficient, la mer monte et descend plus vite, et les courants se renforcent.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">5. Repérer les courants et les baïnes</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La webcam permet aussi de repérer une baïne. Cherchez une zone où les vagues cassent moins, où l'eau paraît plus sombre ou plus agitée, et où l'écume part vers le large au lieu de revenir vers la plage. C'est souvent là que l'eau accumulée sur le bord repart vers le large. Ce passage sert aux surfeurs confirmés pour rejoindre le pic, mais c'est un piège pour un débutant ou un nageur. Lisez notre explication sur <a href="#baines">les courants de baïnes</a> pour savoir comment réagir.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">6. Juger de la fréquentation</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En été, les plages de Capbreton sont surveillées, et la baignade et le surf se pratiquent dans des zones distinctes. La webcam vous montre si le line-up est chargé. Tôt le matin ou en fin de journée, il y a souvent moins de monde et moins de vent : ce sont les meilleurs créneaux pour surfer tranquillement.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Webcam, prévisions et marée : trois sources à croiser</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La webcam montre l'instant présent. Les <a href="#previsions">prévisions surf</a> annoncent ce qui arrive dans les heures et les jours suivants : hauteur de la houle, période, direction, force et direction du vent. L'horaire et le coefficient de marée complètent le tableau. Une bonne session se prépare en croisant les trois. Une houle d'ouest bien formée, un vent faible de secteur est et une marée montante donnent souvent de belles vagues sur les plages de Capbreton. La même houle avec un fort vent d'ouest donnera une mer désordonnée.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Retenez une règle simple : la période compte autant que la hauteur. Une houle de 1 mètre avec une période de 12 secondes est beaucoup plus puissante qu'une houle de 1 mètre avec une période de 6 secondes.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Préparer sa session la veille</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La veille au soir, regardez les prévisions pour le lendemain matin : la hauteur et la période de la houle, sa direction, la force et la direction du vent, puis l'horaire de la marée. Repérez le créneau où un vent faible ou de terre coïncide avec la mi-marée : c'est souvent le meilleur moment de la journée. Le matin, la webcam confirme ou non ce que les prévisions annonçaient. Si la mer est plus grosse que prévu, ou si le vent s'est levé plus tôt, changez de plage ou d'horaire plutôt que de forcer. Les surfeurs qui progressent le plus vite ne sont pas ceux qui vont à l'eau le plus souvent, mais ceux qui y vont au bon moment.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">À quelle heure regarder la webcam ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le matin, entre le lever du soleil et le milieu de matinée, la mer est souvent plus lisse : en été, la brise de mer se lève l'après-midi et dégrade les vagues. C'est aussi le meilleur moment pour décider du programme de la journée. Regardez à nouveau une heure avant votre session : à Capbreton, les conditions changent vite avec la marée.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Petit lexique pour lire la webcam et les prévisions</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Houle : les vagues formées par le vent au large, parfois à des milliers de kilomètres, qui voyagent jusqu'à la côte.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Période : le temps, en secondes, entre deux vagues d'une même série. Plus elle est longue, plus la houle est puissante.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Série : un groupe de vagues plus grosses qui arrivent à la suite, entre deux moments calmes.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Vent offshore : le vent de terre, qui souffle vers le large. Il lisse et creuse les vagues.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Vent onshore : le vent de mer, qui souffle vers la plage. Il rend les vagues molles et désordonnées.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Glassy : une mer lisse comme un miroir, sans vent. Les conditions préférées des surfeurs.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Line-up : la zone, au-delà de la mousse, où les surfeurs attendent les vagues.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Pic : l'endroit où la vague commence à déferler. Le surfeur le plus proche du pic est prioritaire.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Shorebreak : une vague qui casse directement sur le bord, souvent à marée haute. Dangereuse pour les débutants.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Coefficient : la mesure de l'amplitude de la marée, de 20 à 120. Plus il est élevé, plus la mer monte et descend, et plus les courants sont forts.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Baïne : une dépression entre deux bancs de sable par laquelle l'eau repart vers le large, en créant un courant.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quand la webcam ne suffit pas</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Une image ne remplace pas l'œil d'un surfeur sur la plage. Une fois sur place, prenez quelques minutes pour observer : où les surfeurs rament-ils pour rejoindre le pic, où les vagues cassent-elles, où l'eau repart-elle vers le large ? En cours, c'est Paul qui fait ce travail et choisit la plage la plus sûre pour votre niveau. Pour aller plus loin, consultez notre guide des <a href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>">spots de surf de Capbreton</a>, ou réservez un <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">cours de surf à Capbreton</a> pour apprendre à lire la mer avec un moniteur.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
