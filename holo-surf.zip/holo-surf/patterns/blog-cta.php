<?php
/**
 * Title: Blog : appel à réserver
 * Slug: holo-surf/blog-cta
 * Categories: holo-surf
 * Viewport Width: 1440
 * Inserter: no
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-041a3d"} -->
<section class="wp-block-group u-041a3d">
<!-- wp:group {"className":"wrap reveal u-4bddbc"} -->
<div class="wp-block-group wrap reveal u-4bddbc">
<!-- wp:group {"className":"u-d1c8df"} -->
<div class="wp-block-group u-d1c8df">
<!-- wp:heading {"className":"h2 u-5a3306"} -->
<h2 class="wp-block-heading h2 u-5a3306">Prêt à mettre les conseils en pratique ?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-012250"} -->
<p class="u-012250">Cours collectifs, particuliers et coaching vidéo à Capbreton, matériel et assurance compris.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="min-height: 58px; font-size: 23px">Les cours et tarifs</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
