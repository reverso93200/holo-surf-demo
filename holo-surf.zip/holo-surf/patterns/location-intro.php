<?php
/**
 * Title: Location : Intro
 * Slug: holo-surf/location-intro
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-6d3d56"} -->
<section class="wp-block-group u-6d3d56">
<!-- wp:group {"className":"wrap u-0bc89f"} -->
<div class="wp-block-group wrap u-0bc89f">
<!-- wp:group {"className":"u-b99b40"} -->
<div class="wp-block-group u-b99b40">
<!-- wp:html -->
<nav aria-label="Fil d'Ariane" class="in crumb" style="margin-bottom: 26px; font-size: 14.5px; color: #55636A"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #55636A">Accueil</a> / <span aria-current="page" style="color: #192A33">Location</span></nav>
<!-- /wp:html -->

<!-- wp:heading {"level":1,"className":"in u-a7233e"} -->
<h1 class="wp-block-heading in u-a7233e">Location surf à Capbreton</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 kicker u-5469e7"} -->
<p class="in d1 kicker u-5469e7">Planches et combinaisons, tout le nécessaire pour aller surfer</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d1 u-9cfaef"} -->
<p class="in d1 u-9cfaef">Planches en mousse, hybrides et combinaisons, à l'heure, à la journée ou sur plusieurs jours.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"in d2 u-25904d"} -->
<div class="wp-block-group in d2 u-25904d">
<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="#tarifs" style="min-height: 56px; font-size: 22px">Les tarifs</a>
<a class="btn b-od" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="min-height: 56px; font-size: 22px">Contacter Paul</a>
<a class="lnk" href="#guide" style="align-self: center">Bien choisir son matériel</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"in d2 u-b126e6"} -->
<div class="wp-block-group in d2 u-b126e6">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"bob mimg-s ui-c5e477"} -->
<figure class="wp-block-image size-full bob mimg-s ui-c5e477"><img src="<?php echo esc_url( hs_img( '7deae58f184d2ff169cef3dbc6227b2d' ) ); ?>" alt="Planches en mousse Ocean Storm proposées à la location"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
