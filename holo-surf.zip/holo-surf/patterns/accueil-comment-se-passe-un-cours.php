<?php
/**
 * Title: Accueil : Comment se passe un cours
 * Slug: holo-surf/accueil-comment-se-passe-un-cours
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-bc8502"} -->
<section class="wp-block-group u-bc8502">
<!-- wp:group {"className":"wrap u-bbce1c"} -->
<div class="wp-block-group wrap u-bbce1c">
<!-- wp:group {"className":"reveal u-7ea1b5"} -->
<div class="wp-block-group reveal u-7ea1b5">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Comment se passe un cours ?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-0de1f9"} -->
<p class="p u-0de1f9">Chaque séance dure 1h30. Le lieu dépend de la houle, de la marée et de votre niveau. Le plus souvent, on se retrouve au Santocha.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 30px">Écrire à Paul</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-c4eb21"} -->
<div class="wp-block-group reveal u-c4eb21">
<!-- wp:group {"className":"u-32046d"} -->
<div class="wp-block-group u-32046d">
<!-- wp:heading {"level":3,"className":"h3 u-27c620"} -->
<h3 class="wp-block-heading h3 u-27c620">La réservation</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-b65ce1"} -->
<p class="p u-b65ce1">Vous envoyez vos dates, votre niveau et le nombre de surfeurs. Paul vous répond par e-mail pour fixer le créneau.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-32046d"} -->
<div class="wp-block-group u-32046d">
<!-- wp:heading {"level":3,"className":"h3 u-27c620"} -->
<h3 class="wp-block-heading h3 u-27c620">Le spot du jour</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-b65ce1"} -->
<p class="p u-b65ce1">Santocha, Capbreton, Hossegor ou Seignosse : on va là où les vagues conviennent à votre niveau.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-32046d"} -->
<div class="wp-block-group u-32046d">
<!-- wp:heading {"level":3,"className":"h3 u-27c620"} -->
<h3 class="wp-block-heading h3 u-27c620">Sur le sable</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-b65ce1"} -->
<p class="p u-b65ce1">Sécurité, courants et baïnes, lecture des vagues et échauffement avant d'aller à l'eau.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-32046d"} -->
<div class="wp-block-group u-32046d">
<!-- wp:heading {"level":3,"className":"h3 u-27c620"} -->
<h3 class="wp-block-heading h3 u-27c620">Dans l'eau</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-b65ce1"} -->
<p class="p u-b65ce1">Un maximum de vagues et des conseils en direct. En coaching vidéo, on regarde vos vagues ensemble à la sortie.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
