<?php
/**
 * Title: Les spots : seignosse
 * Slug: holo-surf/spots-seignosse
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-cbd47c"} -->
<section id="seignosse" class="wp-block-group u-cbd47c">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-b7f6ed"} -->
<div class="wp-block-group reveal u-b7f6ed">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Les spots de surf de Seignosse</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-c83bd2"} -->
<p class="p u-c83bd2">De longues plages sauvages et des beach breaks puissants, à surfer en mousse, en shortboard ou en longboard.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"zoom reveal townimg u-730f19"} -->
<div class="wp-block-group zoom reveal townimg u-730f19">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'ea460ba8de49e9474e6af6d1e0b445ee' ) ); ?>" alt="Un surfeur sur une vague à Seignosse"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="sp">
<li><div class="nm"><h3>Les Estagnots</h3><span class="lv">Capte plus de houle</span></div><p>Un beach break régulier qui reçoit plus de houle que ses voisins, les vagues y sont souvent plus grosses. Au mieux à mi-marée. Grand parking donc du monde, forts courants latéraux et baïnes.</p></li>
<li><div class="nm"><h3>Les Bourdaines</h3><span class="lv">Polyvalent</span></div><p>Entre les Estagnots et le Penon, moins fréquenté que son voisin du sud. Des vagues régulières et un stationnement facile.</p></li>
<li><div class="nm"><h3>Le Penon</h3><span class="lv">Vagues de qualité</span></div><p>Le plus au nord, accessible par le sud et par l'Agréou. Animé l'été avec son skatepark et ses commerces. Vagues régulières, mais courants et baïnes parfois forts.</p></li>
</ul>
<!-- /wp:html -->

<!-- wp:group {"className":"reveal u-c628b3"} -->
<div class="wp-block-group reveal u-c628b3">
<!-- wp:group {"className":"seo fold"} -->
<div id="seo-ss" class="wp-block-group seo fold">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Surfer à Seignosse : ce qu'il faut savoir</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Au nord d'Hossegor, Seignosse offre des plages plus sauvages, bordées de dunes et de pins. Les beach breaks y sont puissants et réguliers, avec des vagues pour la mousse, le shortboard et le longboard.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Trois plages, trois ambiances</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les Estagnots captent plus de houle que leurs voisins, ce qui en fait souvent la plage aux plus grosses vagues de Seignosse. Leur grand parking attire du monde. Les Bourdaines, entre les Estagnots et le Penon, sont plus tranquilles, avec des vagues régulières et un stationnement facile. Le Penon, le plus au nord, est le cœur animé de Seignosse en été, avec son skatepark et ses commerces.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Pour quel niveau ?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Seignosse convient surtout aux surfeurs intermédiaires et confirmés. Les débutants peuvent y surfer par petite houle, accompagnés d'un moniteur et en restant dans la mousse. Dès que la houle monte, les Estagnots deviennent vite engagés, et le Penon demande de bien connaître les courants.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Les courants à Seignosse</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les courants latéraux y sont souvent forts : ils vous déportent le long de la plage sans que vous vous en rendiez compte. Prenez un repère fixe sur la plage avant d'aller à l'eau, comme un poste de secours ou une descente de dune, et vérifiez régulièrement votre position. Les baïnes sont présentes toute l'année et peuvent être fortes.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Quand surfer à Seignosse</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Comme Hossegor, Seignosse est à son meilleur à l'automne. Les Estagnots, qui captent plus de houle, restent surfables les jours où les autres plages sont trop petites. Au mieux à mi-marée, avec un vent faible ou venu de l'est.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Mousse, shortboard ou longboard ?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les jours de petite houle, une planche à volume, mousse ou longboard, permet de profiter de vagues que les planches courtes ne prennent pas. Quand la houle grossit, la puissance des vagues de Seignosse demande une planche plus courte, de bonnes épaules et l'habitude des courants. Si vous louez votre matériel, choisissez-le en fonction des conditions du jour plutôt que de vos habitudes.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Respecter la dune</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les plages de Seignosse sont protégées par un cordon dunaire fragile. Empruntez les accès balisés, ne marchez pas dans la dune et ne laissez rien derrière vous : ce sont les gestes simples que l'école transmet à chaque cours.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
