<?php
/**
 * Title: Les cours et tarifs : Guide SEO
 * Slug: holo-surf/cours-guide-seo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-503146"} -->
<section id="guide" class="wp-block-group u-503146">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"stick reveal u-67a893"} -->
<div class="wp-block-group stick reveal u-67a893">
<!-- wp:heading {"className":"h2"} -->
<h2 id="guide-t" class="wp-block-heading h2">Tout savoir avant votre cours de surf à Capbreton</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Choisir sa formule, préparer la séance, savoir combien de cours prévoir : les questions à se poser avant de réserver.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-f6967f"} -->
<div class="wp-block-group u-f6967f">
<!-- wp:group {"className":"seo fold"} -->
<div id="seo-s1" class="wp-block-group seo fold">
<!-- wp:paragraph -->
<p>Un cours de surf à Capbreton avec Holo Surf dure 1h30, matériel et assurance compris, et se déroule le plus souvent au Santocha. Voici comment choisir la bonne formule, ce qu'il faut prévoir et comment se passe une séance, de la réservation à la sortie de l'eau.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Collectif, particulier ou coaching vidéo : quelle formule choisir ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le cours collectif est la porte d'entrée la plus simple. Jusqu'à huit surfeurs de niveau proche partagent la séance, ce qui crée de l'émulation : on se motive, on rit de ses chutes et on fête ses premières vagues ensemble. C'est aussi la formule la plus économique, de [holo_prix k="collectif_bs_1"] la séance à [holo_prix k="collectif_bs_6"] par cours à partir de six, hors juillet-août. Elle convient très bien à une initiation ou à une semaine de vacances avec un cours par jour.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Le cours particulier s'adresse à ceux qui veulent un accompagnement plus serré. Seul, en couple, entre amis ou en famille, jusqu'à quatre personnes du même groupe, vous avez Paul pour vous et la séance suit entièrement vos objectifs : se lever pour la première fois, passer la barre, choisir ses vagues. Comptez [holo_prix k="particulier_1"] pour une personne, et [holo_prix k="particulier_pp3"] par personne à partir de trois. Le tarif reste le même toute l'année.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Le coaching vidéo est pensé pour les surfeurs qui tiennent déjà debout. Vous êtes filmé dans l'eau, avec des exercices ciblés sur vos points à travailler, puis vos vagues sont analysées ensemble à la sortie. On voit enfin ce que l'on fait vraiment sur la planche : position des pieds, regard, vitesse, placement sur la vague. De [holo_prix k="coaching_1"] seul à [holo_prix k="coaching_pp4"] par personne à quatre.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Comment se déroule un cours de surf ?</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li>La réservation. Vous écrivez à Paul avec vos dates, votre niveau et le nombre de surfeurs. Il vous répond par e-mail avec le créneau et le lieu du rendez-vous, choisi selon la houle, le vent et la marée.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Sur le sable. Chacun reçoit une planche et une combinaison adaptées à sa taille et à son niveau. On commence par la sécurité : les courants, les baïnes, les zones à éviter, puis la lecture des vagues. Échauffement, puis répétition au sol du take-off, le mouvement qui permet de passer de la position allongée à la position debout.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Dans l'eau. Les débutants commencent dans la mousse, là où ils ont pied, pour multiplier les tentatives. Selon le niveau, on va ensuite chercher les vagues plus loin. Paul donne des conseils en direct, vague après vague.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>À la sortie. On fait le point sur ce qui a fonctionné et sur ce qu'il faut travailler la prochaine fois. En coaching vidéo, c'est le moment de l'analyse des images.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Faut-il savoir nager ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Oui. Même si les débutants restent là où ils ont pied, l'océan bouge en permanence et il faut être à l'aise dans l'eau. Si vous avez un doute, pour vous ou pour un enfant, signalez-le lors de la réservation : Paul adaptera le spot et le format du cours.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Que faut-il apporter ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La planche, la combinaison et l'assurance sont fournies. Prévoyez simplement un maillot de bain à porter sous la combinaison, une serviette, de la crème solaire résistante à l'eau, de l'eau à boire et une tenue chaude pour la sortie, surtout au printemps et à l'automne. En cours particulier et en coaching vidéo, vous pouvez venir avec votre propre matériel.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Dès quel âge peut-on surfer ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les cours commencent dès 5 ans. Les plus jeunes surfent dans des vagues adaptées, en petit groupe, avec des lycras de couleur qui permettent de les repérer d'un coup d'œil. Il n'y a pas d'âge limite pour commencer : on peut découvrir le surf à 30, 40 ou 60 ans. Ce qui compte, c'est d'être à l'aise dans l'eau et d'avoir envie d'apprendre.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Combien de cours pour surfer seul ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Beaucoup de débutants se mettent debout dans la mousse dès les premières séances. Pour surfer en autonomie, c'est-à-dire choisir sa plage, repérer les courants, passer la barre et prendre des vagues vertes, il faut plutôt compter une série de cinq à dix cours, idéalement rapprochés. C'est pour cette raison que le prix des cours collectifs baisse avec le nombre de séances : à partir de six, chaque cours revient à [holo_prix k="collectif_bs_6"] hors juillet-août et [holo_prix k="collectif_hs_6"] en juillet et en août.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Basse saison ou haute saison ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les cours collectifs passent au tarif haute saison en juillet et en août, de [holo_prix k="collectif_hs_1"] la séance à [holo_prix k="collectif_hs_6"] par cours à partir de six. Les cours particuliers et le coaching vidéo gardent le même prix toute l'année. Hors été, les plages sont plus calmes et les houles plus régulières : le printemps et l'automne sont d'excellentes périodes pour apprendre, avec une combinaison un peu plus épaisse.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Où ont lieu les cours ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le plus souvent au Santocha, à Capbreton : une plage large, une pente douce et des vagues régulières, idéales pour apprendre. L'école étant itinérante, le spot peut changer selon les conditions et votre niveau, vers une autre plage de Capbreton, d'Hossegor ou de Seignosse. Vous connaissez toujours le lieu à l'avance. Pour découvrir chaque plage, consultez notre guide des <a href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>">spots de surf</a>, et la veille du cours, jetez un œil à la <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>">webcam de Capbreton</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quand réserver ?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En juillet et en août, les demandes sont nombreuses : écrivez plusieurs jours à l'avance, surtout pour un cours particulier. Le reste de l'année, quelques jours suffisent en général. Pour un groupe, un EVG ou un événement d'entreprise, prévenez le plus tôt possible pour recevoir un devis.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Entre deux cours</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Pour pratiquer seul quand vous avez les bases, l'école propose la <a href="<?php echo esc_url( hs_url( 'Location' ) ); ?>">location de planches et de combinaisons à Capbreton</a>, à l'heure, à la journée ou sur plusieurs jours. Et pour comprendre comment on choisit le spot de chaque séance, découvrez le fonctionnement de notre <a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>">école de surf à Capbreton</a>.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
