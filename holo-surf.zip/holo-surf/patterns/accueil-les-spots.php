<?php
/**
 * Title: Accueil : Les spots
 * Slug: holo-surf/accueil-les-spots
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-7131a3"} -->
<section id="spots" class="wp-block-group u-7131a3">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-0914c2"} -->
<div class="wp-block-group reveal u-0914c2">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Les spots</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-dfd539"} -->
<p class="p u-dfd539">L'école est itinérante. Selon les conditions et vos objectifs, on surfe à Capbreton, Hossegor ou Seignosse.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal tiles3 u-2f1c0a"} -->
<div class="wp-block-group reveal tiles3 u-2f1c0a">
<!-- wp:html -->
<a class="zoom" href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>#capbreton" style="flex: 1 1 320px; min-width: 0; height: 460px; position: relative; display: block; color: #FFFFFF; text-decoration: none">
<img alt="La plage du Santocha à Capbreton et ses blockhaus" decoding="async" height="683" loading="lazy" src="<?php echo esc_url( hs_img( 'e4fe848118a1099a3a24a2e83acd3ed7' ) ); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover" width="1024"/>
<span aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: 0; height: 65%; background: linear-gradient(180deg, rgba(25,42,51,0), rgba(25,42,51,0.85))"></span>
<span style="position: absolute; left: 28px; right: 28px; bottom: 26px"><span class="tname" style="display: block; font-family: 'Bebas Neue', sans-serif; font-size: 66px; line-height: 0.9">Capbreton</span><span style="display: block; margin-top: 8px; font-size: 16px; line-height: 1.5">Le Santocha, La Centrale, Le Prévent, La Piste, Les Océanides</span></span>
</a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="zoom" href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>#hossegor" style="flex: 1 1 320px; min-width: 0; height: 460px; position: relative; display: block; color: #FFFFFF; text-decoration: none">
<img alt="Une vague à Hossegor avec les Pyrénées au loin" decoding="async" height="674" loading="lazy" src="<?php echo esc_url( hs_img( 'a67cb1a03e4015e525f7e0eb9f452cc5' ) ); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover" width="1200"/>
<span aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: 0; height: 65%; background: linear-gradient(180deg, rgba(25,42,51,0), rgba(25,42,51,0.85))"></span>
<span style="position: absolute; left: 28px; right: 28px; bottom: 26px"><span class="tname" style="display: block; font-family: 'Bebas Neue', sans-serif; font-size: 66px; line-height: 0.9">Hossegor</span><span style="display: block; margin-top: 8px; font-size: 16px; line-height: 1.5">La Sud, La Gravière, La Nord, Les Culs Nus</span></span>
</a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="zoom" href="<?php echo esc_url( hs_url( 'Spots' ) ); ?>#seignosse" style="flex: 1 1 320px; min-width: 0; height: 460px; position: relative; display: block; color: #FFFFFF; text-decoration: none">
<img alt="Un surfeur sur une vague à Seignosse" decoding="async" height="675" loading="lazy" src="<?php echo esc_url( hs_img( 'ea460ba8de49e9474e6af6d1e0b445ee' ) ); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover" width="1200"/>
<span aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: 0; height: 65%; background: linear-gradient(180deg, rgba(25,42,51,0), rgba(25,42,51,0.85))"></span>
<span style="position: absolute; left: 28px; right: 28px; bottom: 26px"><span class="tname" style="display: block; font-family: 'Bebas Neue', sans-serif; font-size: 66px; line-height: 0.9">Seignosse</span><span style="display: block; margin-top: 8px; font-size: 16px; line-height: 1.5">Les Estagnots, Les Bourdaines, Le Penon</span></span>
</a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
