<?php
/**
 * Title: Accueil : Concours
 * Slug: holo-surf/accueil-concours
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-67b27d"} -->
<section class="wp-block-group u-67b27d">
<!-- wp:group {"className":"wrap reveal u-944b95"} -->
<div class="wp-block-group wrap reveal u-944b95">
<!-- wp:paragraph {"className":"u-d82184"} -->
<p class="u-d82184">Grand jeu concours : gagne ta planche de surf et des cours personnalisés</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Concours' ) ); ?>">Je participe</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
