<?php
/**
 * Title: Réserver mon cours : section
 * Slug: holo-surf/reserver-section
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-bc356b"} -->
<section class="wp-block-group u-bc356b">
<!-- wp:group {"className":"wrap u-8a60e2"} -->
<div class="wp-block-group wrap u-8a60e2">
<!-- wp:group {"className":"in d2 cbox u-16620e"} -->
<div class="wp-block-group in d2 cbox u-16620e">
<!-- wp:shortcode -->
[holo_reservation]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<aside aria-label="Coordonnées" class="in d3 cbox" style="flex: 1 1 380px; min-width: 0; background: #192A33; color: #FFFFFF; padding: 48px; box-sizing: border-box">
<p style="margin: 0; font-family: 'Bebas Neue', sans-serif; font-size: 36px; line-height: 1">Disponible 24h/7j</p>
<p style="margin: 8px 0 28px; font-size: 16.5px; line-height: 1.6; color: #C9D4D9">pour tout appel ou informations.</p>
[holo_coordonnees]
</aside>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"wrap u-21dc25"} -->
<div class="wp-block-group wrap u-21dc25">
<!-- wp:group {"className":"reveal mapf u-5dafbf"} -->
<div class="wp-block-group reveal mapf u-5dafbf">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-de14c8"} -->
<figure class="wp-block-image size-full ui-de14c8"><img src="<?php echo esc_url( hs_img( '038cdb79f92c60fc87e4bde1fc2e1bf6' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"u-794ff7"} -->
<div class="wp-block-group u-794ff7">
<!-- wp:html -->
<button class="btn b-sand" style="width: auto; min-height: 50px" type="button">Afficher la carte</button>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><span style="font-size: 14.5px; color: #FFFFFF">Plage du Santocha, Capbreton. La carte Google se charge au clic.</span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
