<?php
/**
 * Title: Les spots : Guide SEO
 * Slug: holo-surf/spots-guide-seo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5dd5ac"} -->
<section id="choisir" class="wp-block-group u-5dd5ac">
<!-- wp:group {"className":"wrap u-ab666a"} -->
<div class="wp-block-group wrap u-ab666a">
<!-- wp:group {"className":"stick reveal u-67a893"} -->
<div class="wp-block-group stick reveal u-67a893">
<!-- wp:heading {"className":"h2"} -->
<h2 id="choisir-t" class="wp-block-heading h2">Choisir son spot de surf selon son niveau</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-fc696d"} -->
<p class="p u-fc696d">Débutant, intermédiaire ou confirmé : les repères pour trouver la bonne plage, et les règles à connaître avant d'aller à l'eau.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-f6967f"} -->
<div class="wp-block-group u-f6967f">
<!-- wp:group {"className":"seo fold oncream"} -->
<div id="seo-sg" class="wp-block-group seo fold oncream">
<!-- wp:paragraph -->
<p>Choisir un spot de surf, ce n'est pas seulement choisir une plage. C'est trouver, pour un jour donné, l'endroit où la taille des vagues, le vent, la marée et les courants correspondent à votre niveau. Voici les repères à appliquer entre Capbreton, Hossegor et Seignosse.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Vous débutez</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cherchez une plage à pente douce, des vagues qui déferlent en mousse et des courants faibles. Le Santocha, La Centrale et Le Prévent à Capbreton, ou La Sud à Hossegor, sont les plus adaptés par petite ou moyenne houle. Restez là où vous avez pied, dans la zone de surf en été, et évitez les abords des épis et des blockhaus. Le plus sûr reste de surfer avec un moniteur : vous apprenez au bon endroit dès le départ.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Vous passez la barre</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Quand vous savez vous lever et ramer au-delà de la mousse, vous pouvez découvrir des vagues plus techniques : La Piste à Capbreton, les Bourdaines ou le Penon à Seignosse, par houle modérée. C'est aussi le moment d'apprendre à repérer le pic, l'endroit où la vague casse en premier, et le chenal, plus calme, qui permet de le rejoindre.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Vous êtes confirmé</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Les Océanides, les Culs Nus et les Estagnots, puis La Gravière et La Nord pour les experts : ces vagues sont creuses, rapides et puissantes, avec des courants forts. Elles demandent une excellente condition physique et une vraie connaissance de la mer.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Observer avant d'aller à l'eau</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Prenez cinq à dix minutes sur la plage avant chaque session :</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>repérez où les vagues cassent et où les surfeurs rament pour rejoindre le pic ;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>attendez une série complète pour voir la taille des plus grosses vagues ;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>cherchez les zones où l'eau repart vers le large, signe d'une baïne ;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>choisissez un repère fixe sur la plage pour vérifier que le courant ne vous déporte pas.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Les règles de priorité</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le surfeur le plus proche du pic est prioritaire. Ne partez pas sur une vague déjà prise, ne lâchez pas votre planche quand une vague arrive, et quand vous ramez vers le large, passez par la mousse plutôt que devant un surfeur qui prend une vague. Ces règles évitent la plupart des accidents, de Capbreton à Seignosse.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Avant de partir</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Regardez la <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>">webcam de Capbreton</a> et les prévisions, vérifiez l'horaire de la marée et lisez notre page sur <a href="<?php echo esc_url( hs_url( 'InfosSurf' ) ); ?>#baines">les baïnes</a>. Si vous hésitez sur votre niveau, un <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>">cours de surf à Capbreton</a> vous permet de surfer au bon endroit et d'apprendre à choisir vos spots. Pour pratiquer seul, la <a href="<?php echo esc_url( hs_url( 'Location' ) ); ?>">location de surf à Capbreton</a> vous équipe pour la journée.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
