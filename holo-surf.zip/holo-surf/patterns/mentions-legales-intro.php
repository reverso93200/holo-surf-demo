<?php
/**
 * Title: Mentions légales : Intro
 * Slug: holo-surf/mentions-legales-intro
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-aa15a7"} -->
<section class="wp-block-group u-aa15a7">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:paragraph {"className":"in crumb u-d75df9"} -->
<p class="in crumb u-d75df9"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #55636A">Accueil</a> / Mentions légales</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"in d1 u-bd76b0"} -->
<h1 class="wp-block-heading in d1 u-bd76b0">Mentions légales</h1>
<!-- /wp:heading -->

<!-- wp:html -->
<div aria-label="Pages légales" class="tabs in d2" role="tablist" style="margin-top: 40px">
<button aria-controls="mentions" aria-selected="true" id="tab-mentions" role="tab" type="button">Mentions légales</button>
<button aria-controls="cookies" aria-selected="false" id="tab-cookies" role="tab" type="button">Politique en matière de cookies</button>
<button aria-controls="confidentialite" aria-selected="false" id="tab-confidentialite" role="tab" type="button">Politique de confidentialité</button>
<button aria-controls="conditions" aria-selected="false" id="tab-conditions" role="tab" type="button">Conditions d'utilisation</button>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
