<?php
/**
 * Title: Accueil : Pourquoi surfer avec Holo
 * Slug: holo-surf/accueil-pourquoi-surfer-avec-holo
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-969c6a"} -->
<section class="wp-block-group u-969c6a">
<!-- wp:group {"className":"u-fc795e"} -->
<div class="wp-block-group u-fc795e">
<!-- wp:group {"className":"zoom mimg u-830c2d"} -->
<div class="wp-block-group zoom mimg u-830c2d">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-4a3c4f"} -->
<figure class="wp-block-image size-full ui-4a3c4f"><img src="<?php echo esc_url( hs_img( 'a923f007d594b1f2873440aed578cb43' ) ); ?>" alt="Surfeur allongé sur sa planche dans une eau turquoise, vu du ciel"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-ad7a13"} -->
<div class="wp-block-group reveal u-ad7a13">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Pourquoi choisir notre école de surf ?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-1d08f6"} -->
<p class="u-1d08f6">Des cours pour tous à partir de 5 ans. Que vous ayez envie de découvrir le surf et son environnement ou de vous perfectionner, il y aura toujours une vague pour vous !</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"u-0dd0fa"} -->
<div class="wp-block-group u-0dd0fa">
<!-- wp:group {"className":"u-ad654a"} -->
<div class="wp-block-group u-ad654a">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-1e37fc"} -->
<figure class="wp-block-image size-full ui-1e37fc"><img src="<?php echo esc_url( hs_img( 'e8d41159726ca97b3fe3268639ef8b92' ) ); ?>" alt="Label Ecosafe Surfing"/></figure>
<!-- /wp:image -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3,"className":"h3 u-96d2bf"} -->
<h3 class="wp-block-heading h3 u-96d2bf">Encadrement sécurisé</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-f254cb"} -->
<p class="p u-f254cb">Labellisée Ecosafe Surfing, l'école allie sécurité et respect de l'environnement.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-b57a4e"} -->
<div class="wp-block-group u-b57a4e">
<!-- wp:heading {"level":3,"className":"h3 u-96d2bf"} -->
<h3 class="wp-block-heading h3 u-96d2bf">Pédagogie fun et efficace</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-f254cb"} -->
<p class="p u-f254cb">Apprenez à surfer en vous amusant ! Votre moniteur adapte son enseignement à votre rythme pour une progression rapide.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-b57a4e"} -->
<div class="wp-block-group u-b57a4e">
<!-- wp:heading {"level":3,"className":"h3 u-96d2bf"} -->
<h3 class="wp-block-heading h3 u-96d2bf">Spots adaptés à votre niveau</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-f254cb"} -->
<p class="p u-f254cb">Du Santocha aux meilleures vagues de Capbreton, Seignosse et Hossegor. Holo Surf s'adapte à votre niveau et à vos objectifs.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 36px">Réserver maintenant</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
