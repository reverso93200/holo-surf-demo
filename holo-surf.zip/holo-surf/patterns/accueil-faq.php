<?php
/**
 * Title: Accueil : FAQ
 * Slug: holo-surf/accueil-faq
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-bc8502"} -->
<section class="wp-block-group u-bc8502">
<!-- wp:group {"className":"wrap u-0a2e57"} -->
<div class="wp-block-group wrap u-0a2e57">
<!-- wp:heading {"className":"h2 reveal u-919b25"} -->
<h2 class="wp-block-heading h2 reveal u-919b25">Questions fréquentes</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"faq reveal u-194198"} -->
<div class="wp-block-group faq reveal u-194198">
<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>Dès quel âge peut-on prendre un cours ?</summary>
<!-- wp:paragraph -->
<p>Dès 5 ans, en cours collectif comme en cours particulier.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Le matériel est-il fourni ?</summary>
<!-- wp:paragraph -->
<p>Oui, planche, combinaison et assurance sont comprises dans le prix. Pour les cours particuliers et le coaching vidéo, vous pouvez aussi venir avec votre matériel.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Où ont lieu les cours ?</summary>
<!-- wp:paragraph -->
<p>Généralement au Santocha, à Capbreton. Selon les conditions et vos objectifs, on peut aller surfer sur d'autres spots.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Les cours sont-ils proposés en anglais ou en espagnol ?</summary>
<!-- wp:paragraph -->
<p>Oui. We speak English, hablamos español.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
