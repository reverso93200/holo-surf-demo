<?php
/**
 * Title: Infos surf : Vagues
 * Slug: holo-surf/infos-surf-vagues
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-874b35"} -->
<section id="vagues" class="wp-block-group u-874b35">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-b7f6ed"} -->
<div class="wp-block-group reveal u-b7f6ed">
<!-- wp:heading {"className":"h2 u-6f4d96"} -->
<h2 class="wp-block-heading h2 u-6f4d96">Les vagues</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-976be0"} -->
<p class="u-976be0">Une vague naît souvent à des milliers de kilomètres de nos plages. Voici les cinq étapes de sa vie.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ol class="reveal" style="list-style: none; padding: 0; margin: 48px 0 0; border-top: 1px solid #2C4250">
<li style="display: flex; flex-wrap: wrap; gap: 6px 40px; padding: 24px 0; border-bottom: 1px solid #2C4250"><h3 class="h3" style="flex: 0 0 260px; font-size: 34px; color: #FFFFFF">1. La naissance</h3><p style="flex: 1 1 360px; margin: 0; font-size: 17px; line-height: 1.65; color: #C9D4D9">Au large, des masses d'air se rencontrent et créent une zone de basse pression.</p></li>
<li style="display: flex; flex-wrap: wrap; gap: 6px 40px; padding: 24px 0; border-bottom: 1px solid #2C4250"><h3 class="h3" style="flex: 0 0 260px; font-size: 34px; color: #FFFFFF">2. La croissance</h3><p style="flex: 1 1 360px; margin: 0; font-size: 17px; line-height: 1.65; color: #C9D4D9">Le vent souffle sur une grande distance, le fetch, et creuse la mer.</p></li>
<li style="display: flex; flex-wrap: wrap; gap: 6px 40px; padding: 24px 0; border-bottom: 1px solid #2C4250"><h3 class="h3" style="flex: 0 0 260px; font-size: 34px; color: #FFFFFF">3. La maturité</h3><p style="flex: 1 1 360px; margin: 0; font-size: 17px; line-height: 1.65; color: #C9D4D9">La mer est formée et les vagues atteignent leur taille maximale.</p></li>
<li style="display: flex; flex-wrap: wrap; gap: 6px 40px; padding: 24px 0; border-bottom: 1px solid #2C4250"><h3 class="h3" style="flex: 0 0 260px; font-size: 34px; color: #FFFFFF">4. La propagation</h3><p style="flex: 1 1 360px; margin: 0; font-size: 17px; line-height: 1.65; color: #C9D4D9">La houle voyage jusqu'à la côte et s'organise en séries.</p></li>
<li style="display: flex; flex-wrap: wrap; gap: 6px 40px; padding: 24px 0; border-bottom: 1px solid #2C4250"><h3 class="h3" style="flex: 0 0 260px; font-size: 34px; color: #FFFFFF">5. Le déferlement</h3><p style="flex: 1 1 360px; margin: 0; font-size: 17px; line-height: 1.65; color: #C9D4D9">Quand la profondeur ne fait plus qu'environ 1,3 fois la hauteur de la vague, elle se creuse et déferle.</p></li>
</ol>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
