<?php
/**
 * Title: Accueil : Formules et tarifs
 * Slug: holo-surf/accueil-formules-et-tarifs
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-5b9631"} -->
<section id="cours" class="wp-block-group u-5b9631">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-798606"} -->
<div class="wp-block-group reveal u-798606">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Formules et tarifs</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="font-size: 17px">Voir tous les tarifs</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal cards4 u-c5d581"} -->
<div class="wp-block-group reveal cards4 u-c5d581">
<!-- wp:group {"tagName":"article","className":"u-673ff4"} -->
<article class="wp-block-group u-673ff4">
<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","linkClass":"zoom u-a43326","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><a class="zoom u-a43326" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>"><img src="<?php echo esc_url( hs_img( 'c1658a8054f881a4d5d2929fda8cbc74' ) ); ?>" alt="Cours collectif sur le sable du Santocha avant d'aller à l'eau"/></a></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"h3 u-6a2215"} -->
<h3 class="wp-block-heading h3 u-6a2215">Cours collectifs</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-9d9f75"} -->
<p class="p u-9d9f75">Apprenez en groupe, progressez ensemble.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<dl style="margin: 18px 0 0; border-top: 1px solid #ECE4D3; font-size: 16px">
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Durée</dt><dd style="margin: 0; font-weight: 600">1h30</dd></div>
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Groupe</dt><dd style="margin: 0; font-weight: 600">8 surfeurs maximum</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"u-8976ab"} -->
<p class="u-8976ab">À partir de <span style="font-family: 'Bebas Neue', sans-serif; font-size: 42px; line-height: 1; color: #192A33; vertical-align: -5px">[holo_prix k="collectif_bs_6"]</span></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="margin-top: 14px; align-self: flex-start">Infos et tarifs</a></p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-673ff4"} -->
<article class="wp-block-group u-673ff4">
<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","linkClass":"zoom u-a43326","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><a class="zoom u-a43326" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>"><img src="<?php echo esc_url( hs_img( 'dabea7a64c36488fdd75a01412fbf2bf' ) ); ?>" alt="Paul accompagne une élève dans les vagues pendant un cours particulier"/></a></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"h3 u-6a2215"} -->
<h3 class="wp-block-heading h3 u-6a2215">Cours particuliers</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-9d9f75"} -->
<p class="p u-9d9f75">Un accompagnement sur mesure, seul, entre amis, en couple ou en famille.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<dl style="margin: 18px 0 0; border-top: 1px solid #ECE4D3; font-size: 16px">
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Durée</dt><dd style="margin: 0; font-weight: 600">1h30</dd></div>
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Groupe</dt><dd style="margin: 0; font-weight: 600">Jusqu'à 4 surfeurs</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"u-8976ab"} -->
<p class="u-8976ab">À partir de <span style="font-family: 'Bebas Neue', sans-serif; font-size: 42px; line-height: 1; color: #192A33; vertical-align: -5px">[holo_prix k="particulier_pp3"]</span> par personne</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="margin-top: 14px; align-self: flex-start">Infos et tarifs</a></p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-673ff4"} -->
<article class="wp-block-group u-673ff4">
<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","linkClass":"zoom u-a43326","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><a class="zoom u-a43326" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>"><img src="<?php echo esc_url( hs_img( 'e7709b3444786e99e95b2bae884230da' ) ); ?>" alt="Paul, moniteur de Holo Surf, en virage sur une vague"/></a></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"h3 u-6a2215"} -->
<h3 class="wp-block-heading h3 u-6a2215">Coaching vidéo</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-9d9f75"} -->
<p class="p u-9d9f75">Analyse vidéo pour une progression personnalisée, rapide et efficace.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<dl style="margin: 18px 0 0; border-top: 1px solid #ECE4D3; font-size: 16px">
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Durée</dt><dd style="margin: 0; font-weight: 600">1h30</dd></div>
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Groupe</dt><dd style="margin: 0; font-weight: 600">Jusqu'à 4 surfeurs</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"u-8976ab"} -->
<p class="u-8976ab">À partir de <span style="font-family: 'Bebas Neue', sans-serif; font-size: 42px; line-height: 1; color: #192A33; vertical-align: -5px">[holo_prix k="coaching_pp4"]</span> par personne</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>" style="margin-top: 14px; align-self: flex-start">Infos et tarifs</a></p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-673ff4"} -->
<article class="wp-block-group u-673ff4">
<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","linkClass":"zoom u-a43326","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><a class="zoom u-a43326" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>"><img src="<?php echo esc_url( hs_img( '364b827c81e2a9ff461ab7e676448788' ) ); ?>" alt="Deux surfeurs dans l'eau au coucher du soleil à Capbreton"/></a></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"h3 u-6a2215"} -->
<h3 class="wp-block-heading h3 u-6a2215">Sur mesure</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-9d9f75"} -->
<p class="p u-9d9f75">EVG, EVJF, évènements d'entreprise, colonies de vacances, campings…</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<dl style="margin: 18px 0 0; border-top: 1px solid #ECE4D3; font-size: 16px">
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Pour</dt><dd style="margin: 0; font-weight: 600">Groupes et entreprises</dd></div>
<div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #ECE4D3"><dt style="color: #55636A">Format</dt><dd style="margin: 0; font-weight: 600">À la demande</dd></div>
</dl>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"u-3cf24c"} -->
<p class="u-3cf24c">Sur devis</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="lnk" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 14px; align-self: flex-start">Demander un devis</a></p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
