<?php
/**
 * Title: Concours 2026 : Les lots
 * Slug: holo-surf/concours-les-lots
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-57081f"} -->
<section class="wp-block-group u-57081f">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:heading {"className":"h2 reveal"} -->
<h2 class="wp-block-heading h2 reveal">Les lots</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"reveal u-cc8eee"} -->
<div class="wp-block-group reveal u-cc8eee">
<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-02b528"} -->
<div class="wp-block-group zoom u-02b528">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-33fb98"} -->
<figure class="wp-block-image size-full ui-33fb98"><img src="<?php echo esc_url( hs_img( '7deae58f184d2ff169cef3dbc6227b2d' ) ); ?>" alt="Planche Ocean Storm 7'6"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"u-57b1e1"} -->
<p class="u-57b1e1">Lot n°1, jeu clients</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"h3 u-07c6a7"} -->
<h3 class="wp-block-heading h3 u-07c6a7">Planche Ocean Storm 7'6 Weekender</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">Une planche neuve, choisie par Holo Surf et Ocean Storm. Remise du lot à Capbreton.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-1e487c"} -->
<div class="wp-block-group zoom u-1e487c">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'c1658a8054f881a4d5d2929fda8cbc74' ) ); ?>" alt="Groupe en stage de surf sur la plage à Capbreton"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"u-57b1e1"} -->
<p class="u-57b1e1">Lot n°2, jeu Instagram</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"h3 u-07c6a7"} -->
<h3 class="wp-block-heading h3 u-07c6a7">Stage de surf de 5 jours</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">Cinq séances d'affilée avec un moniteur diplômé d'État, du niveau débutant à intermédiaire. Matériel fourni, petit groupe et conseils personnalisés.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"u-5741ef"} -->
<article class="wp-block-group u-5741ef">
<!-- wp:group {"className":"zoom u-1e487c"} -->
<div class="wp-block-group zoom u-1e487c">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-d3878f"} -->
<figure class="wp-block-image size-full ui-d3878f"><img src="<?php echo esc_url( hs_img( 'd7998c9e816d82c8acf6c8b945419594' ) ); ?>" alt="Paul encourage une élève pendant un cours particulier"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"u-57b1e1"} -->
<p class="u-57b1e1">Lot n°3, jeu Instagram</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"h3 u-07c6a7"} -->
<h3 class="wp-block-heading h3 u-07c6a7">Cours particulier ou coaching vidéo</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-8ced3a"} -->
<p class="p u-8ced3a">Une séance en solo avec un moniteur diplômé, ou un coaching vidéo avec analyse avant, pendant et après la session.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
