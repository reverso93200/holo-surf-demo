<?php
/**
 * Title: À propos : CTA
 * Slug: holo-surf/a-propos-cta
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-22f907"} -->
<section class="wp-block-group u-22f907">
<!-- wp:group {"className":"wrap reveal u-4bddbc"} -->
<div class="wp-block-group wrap reveal u-4bddbc">
<!-- wp:heading {"className":"h2 u-5f4821"} -->
<h2 class="wp-block-heading h2 u-5f4821">Rejoignez-moi pour vibrer avec l'océan</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="min-height: 58px; font-size: 23px">Réserver mon cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
