<?php
/**
 * Title: Les cours et tarifs : Coaching vidéo
 * Slug: holo-surf/cours-coaching-video
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-1b92fa"} -->
<section id="coaching" class="wp-block-group u-1b92fa">
<!-- wp:group {"className":"wrap u-9ce1d5"} -->
<div class="wp-block-group wrap u-9ce1d5">
<!-- wp:group {"className":"reveal u-7a0035"} -->
<div class="wp-block-group reveal u-7a0035">
<!-- wp:group {"className":"zoom"} -->
<div class="wp-block-group zoom">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-9753a5"} -->
<figure class="wp-block-image size-full ui-9753a5"><img src="<?php echo esc_url( hs_img( 'ea460ba8de49e9474e6af6d1e0b445ee' ) ); ?>" alt="Surfeur filmé sur une vague à Seignosse pendant un coaching vidéo"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"className":"h2 u-3d941b"} -->
<h2 class="wp-block-heading h2 u-3d941b">Coaching vidéo surf</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"u-2d4996"} -->
<p class="u-2d4996">Progressez avec un regard extérieur grâce au coaching vidéo !</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Vous êtes filmé, avec des exercices pour travailler les points clés. À la sortie de l'eau, on analyse vos vagues ensemble avec des conseils techniques personnalisés pour affiner votre style et corriger vos erreurs. Cours d'1h30, 4 personnes maximum. Le prix inclut le matériel, l'assurance, l'analyse vidéo et les conseils.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"p u-5bcd7a"} -->
<p class="p u-5bcd7a">Idéal pour un perfectionnement précis et une progression accélérée.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal u-d1c8df"} -->
<div class="wp-block-group reveal u-d1c8df">
<!-- wp:shortcode -->
[holo_tarifs type="coaching"]
<!-- /wp:shortcode -->

<!-- wp:paragraph {"className":"p u-155f08"} -->
<p class="p u-155f08">Soit [holo_prix k="coaching_pp4"] par personne à quatre.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 24px">Réserver un coaching vidéo</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
