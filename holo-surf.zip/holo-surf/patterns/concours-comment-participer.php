<?php
/**
 * Title: Concours 2026 : Comment participer
 * Slug: holo-surf/concours-comment-participer
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-ffae2f"} -->
<section class="wp-block-group u-ffae2f">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:heading {"className":"h2 reveal"} -->
<h2 class="wp-block-heading h2 reveal">Comment participer</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"reveal u-769d9b"} -->
<div class="wp-block-group reveal u-769d9b">
<!-- wp:group {"className":"u-b6b9bc"} -->
<div class="wp-block-group u-b6b9bc">
<!-- wp:heading {"level":3,"className":"h3 u-c49588"} -->
<h3 class="wp-block-heading h3 u-c49588">La planche : pour les élèves</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-0dc91c"} -->
<p class="p u-0dc91c">Tout élève inscrit à au moins un cours ou stage payant entre le 1er avril et le 30 septembre participe automatiquement. Aucune démarche, le fichier élèves de l'école fait foi.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-navy" href="<?php echo esc_url( hs_url( 'Contact' ) ); ?>" style="margin-top: 26px">Réserver un cours</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"u-588d45"} -->
<div class="wp-block-group u-588d45">
<!-- wp:heading {"level":3,"className":"h3 u-c49588"} -->
<h3 class="wp-block-heading h3 u-c49588">Les cours : sur Instagram</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"u-5e5061"} -->
<ol class="wp-block-list u-5e5061"><!-- wp:list-item -->
<li>Suis @holosurfcapbreton et @ocean.storm.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Like la publication du concours.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Identifie au moins deux amis en commentaire.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Partage la publication en story en identifiant les deux comptes.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:paragraph {"className":"hs-c"} -->
<p class="hs-c"><a class="btn b-sand" href="https://www.instagram.com/holosurfcapbreton/" style="margin-top: 26px">Je joue sur Insta</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
