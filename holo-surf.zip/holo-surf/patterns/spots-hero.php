<?php
/**
 * Title: Les spots : Hero
 * Slug: holo-surf/spots-hero
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-0bd8e1"} -->
<section class="wp-block-group u-0bd8e1">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kb ui-4a3c4f"} -->
<figure class="wp-block-image size-full kb ui-4a3c4f"><img src="<?php echo esc_url( hs_img( 'c6e90b27fe474c9ebd785e4276dfdeba' ) ); ?>" alt="Paul dans le tube d'une vague aux Culs Nus, Hossegor"/></figure>
<!-- /wp:image -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(180deg, rgba(25,42,51,0.2) 20%, rgba(25,42,51,0.86) 100%)"></div>
<!-- /wp:html -->

<!-- wp:group {"className":"wrap u-8acf14"} -->
<div class="wp-block-group wrap u-8acf14">
<!-- wp:html -->
<nav aria-label="Fil d'Ariane" class="in crumb" style="margin-bottom: 22px; font-size: 14.5px; color: #C9D4D9"><a href="<?php echo esc_url( hs_url( 'Main' ) ); ?>" style="color: #C9D4D9">Accueil</a> / <span aria-current="page" style="color: #FFFFFF">Les spots</span></nav>
<!-- /wp:html -->

<!-- wp:heading {"level":1,"className":"in u-572a49"} -->
<h1 class="wp-block-heading in u-572a49">Spots de surf à Capbreton<span style="display: block; color: #D4AA63">Hossegor et Seignosse</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"in d1 u-15a0f9"} -->
<p class="in d1 u-15a0f9">De longues plages de sable, des bancs qui bougent et des vagues puissantes : dans le sud des Landes, il y a un spot pour chaque niveau.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"in d2 anch u-e90f6f"} -->
<p class="in d2 anch u-e90f6f"><a class="lnk" href="#capbreton" style="font-weight: 400; color: #FFFFFF">Capbreton</a><a class="lnk" href="#hossegor" style="font-weight: 400; color: #FFFFFF">Hossegor</a><a class="lnk" href="#seignosse" style="font-weight: 400; color: #FFFFFF">Seignosse</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" style="position: absolute; left: 0; right: 0; bottom: -1px; height: 40px; overflow: hidden">
<svg class="wave" preserveAspectRatio="none" style="position: absolute; left: 0; bottom: 0; width: 200%; height: 40px" viewBox="0 0 2880 64"><path d="M0 32 C120 12 240 12 360 32 S600 52 720 32 S960 12 1080 32 S1320 52 1440 32 S1680 12 1800 32 S2040 52 2160 32 S2400 12 2520 32 S2760 52 2880 32 V64 H0 Z" fill="#FFFFFF"></path></svg>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
