<?php
/**
 * Title: Les spots : hossegor
 * Slug: holo-surf/spots-hossegor
 * Categories: holo-surf-pages
 * Viewport Width: 1440
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"u-c55f2c"} -->
<section id="hossegor" class="wp-block-group u-c55f2c">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"reveal u-b7f6ed"} -->
<div class="wp-block-group reveal u-b7f6ed">
<!-- wp:heading {"className":"h2"} -->
<h2 class="wp-block-heading h2">Les spots de surf d'Hossegor</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"p u-c83bd2"} -->
<p class="p u-c83bd2">La capitale européenne du surf et ses beach breaks de classe mondiale.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"zoom reveal townimg u-730f19"} -->
<div class="wp-block-group zoom reveal townimg u-730f19">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"ui-00ce87"} -->
<figure class="wp-block-image size-full ui-00ce87"><img src="<?php echo esc_url( hs_img( 'a67cb1a03e4015e525f7e0eb9f452cc5' ) ); ?>" alt="Une vague d'hiver à Hossegor avec les Pyrénées au loin"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="sp">
<li><div class="nm"><h3>La Sud</h3><span class="lv">Débutant à intermédiaire</span></div><p>Au centre d'Hossegor et abritée des grosses houles, c'est l'un des meilleurs endroits pour débuter et progresser. Très fréquentée : on respecte les écoles et les autres surfeurs.</p></li>
<li><div class="nm"><h3>La Gravière</h3><span class="lv">Expert</span></div><p>Un tube puissant de renommée mondiale, qui a accueilli le Quik Pro France en 2012 et vu Jérémy Flores gagner en 2019. Pour les débutants, ça se regarde depuis la plage.</p></li>
<li><div class="nm"><h3>La Nord</h3><span class="lv">Expert</span></div><p>Le spot de grosses vagues d'Hossegor, jusqu'à 7 mètres environ, réservé aux surfeurs expérimentés.</p></li>
<li><div class="nm"><h3>Les Culs Nus</h3><span class="lv">Confirmé</span></div><p>Juste au nord de La Gravière, un beach break puissant et creux, avec de forts courants et des baïnes toute l'année. Au mieux autour de la mi-marée, avec une houle bien orientée.</p></li>
</ul>
<!-- /wp:html -->

<!-- wp:group {"className":"reveal u-c628b3"} -->
<div class="wp-block-group reveal u-c628b3">
<!-- wp:group {"className":"seo fold oncream"} -->
<div id="seo-sh" class="wp-block-group seo fold oncream">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Surfer à Hossegor : ce qu'il faut savoir</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Hossegor doit sa réputation mondiale à ses beach breaks puissants et réguliers. Pour un débutant, c'est surtout un spectacle à regarder depuis la plage, à l'exception de La Sud. Pour un surfeur confirmé, c'est l'un des terrains de jeu les plus exigeants d'Europe.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Pourquoi les vagues d'Hossegor sont si puissantes</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La proximité du Gouf de Capbreton laisse arriver la houle presque sans perte d'énergie, et les bancs de sable d'Hossegor la font déferler sur très peu d'eau. Le résultat : des vagues creuses, rapides, souvent à tube. La Gravière accueille depuis des années les compétitions internationales, dont le Quik Pro France en 2012, et Jérémy Flores y a remporté une victoire en 2019.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">La Sud, le spot pour apprendre à Hossegor</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Au centre de la ville et abritée des grosses houles, La Sud est l'un des meilleurs endroits du secteur pour débuter et progresser. Les jours où les autres plages sont trop grosses, elle reste souvent surfable. Revers de la médaille, elle est très fréquentée : on y respecte les écoles, les priorités et les autres surfeurs. En cours, Paul peut y emmener un groupe quand les conditions y sont meilleures qu'au Santocha.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Les spots pour surfeurs confirmés</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>La Gravière, La Nord et Les Culs Nus ne sont pas des spots pour apprendre. Les vagues y cassent fort, sur des fonds qui changent vite, avec des courants puissants et des baïnes toute l'année. La Nord peut tenir des vagues de plusieurs mètres. Si vous n'êtes pas sûr de votre niveau, la réponse est simple : regardez depuis la plage, c'est déjà un très beau spectacle.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Regarder La Gravière depuis la plage</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Même sans surfer, une session à La Gravière vaut le détour. Montez sur la dune ou installez-vous sur le sable, de préférence un matin d'automne, avec un vent de terre et une houle moyenne : les tubes s'enchaînent et les meilleurs surfeurs du secteur sont à l'eau. Observer comment ils se placent, où ils rament et quelles vagues ils laissent passer est une excellente leçon de lecture de la mer. Restez en dehors de l'eau et loin du bord : le shorebreak y est violent.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">La meilleure saison à Hossegor</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>L'automne est la période reine : les dépressions de l'Atlantique Nord envoient des houles régulières, l'eau reste douce après l'été et le vent de terre est fréquent le matin. L'hiver apporte les plus grosses vagues, réservées aux experts. L'été est plus calme, souvent trop petit pour La Gravière, mais agréable à La Sud.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Progresser à Hossegor</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Quand vous tenez debout et prenez des vagues vertes, surfer à Hossegor devient une étape motivante. Le <a href="<?php echo esc_url( hs_url( 'Tarifs' ) ); ?>#coaching">coaching vidéo</a> y prend tout son sens : se voir sur une vague plus rapide permet de corriger en quelques séances ce qui prendrait des mois seul.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
