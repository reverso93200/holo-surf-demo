<?php
/**
 * Données structurées (JSON-LD) par type de page, avec les prix des réglages.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

function holo_surf_base() {
	return untrailingslashit( home_url() );
}

/**
 * Clé de maquette de la page affichée.
 */
function holo_surf_cle() {
	if ( function_exists( 'hs_current_key' ) ) {
		return hs_current_key();
	}
	if ( is_front_page() ) {
		return 'Main';
	}
	if ( is_home() ) {
		return 'Blog';
	}
	if ( is_singular( 'post' ) ) {
		return 'Article';
	}
	$ids = get_option( 'holo_surf_pages', array() );
	$k   = is_page() ? array_search( get_queried_object_id(), (array) $ids, true ) : false;
	return $k ? $k : '';
}

function holo_surf_page_url( $key ) {
	if ( function_exists( 'hs_url' ) ) {
		return hs_url( $key );
	}
	$ids = get_option( 'holo_surf_pages', array() );
	return ! empty( $ids[ $key ] ) ? get_permalink( $ids[ $key ] ) : home_url( '/' );
}

function holo_surf_city( $n ) {
	$w = array(
		'Capbreton' => 'https://fr.wikipedia.org/wiki/Capbreton',
		'Hossegor'  => 'https://fr.wikipedia.org/wiki/Soorts-Hossegor',
		'Seignosse' => 'https://fr.wikipedia.org/wiki/Seignosse',
	);
	return array( '@type' => 'City', 'name' => $n, 'sameAs' => $w[ $n ] );
}

function holo_surf_area() {
	return array( holo_surf_city( 'Capbreton' ), holo_surf_city( 'Hossegor' ), holo_surf_city( 'Seignosse' ) );
}

function holo_surf_address() {
	return array(
		'@type'           => 'PostalAddress',
		'streetAddress'   => holo_surf_reglage( 'rue' ),
		'postalCode'      => holo_surf_reglage( 'code_postal' ),
		'addressLocality' => holo_surf_reglage( 'ville' ),
		'addressRegion'   => 'Landes',
		'addressCountry'  => 'FR',
	);
}

function holo_surf_santocha() {
	return array(
		'@type'           => 'Beach',
		'name'            => 'Plage du Santocha',
		'address'         => array( '@type' => 'PostalAddress', 'addressLocality' => 'Capbreton', 'postalCode' => '40130', 'addressCountry' => 'FR' ),
		'containedInPlace' => holo_surf_city( 'Capbreton' ),
	);
}

function holo_surf_paul() {
	$b = holo_surf_base();
	return array(
		'@type'         => 'Person',
		'@id'           => $b . '/#paul',
		'name'          => 'Paul Roquier',
		'jobTitle'      => 'Moniteur de surf',
		'description'   => 'Moniteur de surf diplômé du BPJEPS Surf et sports associés, surfeur depuis plus de 15 ans, fondateur de Holo Surf Capbreton.',
		'worksFor'      => array( '@id' => $b . '/#ecole' ),
		'url'           => holo_surf_page_url( 'APropos' ),
		'knowsLanguage' => array( 'fr', 'en', 'es' ),
		'hasOccupation' => array( '@type' => 'Occupation', 'name' => 'Moniteur de surf', 'occupationLocation' => holo_surf_city( 'Capbreton' ) ),
		'hasCredential' => array(
			'@type'              => 'EducationalOccupationalCredential',
			'name'               => 'BPJEPS Surf et sports associés',
			'credentialCategory' => "Diplôme d'État",
			'recognizedBy'       => array( '@type' => 'GovernmentOrganization', 'name' => 'Ministère chargé des Sports' ),
		),
		'knowsAbout'    => array( 'Surf', 'Coaching vidéo de surf', 'Spots de surf des Landes', 'Marées et houle', 'Sécurité et baïnes' ),
	);
}

function holo_surf_same_as() {
	return array_values( array_filter( array( holo_surf_reglage( 'instagram' ), holo_surf_reglage( 'facebook' ) ) ) );
}

function holo_surf_org_min() {
	$b = holo_surf_base();
	return array(
		'@type'     => array( 'LocalBusiness', 'SportsActivityLocation' ),
		'@id'       => $b . '/#ecole',
		'name'      => 'Holo Surf Capbreton',
		'url'       => $b . '/',
		'telephone' => holo_surf_reglage( 'telephone_intl' ),
		'email'     => holo_surf_reglage( 'email' ),
		'address'   => holo_surf_address(),
	);
}

/**
 * Fourchette de prix des cours (du cours collectif dégressif au cours particulier à 4).
 */
function holo_surf_price_range() {
	$keys = array( 'collectif_bs_6', 'collectif_hs_6', 'collectif_bs_1', 'collectif_hs_1', 'particulier_1', 'particulier_4', 'coaching_1', 'coaching_4' );
	$v    = array_map(
		function ( $k ) {
			return holo_surf_nombre( holo_surf_reglage( $k ) );
		},
		$keys
	);
	return holo_surf_prix_format( min( $v ) ) . ' - ' . holo_surf_prix_format( max( $v ) );
}

function holo_surf_org_full() {
	$b    = holo_surf_base();
	$t    = holo_surf_page_url( 'Tarifs' );
	$biz  = holo_surf_org_min();
	$biz += array(
		'description'        => 'École de surf itinérante à Capbreton : cours collectifs, cours particuliers et coaching vidéo dès 5 ans.',
		'areaServed'         => holo_surf_area(),
		'priceRange'         => str_replace( "\xc2\xa0", ' ', holo_surf_price_range() ),
		'knowsLanguage'      => array( 'fr', 'en', 'es' ),
		'sameAs'             => holo_surf_same_as(),
		'currenciesAccepted' => 'EUR',
		'logo'               => function_exists( 'hs_asset' ) ? hs_asset( 'img/logo-holo-surf-capbreton.webp' ) : '',
		'image'              => holo_surf_og_image(),
		'hasMap'             => 'https://www.google.com/maps/search/?api=1&query=Holo+Surf+Capbreton',
		'founder'            => array( '@id' => $b . '/#paul' ),
		'award'              => 'Label Ecosafe Surfing',
		'knowsAbout'         => array( 'Cours de surf', 'Surf pour enfants', 'Coaching vidéo de surf', 'Location de planches de surf', 'Spots de surf de Capbreton, Hossegor et Seignosse', 'Baïnes et sécurité à la plage' ),
		'contactPoint'       => array(
			'@type'             => 'ContactPoint',
			'contactType'       => 'Réservation',
			'telephone'         => holo_surf_reglage( 'telephone_intl' ),
			'email'             => holo_surf_reglage( 'email' ),
			'availableLanguage' => array( 'French', 'English', 'Spanish' ),
		),
		'makesOffer'         => array(
			array( '@type' => 'Offer', 'name' => 'Cours de surf collectif 1h30', 'price' => holo_surf_prix_schema( 'collectif_bs_1' ), 'priceCurrency' => 'EUR', 'itemOffered' => array( '@id' => $t . '#collectif' ) ),
			array( '@type' => 'Offer', 'name' => 'Cours de surf particulier 1h30', 'price' => holo_surf_prix_schema( 'particulier_1' ), 'priceCurrency' => 'EUR', 'itemOffered' => array( '@id' => $t . '#particulier' ) ),
			array( '@type' => 'Offer', 'name' => 'Coaching vidéo surf 1h30', 'price' => holo_surf_prix_schema( 'coaching_1' ), 'priceCurrency' => 'EUR', 'itemOffered' => array( '@id' => $t . '#coaching' ) ),
		),
	);
	return $biz;
}

function holo_surf_og_image() {
	$id = (int) get_option( 'holo_surf_og_image' );
	return $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
}

/**
 * Questions fréquentes : blocs « details » du contenu.
 */
function holo_surf_faq( $content ) {
	if ( ! preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/s', $content, $m, PREG_SET_ORDER ) ) {
		return null;
	}
	$q = array();
	foreach ( $m as $d ) {
		$name = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $d[1] ) ) );
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $d[2] ) ) );
		if ( '' === $name || '' === $text || 'Sommaire' === $name ) {
			continue;
		}
		$q[] = array( '@type' => 'Question', 'name' => $name, 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $text ) );
	}
	return $q ? array( '@type' => 'FAQPage', 'mainEntity' => $q ) : null;
}

/**
 * Graphe complet de la page.
 */
function holo_surf_graph() {
	$b     = holo_surf_base();
	$key   = holo_surf_cle();
	$graph = array();
	if ( is_404() || is_search() ) {
		return array();
	}
	$obj   = get_queried_object();
	$url   = is_front_page() ? $b . '/' : ( is_home() ? holo_surf_page_url( 'Blog' ) : ( is_singular() ? get_permalink( $obj ) : ( is_category() ? get_category_link( $obj ) : '' ) ) );
	$title = wp_get_document_title();
	$desc  = holo_surf_description();
	$paul  = holo_surf_paul();

	if ( 'Main' === $key ) {
		$graph[] = holo_surf_org_full();
		$graph[] = $paul;
		$graph[] = array( '@type' => 'WebSite', '@id' => $b . '/#site', 'url' => $b . '/', 'name' => 'Holo Surf Capbreton', 'inLanguage' => 'fr-FR', 'publisher' => array( '@id' => $b . '/#ecole' ) );
	} else {
		$graph[] = holo_surf_org_min();
	}
	if ( ! $url ) {
		return array( '@context' => 'https://schema.org', '@graph' => $graph );
	}
	$types = array( 'APropos' => 'AboutPage', 'Contact' => 'ContactPage', 'Blog' => 'CollectionPage' );
	$wp    = array(
		'@type'      => isset( $types[ $key ] ) ? $types[ $key ] : ( is_category() ? 'CollectionPage' : 'WebPage' ),
		'@id'        => $url . '#page',
		'url'        => $url,
		'name'       => $title,
		'isPartOf'   => array( '@id' => $b . '/#site' ),
		'inLanguage' => 'fr-FR',
	);
	if ( $desc ) {
		$wp['description'] = $desc;
	}
	$wp['about'] = 'APropos' === $key ? array( '@id' => $b . '/#paul' ) : array( '@id' => $b . '/#ecole' );
	if ( 'APropos' === $key ) {
		$wp['mainEntity'] = array( '@id' => $b . '/#paul' );
	}
	if ( 'Contact' === $key ) {
		$wp['mainEntity'] = array( '@id' => $b . '/#ecole' );
	}

	// Fil d'Ariane
	if ( ! is_front_page() ) {
		$items = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Accueil', 'item' => $b . '/' ) );
		if ( is_singular( 'post' ) || is_category() ) {
			$items[] = array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Blog', 'item' => holo_surf_page_url( 'Blog' ) );
		}
		$crumb = is_singular() ? get_post_meta( $obj->ID, '_holo_fil_ariane', true ) : '';
		if ( ! $crumb ) {
			$crumb = is_home() ? 'Blog' : ( is_category() ? single_cat_title( '', false ) : get_the_title( $obj ) );
		}
		$items[]          = array( '@type' => 'ListItem', 'position' => count( $items ) + 1, 'name' => $crumb, 'item' => $url );
		$wp['breadcrumb'] = array( '@id' => $url . '#crumb' );
		$graph[]          = $wp;
		$graph[]          = array( '@type' => 'BreadcrumbList', '@id' => $url . '#crumb', 'itemListElement' => $items );
	} else {
		$graph[] = $wp;
	}

	if ( 'Tarifs' === $key ) {
		$graph[] = array(
			'@type'       => 'Service',
			'name'        => 'Cours de surf à Capbreton',
			'serviceType' => 'Cours de surf',
			'provider'    => array( '@id' => $b . '/#ecole' ),
			'areaServed'  => holo_surf_area(),
			'offers'      => array(
				array( '@type' => 'Offer', 'name' => 'Cours collectif, 1 séance', 'price' => holo_surf_prix_schema( 'collectif_bs_1' ), 'priceCurrency' => 'EUR' ),
				array( '@type' => 'Offer', 'name' => 'Cours collectif, à partir de 6 séances (par séance)', 'price' => holo_surf_prix_schema( 'collectif_bs_6' ), 'priceCurrency' => 'EUR' ),
				array( '@type' => 'Offer', 'name' => 'Cours collectif en juillet et août, 1 séance', 'price' => holo_surf_prix_schema( 'collectif_hs_1' ), 'priceCurrency' => 'EUR' ),
				array( '@type' => 'Offer', 'name' => 'Cours particulier, 1 personne', 'price' => holo_surf_prix_schema( 'particulier_1' ), 'priceCurrency' => 'EUR' ),
				array( '@type' => 'Offer', 'name' => 'Coaching vidéo, 1 personne', 'price' => holo_surf_prix_schema( 'coaching_1' ), 'priceCurrency' => 'EUR' ),
			),
		);
		$courses = array(
			array( 'collectif', 'Cours de surf collectif à Capbreton', 'Cours de 1h30 en petit groupe encadré par Paul, matériel et assurance compris, du premier cours au passage de la barre.', 'collectif_bs_1', 'Débutant à intermédiaire', 5 ),
			array( 'particulier', 'Cours de surf particulier à Capbreton', 'Cours de 1h30 en solo ou en famille, rythme et objectifs adaptés, matériel et assurance compris.', 'particulier_1', 'Tous niveaux', 5 ),
			array( 'coaching', 'Coaching vidéo surf à Capbreton', 'Séance de 1h30 filmée puis analysée image par image pour corriger sa technique et progresser plus vite.', 'coaching_1', 'Intermédiaire et confirmé', 0 ),
		);
		foreach ( $courses as $c ) {
			$course = array(
				'@type'             => 'Course',
				'@id'               => $url . '#' . $c[0],
				'name'              => $c[1],
				'description'       => $c[2],
				'provider'          => array( '@id' => $b . '/#ecole' ),
				'inLanguage'        => 'fr-FR',
				'educationalLevel'  => $c[4],
				'offers'            => array( array( '@type' => 'Offer', 'category' => 'Paid', 'price' => holo_surf_prix_schema( $c[3] ), 'priceCurrency' => 'EUR', 'url' => $url ) ),
				'hasCourseInstance' => array( array( '@type' => 'CourseInstance', 'courseMode' => 'Onsite', 'courseWorkload' => 'PT1H30M', 'instructor' => array( '@id' => $b . '/#paul' ), 'location' => holo_surf_santocha() ) ),
			);
			if ( $c[5] ) {
				$course['audience'] = array( '@type' => 'PeopleAudience', 'suggestedMinAge' => $c[5] );
			}
			$graph[] = $course;
		}
	}
	if ( 'Location' === $key ) {
		$offers = array();
		$noms   = array( 'mousse' => 'Planche en mousse', 'hybride' => 'Planche hybride', 'combinaison' => 'Combinaison' );
		foreach ( $noms as $k => $n ) {
			$offers[] = array( '@type' => 'Offer', 'name' => $n . ', 1 heure', 'price' => holo_surf_prix_schema( $k . '_1h' ), 'priceCurrency' => 'EUR' );
			$offers[] = array( '@type' => 'Offer', 'name' => $n . ', journée', 'price' => holo_surf_prix_schema( $k . '_jour' ), 'priceCurrency' => 'EUR' );
		}
		$graph[] = array(
			'@type'           => 'Service',
			'name'            => 'Location de planches de surf et de combinaisons à Capbreton',
			'serviceType'     => 'Location de matériel de surf',
			'provider'        => array( '@id' => $b . '/#ecole' ),
			'areaServed'      => holo_surf_area(),
			'hasOfferCatalog' => array( '@type' => 'OfferCatalog', 'name' => 'Tarifs de location', 'itemListElement' => $offers ),
		);
	}
	if ( 'Spots' === $key ) {
		$beaches = array(
			'Capbreton' => array( array( 'La Centrale', 'Plage Centrale de Capbreton' ), array( 'Le Prévent', 'Plage du Prévent' ), array( 'Le Santocha', 'Plage du Santocha' ), array( 'La Piste', 'Plage de la Piste' ), array( 'Les Océanides', 'Plage des Océanides' ) ),
			'Hossegor'  => array( array( 'La Sud', "Plage Sud d'Hossegor" ), array( 'La Gravière', 'Plage de la Gravière' ), array( 'La Nord', "Plage Nord d'Hossegor" ), array( 'Les Culs Nus', 'Plage des Culs Nus' ) ),
			'Seignosse' => array( array( 'Les Estagnots', 'Plage des Estagnots' ), array( 'Les Bourdaines', 'Plage des Bourdaines' ), array( 'Le Penon', 'Plage du Penon' ) ),
		);
		$els = array();
		$pos = 0;
		foreach ( $beaches as $town => $list ) {
			foreach ( $list as $bch ) {
				$els[] = array( '@type' => 'ListItem', 'position' => ++$pos, 'item' => array( '@type' => 'Beach', 'name' => $bch[1], 'alternateName' => $bch[0], 'url' => $url . '#' . strtolower( $town ), 'containedInPlace' => holo_surf_city( $town ) ) );
			}
		}
		$graph[] = array( '@type' => 'ItemList', 'name' => 'Spots de surf de Capbreton, Hossegor et Seignosse', 'numberOfItems' => $pos, 'itemListElement' => $els );
	}
	if ( 'InfosSurf' === $key ) {
		$graph[] = holo_surf_santocha() + array( 'description' => 'Plage de Capbreton où ont lieu la plupart des cours de Holo Surf, filmée en direct par la webcam.' );
	}
	if ( 'APropos' === $key || is_singular( 'post' ) ) {
		$graph[] = $paul;
	}
	if ( is_singular( 'post' ) ) {
		$post  = $obj;
		$words = count( preg_split( '/\s+/u', trim( wp_strip_all_tags( do_shortcode( $post->post_content ) ) ), -1, PREG_SPLIT_NO_EMPTY ) );
		$cat   = get_the_category( $post->ID );
		$kw    = get_post_meta( $post->ID, 'rank_math_focus_keyword', true );
		$bp    = array(
			'@type'            => 'BlogPosting',
			'@id'              => $url . '#article',
			'headline'         => get_the_title( $post ),
			'description'      => $desc,
			'datePublished'    => get_post_time( 'c', true, $post ),
			'dateModified'     => get_post_modified_time( 'c', true, $post ),
			'author'           => array( '@id' => $b . '/#paul' ),
			'publisher'        => array( '@id' => $b . '/#ecole' ),
			'mainEntityOfPage' => array( '@id' => $url . '#page' ),
			'isPartOf'         => array( '@id' => holo_surf_page_url( 'Blog' ) . '#blog' ),
			'inLanguage'       => 'fr-FR',
			'wordCount'        => $words,
		);
		if ( has_post_thumbnail( $post ) ) {
			$bp['image'] = get_the_post_thumbnail_url( $post, 'full' );
		}
		if ( $cat ) {
			$bp['articleSection'] = $cat[0]->name;
		}
		if ( $kw ) {
			$bp['keywords'] = strtok( $kw, ',' );
		}
		$extra = json_decode( (string) get_post_meta( $post->ID, '_holo_schema_extra', true ), true );
		if ( is_array( $extra ) ) {
			$bp = array_merge( $bp, $extra );
		}
		$graph[] = $bp;
	}
	if ( 'Blog' === $key && is_home() ) {
		$graph[] = array( '@type' => 'Blog', '@id' => $url . '#blog', 'name' => 'Le blog surf de Capbreton', 'url' => $url, 'publisher' => array( '@id' => $b . '/#ecole' ), 'author' => array( '@id' => $b . '/#paul' ), 'inLanguage' => 'fr-FR' );
	}
	if ( is_singular() && ! in_array( $key, array( 'Concours', 'Legal' ), true ) ) {
		$faq = holo_surf_faq( apply_filters( 'the_content', $obj->post_content ) );
		if ( $faq ) {
			$graph[] = $faq;
		}
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

function holo_surf_print_schema() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	$g    = holo_surf_graph();
	if ( empty( $g['@graph'] ) ) {
		return;
	}
	echo '<script type="application/ld+json">' . wp_json_encode( $g, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}
add_action( 'wp_head', 'holo_surf_print_schema', 30 );
