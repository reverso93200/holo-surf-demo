<?php
/**
 * Prévisions Windguru et marées du SHOM chargées au clic, avis clients, hébergeur.
 *
 * Conditions des fournisseurs (vérifiées en novembre 2026) :
 * - Windguru : les widgets sont le moyen officiel d'afficher ses prévisions sur un autre site (conditions, article 3.4).
 * - SHOM : « Insérer gratuitement une vignette des horaires des marées du Shom dans votre site Internet ».
 * - maree.info : l'intégration en iframe est interdite, seuls les liens sont autorisés (lien de secours).
 * - Webcam du Santocha : lecteur Viewsurf (pv.viewsurf.com), celui que le Santocha Surf Club intègre lui-même sur
 *   santocha.org. Le lecteur n'interdit pas l'intégration (ni X-Frame-Options ni frame-ancestors). Décision d'intégration
 *   prise par le client en novembre 2026 ; le site d'origine est crédité juste sous la caméra.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Script de chargement à la demande.
 */
function holo_surf_scripts_integrations() {
	wp_register_script( 'holo-surf-embeds', plugins_url( 'assets/embeds.js', HOLO_SURF_CORE_DIR . 'holo-surf-core.php' ), array(), HOLO_SURF_CORE_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
}
add_action( 'wp_enqueue_scripts', 'holo_surf_scripts_integrations' );

/**
 * Encadré qui remplace le contenu tiers tant que le visiteur ne l'a pas demandé.
 */
function holo_surf_embed_box( $type, $data, $titre, $texte, $bouton, $lien, $lien_label, $style = '' ) {
	wp_enqueue_script( 'holo-surf-embeds' );
	$attrs = '';
	foreach ( $data as $k => $v ) {
		$attrs .= ' data-' . $k . '="' . esc_attr( $v ) . '"';
	}
	return '<div class="hs-embed" data-embed="' . esc_attr( $type ) . '"' . $attrs . ' style="' . esc_attr( $style ) . '">'
		. '<div class="hs-embed-ph">'
		. '<span class="hs-embed-t">' . esc_html( $titre ) . '</span>'
		. '<span class="hs-embed-d">' . esc_html( $texte ) . '</span>'
		. '<button type="button" class="btn b-navy hs-embed-btn">' . esc_html( $bouton ) . '</button>'
		. '<a class="hs-embed-l" href="' . esc_url( $lien ) . '" target="_blank" rel="noopener">' . esc_html( $lien_label ) . '</a>'
		. '</div></div>';
}

/**
 * [holo_windguru] : tableau de prévisions du spot de Capbreton.
 */
function holo_surf_sc_windguru( $a ) {
	$a    = shortcode_atts( array( 'style' => '' ), $a );
	$spot = holo_surf_reglage( 'windguru_spot' );
	return holo_surf_embed_box(
		'windguru',
		array(
			'spot'   => $spot,
			'modele' => holo_surf_reglage( 'windguru_modele' ),
			'vagues' => holo_surf_reglage( 'windguru_vagues' ),
		),
		'Prévisions Windguru, Capbreton',
		'Vent, vagues et période sur dix jours. Le tableau vient du site Windguru et ne se charge qu\'à votre demande : Windguru peut alors déposer ses propres cookies.',
		'Afficher les prévisions',
		'https://www.windguru.cz/' . rawurlencode( $spot ),
		'Ouvrir Windguru dans un nouvel onglet',
		$a['style']
	);
}
add_shortcode( 'holo_windguru', 'holo_surf_sc_windguru' );

/**
 * [holo_marees] : vignette officielle du SHOM pour le port de Capbreton.
 */
function holo_surf_sc_marees( $a ) {
	$a    = shortcode_atts( array( 'style' => '' ), $a );
	$port = holo_surf_reglage( 'shom_port' );
	return holo_surf_embed_box(
		'shom',
		array( 'port' => $port ),
		'Horaires et coefficients du jour',
		'Les marées du port de Capbreton d\'après le SHOM, sur sept jours. La vignette du SHOM ne se charge qu\'à votre demande.',
		'Afficher les marées',
		'https://maree.info/' . rawurlencode( holo_surf_reglage( 'maree_info_port' ) ),
		'Voir les horaires sur maree.info',
		$a['style']
	);
}
add_shortcode( 'holo_marees', 'holo_surf_sc_marees' );

/**
 * [holo_webcam] : webcam en direct (lecteur officiel du fournisseur), chargée au clic, avec le crédit du site d'origine.
 */
function holo_surf_sc_webcam( $a ) {
	$a      = shortcode_atts( array( 'image' => '' ), $a );
	$url    = holo_surf_reglage( 'webcam_url' );
	$titre  = holo_surf_reglage( 'webcam_titre' );
	$source = holo_surf_reglage( 'webcam_source' );
	$page   = holo_surf_reglage( 'webcam_page' );
	if ( ! $url ) {
		return '';
	}
	wp_enqueue_script( 'holo-surf-embeds' );
	$fond = $a['image'] ? '<img class="hs-cam-fond" src="' . esc_url( $a['image'] ) . '" alt="" width="1024" height="683" loading="lazy" decoding="async">' : '';
	$out  = '<div class="hs-embed hs-cam" data-embed="webcam" data-src="' . esc_attr( $url ) . '" data-titre="' . esc_attr( $titre ) . '">'
		. $fond
		. '<div class="hs-embed-ph hs-cam-ph">'
		. '<button type="button" class="hs-embed-btn hs-cam-btn" aria-label="' . esc_attr( 'Afficher en direct : ' . $titre ) . '"><svg aria-hidden="true" width="30" height="30" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button>'
		. '<span class="hs-cam-t">Voir le direct</span>'
		. '<span class="hs-cam-d">' . esc_html( $titre ) . '. Le direct se charge à votre demande' . ( $source ? ', depuis le lecteur utilisé par le ' . esc_html( $source ) : '' ) . '.</span>'
		. '</div></div>';
	$ct = trim( (string) holo_surf_reglage( 'webcam_credit_titre' ) );
	$cx = trim( (string) holo_surf_reglage( 'webcam_credit_texte' ) );
	if ( $source && $page ) {
		$out .= '<div class="hs-cam-credit">'
			. ( $ct ? '<h3 class="hs-cam-credit-t">' . esc_html( $ct ) . '</h3>' : '' )
			. ( $cx ? '<p>' . esc_html( $cx ) . '</p>' : '' )
			. '<p><a href="' . esc_url( $page ) . '" target="_blank" rel="nofollow noopener">Voir la webcam sur le site du ' . esc_html( $source ) . '</a></p>'
			. '</div>';
	}
	return $out;
}
add_shortcode( 'holo_webcam', 'holo_surf_sc_webcam' );

/**
 * Avis saisis dans les réglages (copiés mot pour mot depuis la fiche Google).
 */
function holo_surf_avis_liste() {
	$out = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		$t = trim( (string) holo_surf_reglage( 'avis_' . $i . '_texte' ) );
		if ( '' === $t ) {
			continue;
		}
		$out[] = array(
			'prenom' => trim( (string) holo_surf_reglage( 'avis_' . $i . '_prenom' ) ),
			'note'   => (int) holo_surf_reglage( 'avis_' . $i . '_note' ),
			'date'   => trim( (string) holo_surf_reglage( 'avis_' . $i . '_date' ) ),
			'texte'  => $t,
		);
	}
	return $out;
}

function holo_surf_etoiles( $n, $taille = 18 ) {
	if ( $n < 1 ) {
		return '';
	}
	$s = '<span class="hs-stars" role="img" aria-label="' . esc_attr( $n . ' sur 5' ) . '">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$s .= '<svg aria-hidden="true" width="' . $taille . '" height="' . $taille . '" viewBox="0 0 24 24"><path fill="' . ( $i <= $n ? '#D4AA63' : '#4A6373' ) . '" d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z"/></svg>';
	}
	return $s . '</span>';
}

function holo_surf_meta_avis( $av ) {
	$m = array();
	if ( $av['date'] ) {
		$m[] = esc_html( $av['date'] );
	}
	return $m ? '<span class="hs-avis-date">' . implode( ' ', $m ) . '</span>' : '';
}

/**
 * [holo_avis] : bloc avis de l'accueil. [holo_avis variante="simple"] : l'avis principal seul (page des cours).
 */
function holo_surf_sc_avis( $a ) {
	$a     = shortcode_atts( array( 'variante' => 'accueil' ), $a );
	$ext   = holo_surf_avis_extension();
	if ( '' !== $ext ) {
		return holo_surf_avis_avec_extension( $ext, $a['variante'] );
	}
	$avis  = holo_surf_avis_liste();
	$laiss = holo_surf_reglage( 'avis' );
	$fiche = holo_surf_fiche_google();
	$p     = $avis ? array_shift( $avis ) : null;

	$principal = '';
	if ( $p ) {
		$principal  = '<blockquote style="margin: ' . ( 'simple' === $a['variante'] ? '32px' : '36px' ) . ' 0 0; font-size: clamp(23px, 2.3vw, 31px); line-height: 1.45; font-weight: 500; color: #FFFFFF">« ' . esc_html( $p['texte'] ) . ' »</blockquote>' . "\n";
		$principal .= '<p class="hs-avis-auteur" style="margin: 20px 0 0; font-family: \'Bebas Neue\', sans-serif; font-size: 28px; letter-spacing: 0.04em; color: #D4AA63">' . esc_html( $p['prenom'] ) . '</p>' . "\n";
		$etoiles    = holo_surf_etoiles( $p['note'] ) . holo_surf_meta_avis( $p );
		if ( $etoiles ) {
			$principal .= '<p class="hs-avis-meta">' . $etoiles . '</p>' . "\n";
		}
	}
	if ( 'simple' === $a['variante'] ) {
		return '<h2 class="h2" style="color: #D4AA63">L\'avis de nos surfeurs</h2>' . "\n" . $principal;
	}

	$autres = '';
	foreach ( $avis as $av ) {
		$autres .= '<figure class="hs-avis-carte"><blockquote>« ' . esc_html( $av['texte'] ) . ' »</blockquote><figcaption><span class="hs-avis-nom">' . esc_html( $av['prenom'] ) . '</span>' . holo_surf_etoiles( $av['note'], 15 ) . holo_surf_meta_avis( $av ) . '</figcaption></figure>' . "\n";
	}
	$droite = '<div class="hs-avis-box">' . "\n";
	if ( $autres ) {
		$droite .= '<div class="hs-avis-liste">' . $autres . '</div>' . "\n";
	} else {
		$droite .= '<span class="hs-avis-box-t">Avis Google</span>' . "\n" . '<span class="hs-avis-box-d">Vous avez surfé avec Paul ? Votre avis aide d\'autres surfeurs à choisir leur école.</span>' . "\n";
	}
	$droite .= '<a href="' . esc_url( $laiss ) . '" class="btn b-sand" target="_blank" rel="noopener">Laisser un avis sur Google</a>' . "\n";
	$droite .= '</div>' . "\n";
	if ( $fiche ) {
		$droite .= '<a href="' . esc_url( $fiche ) . '" class="lnk" target="_blank" rel="noopener" style="display: inline-block; margin-top: 18px; color: #FFFFFF">Voir tous les avis sur Google</a>' . "\n";
	}

	return '<div class="reveal" style="flex: 2 1 560px; min-width: 0">' . "\n"
		. '<h2 class="h2" style="color: #D4AA63">L\'avis de nos surfeurs</h2>' . "\n" . $principal
		. '</div>' . "\n"
		. '<div class="reveal" style="flex: 1 1 340px; min-width: 0">' . "\n" . $droite . '</div>';
}
add_shortcode( 'holo_avis', 'holo_surf_sc_avis' );

/**
 * Lien « Voir tous les avis » : la fiche saisie, sinon la recherche de l'école dans Google Maps.
 */
function holo_surf_fiche_google() {
	$f = trim( (string) holo_surf_reglage( 'fiche_google' ) );
	return '' !== $f ? $f : 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'Holo Surf Capbreton' );
}

/**
 * Rendu du code court de l'extension d'avis saisi dans les réglages, si l'extension est active.
 */
function holo_surf_avis_extension() {
	$code = trim( (string) holo_surf_reglage( 'avis_extension' ) );
	if ( ! preg_match( '/^\[([a-zA-Z0-9_-]+)[^\]]*\]$/', $code, $m ) || ! shortcode_exists( $m[1] ) || 'holo_avis' === $m[1] ) {
		return '';
	}
	return trim( do_shortcode( $code ) );
}

function holo_surf_avis_avec_extension( $html, $variante ) {
	$laiss = holo_surf_reglage( 'avis' );
	$fiche = holo_surf_fiche_google();
	$out   = '<div class="reveal hs-avis-ext" style="flex: 1 1 100%; min-width: 0">' . "\n"
		. '<h2 class="h2" style="color: #D4AA63">L\'avis de nos surfeurs</h2>' . "\n"
		. '<div class="hs-avis-widget">' . $html . '</div>' . "\n";
	if ( 'simple' !== $variante ) {
		$out .= '<p class="hs-avis-actions"><a href="' . esc_url( $laiss ) . '" class="btn b-sand" target="_blank" rel="noopener">Laisser un avis sur Google</a>';
		if ( $fiche ) {
			$out .= ' <a href="' . esc_url( $fiche ) . '" class="lnk" target="_blank" rel="noopener" style="color: #FFFFFF">Voir tous les avis sur Google</a>';
		}
		$out .= '</p>' . "\n";
	}
	return $out . '</div>';
}

/**
 * [holo_hebergeur] : coordonnées de l'hébergeur saisies dans les réglages.
 */
add_shortcode(
	'holo_hebergeur',
	function () {
		$n = trim( (string) holo_surf_reglage( 'hebergeur_nom' ) );
		if ( '' === $n ) {
			return 'Les coordonnées de l\'hébergeur du site seront indiquées ici à la mise en ligne.';
		}
		$parts = array_filter( array( $n, holo_surf_reglage( 'hebergeur_adresse' ), holo_surf_reglage( 'hebergeur_tel' ) ) );
		return esc_html( implode( ', ', $parts ) ) . '.';
	}
);

/**
 * [holo_conservation] : durée de conservation des demandes, en mois.
 */
add_shortcode(
	'holo_conservation',
	function () {
		return esc_html( max( 1, (int) holo_surf_reglage( 'conservation_mois' ) ) );
	}
);

/**
 * Styles des encadrés (chargés après ceux du thème).
 */
function holo_surf_styles_integrations() {
	$css = '.hs-embed{position:relative;min-height:300px;border:1.5px dashed #C9B88F;background:#FCF9F2;box-sizing:border-box}'
		. '.hs-embed.is-loaded{border:0;background:none;min-height:0}'
		. '.hs-embed-ph{min-height:inherit;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;text-align:center;box-sizing:border-box}'
		. '.hs-embed-t{font-family:"Bebas Neue",sans-serif;font-size:32px;line-height:1;color:#85652A}'
		. '.hs-embed-d{max-width:460px;font-size:15px;line-height:1.55;color:#55636A}'
		. '.hs-embed-btn{margin-top:6px;width:auto!important}'
		. '.hs-embed-l{font-size:14.5px;color:#192A33;text-decoration:underline;text-decoration-color:#D4AA63;text-underline-offset:4px;display:inline-flex;align-items:center;min-height:44px}'
		. '.hs-embed iframe{display:block;width:100%;border:0}'
		. '.hs-embed-src{margin:10px 0 0;font-size:13.5px;color:#55636A}'
		. '.hs-avis-meta{margin:10px 0 0;display:flex;align-items:center;gap:12px;font-size:15px;color:#B8C6CC}'
		. '.hs-stars{display:inline-flex;gap:2px}'
		. '.hs-avis-box{box-sizing:border-box;border:1.5px solid #4A6373;padding:28px;display:flex;flex-direction:column;align-items:flex-start;gap:14px}'
		. '.hs-avis-box-t{font-family:"Bebas Neue",sans-serif;font-size:32px;line-height:1;color:#FFFFFF}'
		. '.hs-avis-box-d{font-size:15px;line-height:1.5;color:#B8C6CC}'
		. '.hs-avis-liste{display:flex;flex-direction:column;gap:18px;width:100%}'
		. '.hs-avis-carte{margin:0;padding:0 0 18px;border-bottom:1px solid #2C4250}'
		. '.hs-avis-carte blockquote{margin:0;font-size:16px;line-height:1.6;color:#FFFFFF}'
		. '.hs-avis-carte figcaption{margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;font-size:14px;color:#B8C6CC}'
		. '.hs-avis-nom{font-family:"Bebas Neue",sans-serif;font-size:21px;letter-spacing:.04em;color:#D4AA63}'
		. '.hs-avis-widget{margin-top:32px;color:#192A33}'
		. '.hs-avis-actions{margin:28px 0 0;display:flex;flex-wrap:wrap;align-items:center;gap:16px 28px}'
		. '.hs-cam{position:relative;aspect-ratio:16/9;max-height:680px;width:100%;min-height:0;border:0;background:#192A33;overflow:hidden}'
		. '.hs-cam.is-loaded{background:#000}'
		. '.hs-cam-fond{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.6}'
		. '.hs-cam .hs-cam-ph{position:absolute;inset:0;min-height:0;color:#FFFFFF;gap:14px}'
		. '.hs-cam-btn{width:84px;height:84px;border-radius:50%;border:0;background:#D4AA63;color:#192A33;display:flex;align-items:center;justify-content:center;cursor:pointer;margin:0}'
		. '.hs-cam .hs-cam-btn{width:84px!important;height:84px;padding:0;flex:none;margin:0}'
		. '.hs-cam-btn:focus-visible{outline:3px solid #FFFFFF;outline-offset:4px}'
		. '.hs-cam-t{font-family:"Bebas Neue",sans-serif;font-size:30px;letter-spacing:.03em;line-height:1}'
		. '.hs-cam-d{max-width:460px;font-size:14.5px;line-height:1.5;color:#C9D4D9}'
		. '.hs-cam iframe{position:absolute;inset:0;width:100%;height:100%;border:0}'
		. '.hs-cam-credit{margin-top:20px;max-width:760px;font-size:15.5px;line-height:1.6;color:#55636A}'
		. '.hs-cam-credit-t{margin:0;font-family:"Bebas Neue",sans-serif;font-weight:400;font-size:24px;letter-spacing:.03em;line-height:1.1;color:#192A33}'
		. '.hs-cam-credit p{margin:6px 0 0}'
		. '.hs-cam-credit a{color:#192A33;text-decoration:underline;text-decoration-color:#D4AA63;text-underline-offset:4px;display:inline-flex;align-items:center;min-height:44px}'
		. '@media (max-width:760px){.hs-avis-box .btn{width:100%}.hs-embed{min-height:260px}.hs-cam{min-height:0}.hs-cam-d{display:none}.hs-cam .hs-cam-btn{width:64px!important;height:64px}}';
	wp_register_style( 'holo-surf-core', false, array(), HOLO_SURF_CORE_VERSION );
	wp_enqueue_style( 'holo-surf-core' );
	wp_add_inline_style( 'holo-surf-core', $css );
}
add_action( 'wp_enqueue_scripts', 'holo_surf_styles_integrations', 30 );
