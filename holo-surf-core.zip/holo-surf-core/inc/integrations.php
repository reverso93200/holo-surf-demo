<?php
/**
 * Prévisions Windguru et marées du SHOM chargées au clic, avis clients, hébergeur.
 *
 * Conditions des fournisseurs (vérifiées en novembre 2026) :
 * - Windguru : les widgets sont le moyen officiel d'afficher ses prévisions sur un autre site (conditions, article 3.4).
 * - SHOM : « Insérer gratuitement une vignette des horaires des marées du Shom dans votre site Internet ».
 * - maree.info : l'intégration en iframe est interdite, seuls les liens sont autorisés (lien de secours).
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Script de chargement à la demande.
 */
function holo_surf_scripts_integrations() {
	wp_register_script( 'holo-surf-embeds', plugins_url( 'assets/embeds.js', HOLO_SURF_CORE_DIR . 'holo-surf-core.php' ), array(), HOLO_SURF_CORE_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
}
add_action( 'wp_enqueue_scripts', 'holo_surf_scripts_integrations' );

/**
 * Encadré qui remplace le contenu tiers tant que le visiteur ne l'a pas demandé.
 */
function holo_surf_embed_box( $type, $data, $titre, $texte, $bouton, $lien, $lien_label, $style = '' ) {
	wp_enqueue_script( 'holo-surf-embeds' );
	$attrs = '';
	foreach ( $data as $k => $v ) {
		$attrs .= ' data-' . $k . '="' . esc_attr( $v ) . '"';
	}
	return '<div class="hs-embed" data-embed="' . esc_attr( $type ) . '"' . $attrs . ' style="' . esc_attr( $style ) . '">'
		. '<div class="hs-embed-ph">'
		. '<span class="hs-embed-t">' . esc_html( $titre ) . '</span>'
		. '<span class="hs-embed-d">' . esc_html( $texte ) . '</span>'
		. '<button type="button" class="btn b-navy hs-embed-btn">' . esc_html( $bouton ) . '</button>'
		. '<a class="hs-embed-l" href="' . esc_url( $lien ) . '" target="_blank" rel="noopener">' . esc_html( $lien_label ) . '</a>'
		. '</div></div>';
}

/**
 * [holo_windguru] : tableau de prévisions du spot de Capbreton.
 */
function holo_surf_sc_windguru( $a ) {
	$a    = shortcode_atts( array( 'style' => '' ), $a );
	$spot = holo_surf_reglage( 'windguru_spot' );
	return holo_surf_embed_box(
		'windguru',
		array(
			'spot'   => $spot,
			'modele' => holo_surf_reglage( 'windguru_modele' ),
			'vagues' => holo_surf_reglage( 'windguru_vagues' ),
		),
		'Prévisions Windguru, Capbreton',
		'Vent, vagues et période sur dix jours. Le tableau vient du site Windguru et ne se charge qu\'à votre demande : Windguru peut alors déposer ses propres cookies.',
		'Afficher les prévisions',
		'https://www.windguru.cz/' . rawurlencode( $spot ),
		'Ouvrir Windguru dans un nouvel onglet',
		$a['style']
	);
}
add_shortcode( 'holo_windguru', 'holo_surf_sc_windguru' );

/**
 * [holo_marees] : vignette officielle du SHOM pour le port de Capbreton.
 */
function holo_surf_sc_marees( $a ) {
	$a    = shortcode_atts( array( 'style' => '' ), $a );
	$port = holo_surf_reglage( 'shom_port' );
	return holo_surf_embed_box(
		'shom',
		array( 'port' => $port ),
		'Horaires et coefficients du jour',
		'Les marées du port de Capbreton d\'après le SHOM, sur sept jours. La vignette du SHOM ne se charge qu\'à votre demande.',
		'Afficher les marées',
		'https://maree.info/' . rawurlencode( holo_surf_reglage( 'maree_info_port' ) ),
		'Voir les horaires sur maree.info',
		$a['style']
	);
}
add_shortcode( 'holo_marees', 'holo_surf_sc_marees' );

/**
 * Avis saisis dans les réglages (copiés mot pour mot depuis la fiche Google).
 */
function holo_surf_avis_liste() {
	$out = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		$t = trim( (string) holo_surf_reglage( 'avis_' . $i . '_texte' ) );
		if ( '' === $t ) {
			continue;
		}
		$out[] = array(
			'prenom' => trim( (string) holo_surf_reglage( 'avis_' . $i . '_prenom' ) ),
			'note'   => (int) holo_surf_reglage( 'avis_' . $i . '_note' ),
			'date'   => trim( (string) holo_surf_reglage( 'avis_' . $i . '_date' ) ),
			'texte'  => $t,
		);
	}
	return $out;
}

function holo_surf_etoiles( $n, $taille = 18 ) {
	if ( $n < 1 ) {
		return '';
	}
	$s = '<span class="hs-stars" role="img" aria-label="' . esc_attr( $n . ' sur 5' ) . '">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$s .= '<svg aria-hidden="true" width="' . $taille . '" height="' . $taille . '" viewBox="0 0 24 24"><path fill="' . ( $i <= $n ? '#D4AA63' : '#4A6373' ) . '" d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z"/></svg>';
	}
	return $s . '</span>';
}

function holo_surf_meta_avis( $av ) {
	$m = array();
	if ( $av['date'] ) {
		$m[] = esc_html( $av['date'] );
	}
	return $m ? '<span class="hs-avis-date">' . implode( ' ', $m ) . '</span>' : '';
}

/**
 * [holo_avis] : bloc avis de l'accueil. [holo_avis variante="simple"] : l'avis principal seul (page des cours).
 */
function holo_surf_sc_avis( $a ) {
	$a     = shortcode_atts( array( 'variante' => 'accueil' ), $a );
	$avis  = holo_surf_avis_liste();
	$laiss = holo_surf_reglage( 'avis' );
	$fiche = holo_surf_reglage( 'fiche_google' );
	$p     = $avis ? array_shift( $avis ) : null;

	$principal = '';
	if ( $p ) {
		$principal  = '<blockquote style="margin: ' . ( 'simple' === $a['variante'] ? '32px' : '36px' ) . ' 0 0; font-size: clamp(23px, 2.3vw, 31px); line-height: 1.45; font-weight: 500; color: #FFFFFF">« ' . esc_html( $p['texte'] ) . ' »</blockquote>' . "\n";
		$principal .= '<p class="hs-avis-auteur" style="margin: 20px 0 0; font-family: \'Bebas Neue\', sans-serif; font-size: 28px; letter-spacing: 0.04em; color: #D4AA63">' . esc_html( $p['prenom'] ) . '</p>' . "\n";
		$etoiles    = holo_surf_etoiles( $p['note'] ) . holo_surf_meta_avis( $p );
		if ( $etoiles ) {
			$principal .= '<p class="hs-avis-meta">' . $etoiles . '</p>' . "\n";
		}
	}
	if ( 'simple' === $a['variante'] ) {
		return '<h2 class="h2" style="color: #D4AA63">L\'avis de nos surfeurs</h2>' . "\n" . $principal;
	}

	$autres = '';
	foreach ( $avis as $av ) {
		$autres .= '<figure class="hs-avis-carte"><blockquote>« ' . esc_html( $av['texte'] ) . ' »</blockquote><figcaption><span class="hs-avis-nom">' . esc_html( $av['prenom'] ) . '</span>' . holo_surf_etoiles( $av['note'], 15 ) . holo_surf_meta_avis( $av ) . '</figcaption></figure>' . "\n";
	}
	$droite = '<div class="hs-avis-box">' . "\n";
	if ( $autres ) {
		$droite .= '<div class="hs-avis-liste">' . $autres . '</div>' . "\n";
	} else {
		$droite .= '<span class="hs-avis-box-t">Avis Google</span>' . "\n" . '<span class="hs-avis-box-d">Vous avez surfé avec Paul ? Votre avis aide d\'autres surfeurs à choisir leur école.</span>' . "\n";
	}
	$droite .= '<a href="' . esc_url( $laiss ) . '" class="btn b-sand" target="_blank" rel="noopener">Laisser un avis sur Google</a>' . "\n";
	$droite .= '</div>' . "\n";
	if ( $fiche ) {
		$droite .= '<a href="' . esc_url( $fiche ) . '" class="lnk" target="_blank" rel="noopener" style="display: inline-block; margin-top: 18px; color: #FFFFFF">Voir tous les avis sur Google</a>' . "\n";
	}

	return '<div class="reveal" style="flex: 2 1 560px; min-width: 0">' . "\n"
		. '<h2 class="h2" style="color: #D4AA63">L\'avis de nos surfeurs</h2>' . "\n" . $principal
		. '</div>' . "\n"
		. '<div class="reveal" style="flex: 1 1 340px; min-width: 0">' . "\n" . $droite . '</div>';
}
add_shortcode( 'holo_avis', 'holo_surf_sc_avis' );

/**
 * [holo_hebergeur] : coordonnées de l'hébergeur saisies dans les réglages.
 */
add_shortcode(
	'holo_hebergeur',
	function () {
		$n = trim( (string) holo_surf_reglage( 'hebergeur_nom' ) );
		if ( '' === $n ) {
			return 'Les coordonnées de l\'hébergeur du site seront indiquées ici à la mise en ligne.';
		}
		$parts = array_filter( array( $n, holo_surf_reglage( 'hebergeur_adresse' ), holo_surf_reglage( 'hebergeur_tel' ) ) );
		return esc_html( implode( ', ', $parts ) ) . '.';
	}
);

/**
 * [holo_conservation] : durée de conservation des demandes, en mois.
 */
add_shortcode(
	'holo_conservation',
	function () {
		return esc_html( max( 1, (int) holo_surf_reglage( 'conservation_mois' ) ) );
	}
);

/**
 * Styles des encadrés (chargés après ceux du thème).
 */
function holo_surf_styles_integrations() {
	$css = '.hs-embed{position:relative;min-height:300px;border:1.5px dashed #C9B88F;background:#FCF9F2;box-sizing:border-box}'
		. '.hs-embed.is-loaded{border:0;background:none;min-height:0}'
		. '.hs-embed-ph{min-height:inherit;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;text-align:center;box-sizing:border-box}'
		. '.hs-embed-t{font-family:"Bebas Neue",sans-serif;font-size:32px;line-height:1;color:#85652A}'
		. '.hs-embed-d{max-width:460px;font-size:15px;line-height:1.55;color:#55636A}'
		. '.hs-embed-btn{margin-top:6px;width:auto!important}'
		. '.hs-embed-l{font-size:14.5px;color:#192A33;text-decoration:underline;text-decoration-color:#D4AA63;text-underline-offset:4px;display:inline-flex;align-items:center;min-height:44px}'
		. '.hs-embed iframe{display:block;width:100%;border:0}'
		. '.hs-embed-src{margin:10px 0 0;font-size:13.5px;color:#55636A}'
		. '.hs-avis-meta{margin:10px 0 0;display:flex;align-items:center;gap:12px;font-size:15px;color:#B8C6CC}'
		. '.hs-stars{display:inline-flex;gap:2px}'
		. '.hs-avis-box{box-sizing:border-box;border:1.5px solid #4A6373;padding:28px;display:flex;flex-direction:column;align-items:flex-start;gap:14px}'
		. '.hs-avis-box-t{font-family:"Bebas Neue",sans-serif;font-size:32px;line-height:1;color:#FFFFFF}'
		. '.hs-avis-box-d{font-size:15px;line-height:1.5;color:#B8C6CC}'
		. '.hs-avis-liste{display:flex;flex-direction:column;gap:18px;width:100%}'
		. '.hs-avis-carte{margin:0;padding:0 0 18px;border-bottom:1px solid #2C4250}'
		. '.hs-avis-carte blockquote{margin:0;font-size:16px;line-height:1.6;color:#FFFFFF}'
		. '.hs-avis-carte figcaption{margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;font-size:14px;color:#B8C6CC}'
		. '.hs-avis-nom{font-family:"Bebas Neue",sans-serif;font-size:21px;letter-spacing:.04em;color:#D4AA63}'
		. '@media (max-width:760px){.hs-avis-box .btn{width:100%}.hs-embed{min-height:260px}}';
	wp_register_style( 'holo-surf-core', false, array(), HOLO_SURF_CORE_VERSION );
	wp_enqueue_style( 'holo-surf-core' );
	wp_add_inline_style( 'holo-surf-core', $css );
}
add_action( 'wp_enqueue_scripts', 'holo_surf_styles_integrations', 30 );
