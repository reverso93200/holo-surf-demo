<?php
/**
 * Référencement : titres et descriptions de secours, compatibilité Rank Math,
 * robots.txt, llms.txt et redirections des anciennes adresses Wix.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

function holo_surf_rank_math_actif() {
	return defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
}

/**
 * Description de la page (Rank Math, sinon celle de l'installation, sinon l'extrait).
 */
function holo_surf_description() {
	if ( is_front_page() || is_home() || is_singular() ) {
		$id = is_home() ? (int) get_option( 'page_for_posts' ) : get_queried_object_id();
		if ( is_front_page() && ! $id ) {
			return '';
		}
		foreach ( array( 'rank_math_description', '_holo_description' ) as $k ) {
			$d = trim( (string) get_post_meta( $id, $k, true ) );
			if ( $d ) {
				return $d;
			}
		}
		if ( is_singular( 'post' ) ) {
			return wp_strip_all_tags( get_the_excerpt( $id ) );
		}
	}
	return '';
}

/**
 * Titre de la page quand Rank Math n'est pas installé.
 */
function holo_surf_titre( $title ) {
	if ( '' !== (string) $title ) {
		return $title; // titre déjà fourni par Rank Math
	}
	if ( is_404() ) {
		return 'Page introuvable | Holo Surf Capbreton';
	}
	$id = is_home() ? (int) get_option( 'page_for_posts' ) : ( is_singular() ? get_queried_object_id() : 0 );
	if ( $id ) {
		$t = get_post_meta( $id, '_holo_title', true );
		if ( $t ) {
			return $t;
		}
	}
	return $title;
}
add_filter( 'pre_get_document_title', 'holo_surf_titre', 20 );

/**
 * Méta description et Open Graph de secours.
 */
function holo_surf_meta() {
	if ( did_action( 'rank_math/head' ) ) {
		return; // Rank Math écrit déjà description, canonique et Open Graph.
	}
	if ( is_404() ) {
		echo '<meta name="robots" content="noindex">' . "\n";
		return;
	}
	$desc = holo_surf_description();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	$url = is_front_page() ? home_url( '/' ) : ( is_home() ? get_permalink( get_option( 'page_for_posts' ) ) : ( is_singular() ? get_permalink() : '' ) );
	if ( ! $url ) {
		return;
	}
	if ( is_home() ) {
		echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	}
	$img = is_singular( 'post' ) && has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'full' ) : holo_surf_og_image();
	$og  = array(
		'og:type'      => is_singular( 'post' ) ? 'article' : 'website',
		'og:site_name' => 'Holo Surf Capbreton',
		'og:locale'    => 'fr_FR',
		'og:title'     => wp_get_document_title(),
		'og:description' => $desc,
		'og:url'       => $url,
		'og:image'     => $img,
	);
	foreach ( $og as $k => $v ) {
		if ( $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
}
add_action( 'wp_head', 'holo_surf_meta', 3 );

/**
 * Rank Math : ses données structurées sont remplacées par celles de l'école (pas de doublon).
 */
add_filter( 'rank_math/json_ld', '__return_empty_array', PHP_INT_MAX );
add_filter( 'rank_math/frontend/disable_schema', '__return_true' );

/**
 * robots.txt virtuel : moteurs et robots d'IA autorisés, administration fermée.
 */
function holo_surf_robots( $output, $public ) {
	if ( ! $public ) {
		return "User-agent: *\nDisallow: /\n";
	}
	$bots = array( 'OAI-SearchBot', 'ChatGPT-User', 'GPTBot', 'PerplexityBot', 'ClaudeBot', 'Google-Extended' );
	$out  = "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nDisallow: /?s=\nDisallow: /search/\n\n";
	foreach ( $bots as $b ) {
		$out .= "User-agent: $b\nAllow: /\nDisallow: /wp-admin/\n\n";
	}
	$sitemap = holo_surf_rank_math_actif() ? home_url( '/sitemap_index.xml' ) : home_url( '/wp-sitemap.xml' );
	$out    .= 'Sitemap: ' . $sitemap . "\n";
	return $out;
}
add_filter( 'robots_txt', 'holo_surf_robots', PHP_INT_MAX, 2 );

/**
 * Texte de départ de /llms.txt.
 */
function holo_surf_llms_defaut() {
	$u = function ( $k ) {
		return function_exists( 'holo_surf_page_url' ) ? holo_surf_page_url( $k ) : home_url( '/' );
	};
	$tel = holo_surf_reglage( 'telephone' );
	$e   = holo_surf_reglage( 'email' );
	return "# Holo Surf Capbreton\n\n"
		. "> École de surf itinérante à Capbreton, dans les Landes. Paul, moniteur diplômé du BPJEPS Surf et sports associés, encadre lui-même chaque cours : cours collectifs (8 surfeurs maximum), cours particuliers (jusqu'à 4 personnes) et coaching vidéo, dès 5 ans, matériel et assurance compris. Les cours ont lieu le plus souvent à la plage du Santocha, et selon la houle à Hossegor ou Seignosse. École labellisée Ecosafe Surfing. Cours en français, anglais et espagnol.\n\n"
		. "Il n'y a pas de réservation en ligne : on écrit à Paul avec ses dates, le nombre de surfeurs et leur niveau, il répond par e-mail.\n\n"
		. "## Pages principales\n\n"
		. '- [Cours et tarifs](' . $u( 'Tarifs' ) . "): cours collectifs, particuliers et coaching vidéo de 1h30, tarifs de l'année\n"
		. '- [Location](' . $u( 'Location' ) . "): planches en mousse, hybrides et combinaisons, à l'heure ou à la journée\n"
		. '- [Webcam et infos surf](' . $u( 'InfosSurf' ) . "): webcam du Santocha, prévisions, baïnes et vagues\n"
		. '- [Les spots](' . $u( 'Spots' ) . "): plages de Capbreton, Hossegor et Seignosse selon le niveau\n"
		. '- [Le moniteur](' . $u( 'APropos' ) . "): Paul, sa façon d'enseigner et le label Ecosafe Surfing\n"
		. '- [Réserver un cours](' . $u( 'Contact' ) . "): formulaire de demande\n"
		. '- [Blog](' . $u( 'Blog' ) . "): marées, spots, sécurité et conseils\n\n"
		. "## Contact\n\n"
		. '- Téléphone et WhatsApp : ' . $tel . "\n"
		. '- E-mail : ' . $e . "\n"
		. '- Adresse : ' . holo_surf_reglage( 'rue' ) . ', ' . holo_surf_reglage( 'code_postal' ) . ' ' . holo_surf_reglage( 'ville' ) . "\n";
}

/**
 * Chemin demandé, sans le dossier d'installation.
 */
function holo_surf_chemin() {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( $home && '/' !== $home && 0 === strpos( $path, $home ) ) {
		$path = '/' . substr( $path, strlen( $home ) );
	}
	return '/' . trim( strtolower( (string) $path ), '/' );
}

/**
 * /llms.txt servi depuis les réglages.
 */
function holo_surf_servir_llms() {
	if ( '/llms.txt' !== holo_surf_chemin() ) {
		return;
	}
	nocache_headers();
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	echo holo_surf_reglage( 'llms_txt' ); // phpcs:ignore WordPress.Security.EscapeOutput -- texte brut.
	exit;
}
add_action( 'init', 'holo_surf_servir_llms', 1 );

/**
 * Redirections 301 des adresses de l'ancien site Wix.
 */
function holo_surf_redirections() {
	return array(
		'/services-3'              => 'Tarifs',
		'/services-1'              => 'Location',
		'/general-7'               => 'InfosSurf',
		'/les-spots'               => 'Spots',
		'/about-2'                 => 'APropos',
		'/contact-5'               => 'Contact',
		'/s-projects-side-by-side' => 'Concours',
	);
}

function holo_surf_rediriger() {
	$map  = holo_surf_redirections();
	$path = holo_surf_chemin();
	if ( isset( $map[ $path ] ) ) {
		wp_safe_redirect( holo_surf_page_url( $map[ $path ] ), 301, 'Holo Surf' );
		exit;
	}
}
add_action( 'template_redirect', 'holo_surf_rediriger', 0 );

/**
 * Adresse inconnue : page 404, même sur les serveurs qui renseignent PHP_SELF avec l'adresse demandée.
 */
function holo_surf_404_sans_regle( $wp ) {
	if ( '' !== $wp->request && empty( $wp->matched_rule ) && empty( $wp->query_vars ) ) {
		$wp->query_vars['error'] = '404';
	}
}
add_action( 'parse_request', 'holo_surf_404_sans_regle', 20 );
