<?php
/**
 * Référencement : titres et descriptions de secours, compatibilité Rank Math,
 * robots.txt, llms.txt et redirections des anciennes adresses Wix.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

function holo_surf_rank_math_actif() {
	return defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
}

/**
 * Description de la page (Rank Math, sinon celle de l'installation, sinon l'extrait).
 */
function holo_surf_description() {
	if ( is_front_page() || is_home() || is_singular() ) {
		$id = is_home() ? (int) get_option( 'page_for_posts' ) : get_queried_object_id();
		if ( is_front_page() && ! $id ) {
			return '';
		}
		foreach ( array( 'rank_math_description', '_holo_description' ) as $k ) {
			$d = trim( (string) get_post_meta( $id, $k, true ) );
			if ( $d ) {
				return $d;
			}
		}
		if ( is_singular( 'post' ) ) {
			return wp_strip_all_tags( get_the_excerpt( $id ) );
		}
	}
	return '';
}

/**
 * Titre de la page quand Rank Math n'est pas installé.
 */
function holo_surf_titre( $title ) {
	if ( '' !== (string) $title ) {
		return $title; // titre déjà fourni par Rank Math
	}
	if ( is_404() ) {
		return 'Page introuvable | Holo Surf Capbreton';
	}
	$id = is_home() ? (int) get_option( 'page_for_posts' ) : ( is_singular() ? get_queried_object_id() : 0 );
	if ( $id ) {
		$t = get_post_meta( $id, '_holo_title', true );
		if ( $t ) {
			return $t;
		}
	}
	return $title;
}
add_filter( 'pre_get_document_title', 'holo_surf_titre', 20 );

/**
 * Méta description et Open Graph de secours.
 */
function holo_surf_meta() {
	if ( did_action( 'rank_math/head' ) ) {
		return; // Rank Math écrit déjà description, canonique et Open Graph.
	}
	if ( is_404() ) {
		return; // noindex écrit par le filtre wp_robots.
	}
	$desc = holo_surf_description();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	$url = is_front_page() ? home_url( '/' ) : ( is_home() ? get_permalink( get_option( 'page_for_posts' ) ) : ( is_singular() ? get_permalink() : '' ) );
	if ( ! $url ) {
		return;
	}
	if ( is_home() ) {
		echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	}
	$og_img = holo_surf_og( holo_surf_id_affiche() );
	$img    = $og_img ? $og_img[0] : holo_surf_og_image();
	$og     = array(
		'og:type'      => is_singular( 'post' ) ? 'article' : 'website',
		'og:site_name' => 'Holo Surf Capbreton',
		'og:locale'    => 'fr_FR',
		'og:title'     => wp_get_document_title(),
		'og:description' => $desc,
		'og:url'       => $url,
		'og:image'     => $img,
	);
	if ( $og_img ) {
		$og['og:image:width']  = '1200';
		$og['og:image:height'] = '630';
		$og['og:image:type']   = 'image/jpeg';
		$og['og:image:alt']    = (string) get_post_meta( $og_img[3], '_wp_attachment_image_alt', true );
	}
	if ( is_singular( 'post' ) ) {
		$og['article:published_time'] = get_post_time( 'c', true );
		$og['article:modified_time']  = get_post_modified_time( 'c', true );
	}
	foreach ( $og as $k => $v ) {
		if ( $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	if ( $img ) {
		echo '<meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n";
	}
}
add_action( 'wp_head', 'holo_surf_meta', 3 );

/**
 * Rank Math : ses données structurées sont remplacées par celles de l'école (pas de doublon).
 */
add_filter( 'rank_math/json_ld', '__return_empty_array', PHP_INT_MAX );
add_filter( 'rank_math/frontend/disable_schema', '__return_true' );

/**
 * robots.txt virtuel : moteurs et robots d'IA autorisés, administration fermée.
 */
function holo_surf_robots( $output, $public ) {
	if ( ! $public ) {
		return "User-agent: *\nDisallow: /\n";
	}
	$bots = array( 'OAI-SearchBot', 'ChatGPT-User', 'GPTBot', 'PerplexityBot', 'ClaudeBot', 'Google-Extended' );
	$out  = "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nDisallow: /?s=\nDisallow: /search/\n\n";
	foreach ( $bots as $b ) {
		$out .= "User-agent: $b\nAllow: /\nDisallow: /wp-admin/\n\n";
	}
	$sitemap = holo_surf_rank_math_actif() ? home_url( '/sitemap_index.xml' ) : home_url( '/wp-sitemap.xml' );
	$out    .= 'Sitemap: ' . $sitemap . "\n";
	if ( ! holo_surf_rank_math_actif() ) {
		$out .= 'Sitemap: ' . home_url( '/sitemap-images.xml' ) . "\n";
	}
	return $out;
}
add_filter( 'robots_txt', 'holo_surf_robots', PHP_INT_MAX, 2 );

/**
 * Texte de départ de /llms.txt.
 */
function holo_surf_llms_defaut() {
	$u = function ( $k ) {
		return function_exists( 'holo_surf_page_url' ) ? holo_surf_page_url( $k ) : home_url( '/' );
	};
	$tel = holo_surf_reglage( 'telephone' );
	$e   = holo_surf_reglage( 'email' );
	return "# Holo Surf Capbreton\n\n"
		. "> École de surf itinérante à Capbreton, dans les Landes. Paul, moniteur diplômé du BPJEPS Surf et sports associés, encadre lui-même chaque cours : cours collectifs (8 surfeurs maximum), cours particuliers (jusqu'à 4 personnes) et coaching vidéo, dès 5 ans, matériel et assurance compris. Les cours ont lieu le plus souvent à la plage du Santocha, et selon la houle à Hossegor ou Seignosse. École labellisée Ecosafe Surfing. Cours en français, anglais et espagnol.\n\n"
		. "Il n'y a pas de réservation en ligne : on écrit à Paul avec ses dates, le nombre de surfeurs et leur niveau, il répond par e-mail.\n\n"
		. "## Pages principales\n\n"
		. '- [Cours et tarifs](' . $u( 'Tarifs' ) . "): cours collectifs, particuliers et coaching vidéo de 1h30, tarifs de l'année\n"
		. '- [Location](' . $u( 'Location' ) . "): planches en mousse, hybrides et combinaisons, à l'heure ou à la journée\n"
		. '- [Webcam et infos surf](' . $u( 'InfosSurf' ) . "): webcam du Santocha, prévisions, baïnes et vagues\n"
		. '- [Les spots](' . $u( 'Spots' ) . "): plages de Capbreton, Hossegor et Seignosse selon le niveau\n"
		. '- [Le moniteur](' . $u( 'APropos' ) . "): Paul, sa façon d'enseigner et le label Ecosafe Surfing\n"
		. '- [Réserver un cours](' . $u( 'Contact' ) . "): formulaire de demande\n"
		. '- [Blog](' . $u( 'Blog' ) . "): marées, spots, sécurité et conseils\n\n"
		. "## Contact\n\n"
		. '- Téléphone et WhatsApp : ' . $tel . "\n"
		. '- E-mail : ' . $e . "\n"
		. '- Adresse : ' . holo_surf_reglage( 'rue' ) . ', ' . holo_surf_reglage( 'code_postal' ) . ' ' . holo_surf_reglage( 'ville' ) . "\n";
}

/**
 * Chemin demandé, sans le dossier d'installation.
 */
function holo_surf_chemin() {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( $home && '/' !== $home && 0 === strpos( $path, $home ) ) {
		$path = '/' . substr( $path, strlen( $home ) );
	}
	return '/' . trim( strtolower( (string) $path ), '/' );
}

/**
 * Articles publiés pour llms.txt : titre, adresse, résumé d'une phrase.
 */
function holo_surf_llms_articles() {
	$out   = "## Articles du blog\n\n";
	$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC' ) );
	foreach ( $posts as $p ) {
		$r = trim( (string) get_post_meta( $p->ID, '_holo_description', true ) );
		if ( '' === $r ) {
			$r = wp_strip_all_tags( get_the_excerpt( $p ) );
		}
		$r    = preg_replace( '/\s+/u', ' ', $r );
		$out .= '- [' . html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ) . '](' . get_permalink( $p ) . '): ' . $r . "\n";
	}
	return $out;
}

/**
 * Texte brut lisible d'un contenu HTML (titres en Markdown, listes, tableaux).
 */
function holo_surf_texte( $html ) {
	$html = preg_replace( '#<(script|style|svg|noscript|form|button)\b.*?</\1>#is', '', $html );
	$html = preg_replace_callback(
		'#<h([1-4])\b[^>]*>(.*?)</h\1>#is',
		function ( $m ) {
			return "\n\n" . str_repeat( '#', min( 4, (int) $m[1] + 1 ) ) . ' ' . trim( wp_strip_all_tags( $m[2] ) ) . "\n\n";
		},
		$html
	);
	$html = preg_replace( '#<li\b[^>]*>#i', "\n- ", $html );
	$html = preg_replace( '#</(p|div|tr|ul|ol|section|details|summary|table|caption|dl|dt|dd|blockquote)>#i', "\n", $html );
	$html = preg_replace( '#</t[hd]>#i', ' | ', $html );
	$html = preg_replace( '#</(span|a|strong|em|b|i|time)>#i', '$0 ', $html );
	$t    = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
	$t    = preg_replace( "/[ \t\x{00a0}]+/u", ' ', $t );
	$t    = preg_replace( "/ *\n */", "\n", $t );
	return trim( preg_replace( "/\n{3,}/", "\n\n", $t ) );
}

/**
 * /llms-full.txt : texte des pages principales, mis en cache jusqu'à la prochaine modification.
 */
function holo_surf_llms_full() {
	$cache = get_transient( 'holo_llms_full' );
	if ( $cache ) {
		return $cache;
	}
	$ids = get_option( 'holo_surf_pages', array() );
	$out = "# Holo Surf Capbreton : texte complet des pages principales\n\n> Version texte du site, pour les assistants et moteurs de réponse. Liste des articles : " . home_url( '/llms.txt' ) . "\n";
	foreach ( array( 'Main', 'Tarifs', 'Location', 'InfosSurf', 'Spots', 'APropos', 'Contact' ) as $k ) {
		if ( empty( $ids[ $k ] ) || ! get_post( $ids[ $k ] ) ) {
			continue;
		}
		$p    = get_post( $ids[ $k ] );
		$t    = trim( (string) get_post_meta( $p->ID, '_holo_title', true ) );
		$out .= "\n\n---\n\n# " . ( $t ? $t : get_the_title( $p ) ) . "\n\nAdresse : " . ( 'Main' === $k ? home_url( '/' ) : get_permalink( $p ) ) . "\n\n";
		$out .= holo_surf_texte( apply_filters( 'the_content', $p->post_content ) ) . "\n";
	}
	set_transient( 'holo_llms_full', $out, WEEK_IN_SECONDS );
	return $out;
}
add_action(
	'save_post',
	function () {
		delete_transient( 'holo_llms_full' );
	}
);

/**
 * /llms.txt (réglages + articles publiés, toujours à jour) et /llms-full.txt.
 */
function holo_surf_servir_llms() {
	$c = holo_surf_chemin();
	if ( '/llms.txt' !== $c && '/llms-full.txt' !== $c ) {
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	header( 'Cache-Control: public, max-age=3600' );
	if ( '/llms-full.txt' === $c ) {
		echo holo_surf_llms_full(); // phpcs:ignore WordPress.Security.EscapeOutput -- texte brut.
		exit;
	}
	$t = trim( (string) holo_surf_reglage( 'llms_txt' ) );
	if ( '' === $t ) {
		$t = holo_surf_llms_defaut();
	}
	$pos = strpos( $t, '## Articles du blog' );
	if ( false !== $pos ) {
		$t = rtrim( substr( $t, 0, $pos ) );
	}
	echo $t . "\n\n" . holo_surf_llms_articles() . "\n## Pour aller plus loin\n\n- [Texte complet des pages principales](" . home_url( '/llms-full.txt' ) . ")\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- texte brut.
	exit;
}
add_action( 'template_redirect', 'holo_surf_servir_llms', -1 );

/**
 * Redirections 301 des adresses de l'ancien site Wix.
 */
function holo_surf_redirections() {
	return array(
		'/services-3'              => 'Tarifs',
		'/services-1'              => 'Location',
		'/general-7'               => 'InfosSurf',
		'/les-spots'               => 'Spots',
		'/about-2'                 => 'APropos',
		'/contact-5'               => 'Contact',
		'/s-projects-side-by-side' => 'Concours',
	);
}

function holo_surf_rediriger() {
	$map  = holo_surf_redirections();
	$path = holo_surf_chemin();
	if ( isset( $map[ $path ] ) ) {
		wp_safe_redirect( holo_surf_page_url( $map[ $path ] ), 301, 'Holo Surf' );
		exit;
	}
}
add_action( 'template_redirect', 'holo_surf_rediriger', 0 );

/**
 * Adresse inconnue : page 404, même sur les serveurs qui renseignent PHP_SELF avec l'adresse demandée.
 */
function holo_surf_404_sans_regle( $wp ) {
	if ( '' !== $wp->request && empty( $wp->matched_rule ) && empty( $wp->query_vars ) ) {
		$wp->query_vars['error'] = '404';
	}
}
add_action( 'parse_request', 'holo_surf_404_sans_regle', 20 );


/**
 * Pages exclues des résultats : mentions légales (noindex, follow), 404 et recherche.
 */
function holo_surf_noindex_page() {
	$ids = get_option( 'holo_surf_pages', array() );
	return ! empty( $ids['Legal'] ) && is_page( (int) $ids['Legal'] );
}
add_filter(
	'wp_robots',
	function ( $robots ) {
		if ( is_404() || is_search() || holo_surf_noindex_page() ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['max-image-preview'] );
		}
		return $robots;
	}
);

/**
 * Sitemap de WordPress : sans les mentions légales, sans les auteurs.
 */
add_filter(
	'wp_sitemaps_posts_query_args',
	function ( $args, $type ) {
		$ids = get_option( 'holo_surf_pages', array() );
		if ( 'page' === $type && ! empty( $ids['Legal'] ) ) {
			$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), array( (int) $ids['Legal'] ) );
		}
		return $args;
	},
	10,
	2
);
add_filter(
	'wp_sitemaps_add_provider',
	function ( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	},
	10,
	2
);

/**
 * Sitemap des images (quand Rank Math, qui inclut déjà les images, n'est pas installé).
 */
function holo_surf_sitemap_images() {
	if ( '/sitemap-images.xml' !== holo_surf_chemin() || holo_surf_rank_math_actif() ) {
		return;
	}
	$ids   = get_option( 'holo_surf_pages', array() );
	$legal = ! empty( $ids['Legal'] ) ? (int) $ids['Legal'] : 0;
	$posts = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC' ) );
	status_header( 200 );
	header( 'Content-Type: application/xml; charset=utf-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
	foreach ( $posts as $p ) {
		if ( $p->ID === $legal ) {
			continue;
		}
		$imgs = holo_surf_images_du_contenu( apply_filters( 'the_content', $p->post_content ) );
		$t    = (int) get_post_thumbnail_id( $p );
		if ( $t ) {
			array_unshift( $imgs, $t );
		}
		$imgs = array_unique( $imgs );
		if ( ! $imgs ) {
			continue;
		}
		$loc = (int) get_option( 'page_on_front' ) === $p->ID ? home_url( '/' ) : get_permalink( $p );
		echo '<url><loc>' . esc_url( $loc ) . '</loc>';
		foreach ( array_slice( $imgs, 0, 30 ) as $id ) {
			echo '<image:image><image:loc>' . esc_url( wp_get_attachment_url( $id ) ) . '</image:loc></image:image>';
		}
		echo "</url>\n";
	}
	echo '</urlset>';
	exit;
}
add_action( 'template_redirect', 'holo_surf_sitemap_images', -1 );

/**
 * Pas d'archive auteur publique : Paul est présenté sur la page À propos (redirection 301).
 */
add_action(
	'template_redirect',
	function () {
		if ( is_author() || ( isset( $_GET['author'] ) && ! is_admin() ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( holo_surf_page_url( 'APropos' ), 301, 'Holo Surf' );
			exit;
		}
	},
	1
);
add_filter(
	'author_link',
	function () {
		return holo_surf_page_url( 'APropos' );
	}
);
