<?php
/**
 * Réglages Holo Surf : coordonnées, réseaux, saison et tarifs, saisis à un seul endroit.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

const HOLO_SURF_OPTION = 'holo_surf_reglages';

/**
 * Durées de location (clé => libellé du tableau).
 */
function holo_surf_durees_location() {
	return array(
		'1h'   => '1h',
		'2h'   => '2h',
		'4h'   => '4h',
		'jour' => 'Journée',
		'24h'  => '24h',
		'2j'   => '2 jours',
		'plus' => '+ / jour',
	);
}

/**
 * Structure des réglages : sections, champs, valeurs par défaut (celles de la maquette).
 */
function holo_surf_champs() {
	$loc = array(
		'mousse'      => array( 'Location planche mousse', array( 11, 13, 16, 25, 34, 44, 15 ) ),
		'hybride'     => array( 'Location planche hybride', array( 13, 15, 18, 29, 39, 49, 17 ) ),
		'combinaison' => array( 'Location combinaison', array( 5, 7, 9, 12, 15, 24, 7 ) ),
	);
	$s = array(
		'coordonnees' => array(
			'titre'  => 'Coordonnées',
			'champs' => array(
				'telephone'       => array( 'Téléphone affiché', '06 60 95 77 20' ),
				'telephone_intl'  => array( 'Téléphone au format international (liens d\'appel)', '+33660957720' ),
				'email'           => array( 'E-mail affiché sur le site', 'holosurfcapbreton@gmail.com' ),
				'email_reception' => array( 'E-mail qui reçoit les demandes de réservation', 'holosurfcapbreton@gmail.com' ),
				'rue'             => array( 'Adresse (rue)', '29b rue Jean-Baptiste Gabarra' ),
				'code_postal'     => array( 'Code postal', '40130' ),
				'ville'           => array( 'Ville', 'Capbreton' ),
				'langues'         => array( 'Langues (bandeau du haut)', 'We speak English / Hablamos español' ),
			),
		),
		'reseaux'     => array(
			'titre'  => 'Réseaux',
			'champs' => array(
				'instagram' => array( 'Instagram (adresse complète)', 'https://www.instagram.com/holosurfcapbreton/' ),
				'facebook'  => array( 'Facebook (adresse complète)', 'https://www.facebook.com/profile.php?id=61574016721386' ),
				'whatsapp'  => array( 'WhatsApp (numéro au format 33…)', '33660957720' ),
				'avis'      => array( 'Lien « Laisser un avis sur Google »', 'https://www.google.com/maps/search/?api=1&query=Holo+Surf+Capbreton' ),
			),
		),
		'saison'      => array(
			'titre'  => 'Saison',
			'champs' => array(
				'annee_tarifs'  => array( 'Année des tarifs', '2026' ),
				'saison_defaut' => array( 'Tableau affiché en premier (cours collectifs)', 'auto', 'select', array( 'auto' => 'Automatique : haute saison en juillet et août', 'bs' => 'Toujours la basse saison', 'hs' => 'Toujours juillet et août' ) ),
			),
		),
		'collectif'   => array(
			'titre'  => 'Cours collectifs (1h30, prix total selon le nombre de cours)',
			'champs' => array(),
		),
		'particulier' => array(
			'titre'  => 'Cours particulier (prix total selon le nombre de personnes)',
			'champs' => array(),
		),
		'coaching'    => array(
			'titre'  => 'Coaching vidéo (prix total selon le nombre de personnes)',
			'champs' => array(),
		),
		'location'    => array(
			'titre'  => 'Location (prix par article)',
			'champs' => array(),
		),
	);
	$bs = array( 36, 72, 100, 129, 155, 26 );
	$hs = array( 40, 79, 109, 139, 169, 30 );
	for ( $i = 1; $i <= 6; $i++ ) {
		$l = 6 === $i ? 'à partir de 6 cours, prix par cours' : $i . ' cours';
		$s['collectif']['champs'][ 'collectif_bs_' . $i ] = array( 'Basse saison, ' . $l, $bs[ $i - 1 ], 'prix' );
	}
	for ( $i = 1; $i <= 6; $i++ ) {
		$l = 6 === $i ? 'à partir de 6 cours, prix par cours' : $i . ' cours';
		$s['collectif']['champs'][ 'collectif_hs_' . $i ] = array( 'Juillet et août, ' . $l, $hs[ $i - 1 ], 'prix' );
	}
	foreach ( array( 80, 150, 210, 280 ) as $i => $v ) {
		$s['particulier']['champs'][ 'particulier_' . ( $i + 1 ) ] = array( ( $i + 1 ) . ' personne' . ( $i ? 's' : '' ), $v, 'prix' );
	}
	foreach ( array( 70, 120, 170, 210 ) as $i => $v ) {
		$s['coaching']['champs'][ 'coaching_' . ( $i + 1 ) ] = array( ( $i + 1 ) . ' personne' . ( $i ? 's' : '' ), $v, 'prix' );
	}
	$durees = holo_surf_durees_location();
	foreach ( $loc as $k => $def ) {
		$j = 0;
		foreach ( $durees as $dk => $dl ) {
			$s['location']['champs'][ $k . '_' . $dk ] = array( $def[0] . ', ' . $dl, $def[1][ $j++ ], 'prix' );
		}
	}
	$s['widgets'] = array(
		'titre'  => 'Prévisions et marées (widgets chargés au clic)',
		'champs' => array(
			'windguru_spot'   => array( 'Windguru : numéro du spot (48571 = France - Capbreton)', '48571' ),
			'windguru_modele' => array( 'Windguru : modèle de vent (100 = mélange WG)', '100' ),
			'windguru_vagues' => array( 'Windguru : modèle de vagues (84 = GFS-Wave 16 km)', '84' ),
			'shom_port'       => array( 'SHOM : code du port pour la vignette des marées', 'CAPBRETON' ),
			'maree_info_port' => array( 'maree.info : numéro du port (lien de secours, 143 = Capbreton)', '143' ),
			'webcam_url'      => array( 'Webcam : adresse du lecteur intégré (page Infos surf)', 'https://pv.viewsurf.com/2534/Capbreton-Santocha', 'url' ),
			'webcam_titre'    => array( 'Webcam : nom de la caméra', 'Webcam de la plage du Santocha' ),
			'webcam_source'   => array( 'Webcam : site d\'origine à créditer', 'Santocha Surf Club' ),
			'webcam_page'     => array( 'Webcam : page de la caméra sur le site d\'origine (lien de crédit)', 'https://www.santocha.org/webcam/', 'url' ),
			'webcam_credit_titre' => array( 'Webcam : titre du crédit sous la caméra', 'Merci au Santocha Surf Club' ),
			'webcam_credit_texte' => array( 'Webcam : texte du crédit sous la caméra', 'Ces images en direct viennent de la webcam de la plage du Santocha, que le Santocha Surf Club propose sur son site avec le lecteur de Viewsurf. Leur site est excellent pour suivre les conditions à Capbreton : la webcam, mais aussi les infos sur le spot et la lecture des vagues.', 'textarea_court' ),
		),
	);
	$s['avis'] = array(
		'titre'  => 'Avis clients (copiés mot pour mot depuis la fiche Google)',
		'champs' => array(
			'fiche_google'  => array( 'Lien de la fiche Google (« Voir tous les avis »)', '', 'url', null, true ),
			'avis_extension' => array( 'Code court d\'une extension d\'avis Google (par exemple [trustindex no="…"] de Widgets for Google Reviews). Rempli, il remplace les avis saisis ci-dessous.', '', 'text', null, true ),
		),
	);
	for ( $i = 1; $i <= 6; $i++ ) {
		$d = 1 === $i ? array( 'Guillaume', '', '', 'Une organisation remarquable et une grande souplesse. Merci beaucoup, Paul, pour ta joie de vivre communicative, ta pédagogie et le partage généreux de ta passion qui a su faire germer la graine de deux futurs passionnés.' ) : array( '', '', '', '' );
		$s['avis']['champs'][ 'avis_' . $i . '_prenom' ] = array( 'Avis ' . $i . ' : prénom', $d[0], 'text', null, true );
		$s['avis']['champs'][ 'avis_' . $i . '_note' ]   = array( 'Avis ' . $i . ' : note sur 5 (vide si inconnue)', $d[1], 'select', array( '' => '', '5' => '5', '4' => '4', '3' => '3', '2' => '2', '1' => '1' ), true );
		$s['avis']['champs'][ 'avis_' . $i . '_date' ]   = array( 'Avis ' . $i . ' : date (par exemple « août 2026 »)', $d[2], 'text', null, true );
		$s['avis']['champs'][ 'avis_' . $i . '_texte' ]  = array( 'Avis ' . $i . ' : texte, mot pour mot', $d[3], 'textarea_court', null, true );
	}
	$s['reponse'] = array(
		'titre'  => 'Réponse automatique au formulaire',
		'champs' => array(
			'reponse_active' => array( 'Envoyer la réponse automatique', '1', 'select', array( '1' => 'Oui', '0' => 'Non' ) ),
			'reponse_sujet'  => array( 'Sujet de l\'e-mail', 'Demande bien reçue' ),
			'reponse_texte'  => array( 'Texte de l\'e-mail ({prenom}, {recapitulatif}, {telephone}, {email} et {adresse} sont remplacés automatiquement)', "Bonjour {prenom},\n\nVotre demande est bien arrivée chez Holo Surf Capbreton. Paul vous répond par e-mail, en général sous 24 h.\n\nVoici le récapitulatif de votre demande :\n\n{recapitulatif}\n\nPour toute question en attendant :\nTéléphone et WhatsApp : {telephone}\nE-mail : {email}\nAdresse : {adresse}\n\nÀ très vite dans les vagues !\nPaul, Holo Surf Capbreton", 'textarea' ),
		),
	);
	$s['legal'] = array(
		'titre'  => 'Pages légales et données personnelles',
		'champs' => array(
			'hebergeur_nom'     => array( 'Hébergeur : raison sociale', '', 'text', null, true ),
			'hebergeur_adresse' => array( 'Hébergeur : adresse', '', 'text', null, true ),
			'hebergeur_tel'     => array( 'Hébergeur : téléphone', '', 'text', null, true ),
			'conservation_mois' => array( 'Durée de conservation des demandes de réservation, en mois (supprimées automatiquement ensuite)', '36' ),
		),
	);
	$s['llms'] = array(
		'titre'  => 'Fichier llms.txt (présentation de l\'école pour les assistants IA)',
		'champs' => array(
			'llms_txt' => array( 'Contenu de /llms.txt', '', 'textarea' ),
		),
	);
	return $s;
}

/**
 * Valeurs par défaut à plat.
 */
function holo_surf_defauts() {
	$out = array();
	foreach ( holo_surf_champs() as $sec ) {
		foreach ( $sec['champs'] as $k => $c ) {
			$out[ $k ] = (string) $c[1];
		}
	}
	return $out;
}

/**
 * Champs qui peuvent rester vides (avis, hébergeur) : un champ vidé ne reprend pas la valeur d'origine.
 */
function holo_surf_vides_autorises() {
	$out = array();
	foreach ( holo_surf_champs() as $sec ) {
		foreach ( $sec['champs'] as $k => $c ) {
			if ( ! empty( $c[4] ) ) {
				$out[] = $k;
			}
		}
	}
	return $out;
}

/**
 * Lecture d'un réglage.
 */
function holo_surf_reglage( $key ) {
	static $cache = null;
	if ( null === $cache || doing_action( 'update_option_' . HOLO_SURF_OPTION ) ) {
		$saved = get_option( HOLO_SURF_OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$cache = array_merge( holo_surf_defauts(), array_filter( $saved, 'strlen' ) );
		foreach ( holo_surf_vides_autorises() as $k ) {
			if ( array_key_exists( $k, $saved ) ) {
				$cache[ $k ] = $saved[ $k ];
			}
		}
	}
	if ( 'particulier_pp3' === $key ) {
		return holo_surf_nombre( $cache['particulier_3'] ) / 3;
	}
	if ( 'coaching_pp4' === $key ) {
		return holo_surf_nombre( $cache['coaching_4'] ) / 4;
	}
	if ( 'llms_txt' === $key && '' === trim( (string) $cache['llms_txt'] ) ) {
		return holo_surf_llms_defaut();
	}
	return isset( $cache[ $key ] ) ? $cache[ $key ] : '';
}
add_action(
	'update_option_' . HOLO_SURF_OPTION,
	function () {
		holo_surf_reglage( 'telephone' );
	}
);

/**
 * Valeur numérique d'un prix saisi (« 52,50 » ou « 52.5 »).
 */
function holo_surf_nombre( $v ) {
	return (float) str_replace( array( ' ', "\xc2\xa0", ',' ), array( '', '', '.' ), (string) $v );
}

/**
 * Prix au format français : 36 €, 52,50 €.
 */
function holo_surf_prix_format( $v ) {
	$n = holo_surf_nombre( $v );
	$t = ( floor( $n ) == $n ) ? number_format( $n, 0, ',', "\xc2\xa0" ) : number_format( $n, 2, ',', "\xc2\xa0" ); // phpcs:ignore Universal.Operators.StrictComparisons
	return $t . "\xc2\xa0€";
}

/**
 * Prix pour les données structurées : 36, 52.50.
 */
function holo_surf_prix_schema( $key ) {
	$n = holo_surf_nombre( holo_surf_reglage( $key ) );
	return ( floor( $n ) == $n ) ? (string) (int) $n : number_format( $n, 2, '.', '' ); // phpcs:ignore Universal.Operators.StrictComparisons
}

/**
 * Saison affichée en premier.
 */
function holo_surf_saison_courante() {
	$d = holo_surf_reglage( 'saison_defaut' );
	if ( 'bs' === $d || 'hs' === $d ) {
		return $d;
	}
	$m = (int) wp_date( 'n' );
	return ( 7 === $m || 8 === $m ) ? 'hs' : 'bs';
}

/**
 * Page de réglages (accessible aux éditeurs : Paul change ses prix lui-même).
 */
function holo_surf_menu_reglages() {
	add_menu_page( 'Réglages Holo Surf', 'Réglages Holo Surf', 'edit_pages', 'holo-surf-reglages', 'holo_surf_page_reglages', 'dashicons-palmtree', 3 );
}
add_action( 'admin_menu', 'holo_surf_menu_reglages' );

/**
 * Enregistrement du formulaire de réglages.
 */
function holo_surf_enregistrer_reglages() {
	if ( ! isset( $_POST['holo_surf_reglages_nonce'] ) || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	check_admin_referer( 'holo_surf_reglages', 'holo_surf_reglages_nonce' );
	$in  = isset( $_POST['hs'] ) && is_array( $_POST['hs'] ) ? wp_unslash( $_POST['hs'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$out = array();
	foreach ( holo_surf_champs() as $sec ) {
		foreach ( $sec['champs'] as $k => $c ) {
			$type = isset( $c[2] ) ? $c[2] : 'text';
			$v    = isset( $in[ $k ] ) ? $in[ $k ] : '';
			if ( 'textarea' === $type || 'textarea_court' === $type ) {
				$v = sanitize_textarea_field( $v );
			} elseif ( 'url' === $type ) {
				$v = esc_url_raw( trim( $v ) );
			} elseif ( in_array( $k, array( 'windguru_spot', 'windguru_modele', 'windguru_vagues', 'maree_info_port', 'conservation_mois' ), true ) ) {
				$v = preg_replace( '/[^0-9]/', '', $v );
			} elseif ( 'shom_port' === $k ) {
				$v = strtoupper( preg_replace( '/[^A-Za-z0-9_]/', '', $v ) );
			} elseif ( 'prix' === $type ) {
				$v = preg_replace( '/[^0-9,.]/', '', $v );
			} elseif ( in_array( $k, array( 'instagram', 'facebook', 'avis' ), true ) ) {
				$v = esc_url_raw( trim( $v ) );
			} elseif ( in_array( $k, array( 'email', 'email_reception' ), true ) ) {
				$v = sanitize_email( $v );
			} elseif ( 'select' === $type ) {
				$v = array_key_exists( $v, $c[3] ) ? $v : $c[1];
			} else {
				$v = sanitize_text_field( $v );
			}
			$out[ $k ] = $v;
		}
	}
	update_option( HOLO_SURF_OPTION, $out );
	wp_safe_redirect( add_query_arg( 'enregistre', '1', admin_url( 'admin.php?page=holo-surf-reglages' ) ) );
	exit;
}
add_action( 'admin_init', 'holo_surf_enregistrer_reglages' );

/**
 * Affichage de la page de réglages.
 */
function holo_surf_page_reglages() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$saved = get_option( HOLO_SURF_OPTION, array() );
	$saved = is_array( $saved ) ? $saved : array();
	echo '<div class="wrap holo-reglages"><h1>Réglages Holo Surf</h1>';
	if ( isset( $_GET['enregistre'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success is-dismissible"><p>Réglages enregistrés. Les prix sont à jour partout sur le site.</p></div>';
	}
	echo '<p>Chaque valeur saisie ici se met à jour partout : pages, tableaux de prix, pied de page et données lues par Google. Un prix ou une coordonnée laissé vide reprend la valeur d\'origine. Les avis et l\'hébergeur peuvent rester vides.</p>';
	echo '<form method="post">';
	wp_nonce_field( 'holo_surf_reglages', 'holo_surf_reglages_nonce' );
	echo '<p class="holo-sommaire">';
	foreach ( holo_surf_champs() as $id => $sec ) {
		echo '<a href="#' . esc_attr( $id ) . '">' . esc_html( strtok( $sec['titre'], '(' ) ) . '</a> ';
	}
	echo '</p>';
	foreach ( holo_surf_champs() as $id => $sec ) {
		echo '<h2 id="' . esc_attr( $id ) . '">' . esc_html( $sec['titre'] ) . '</h2><table class="form-table" role="presentation">';
		foreach ( $sec['champs'] as $k => $c ) {
			$type = isset( $c[2] ) ? $c[2] : 'text';
			$val  = isset( $saved[ $k ] ) && ( '' !== $saved[ $k ] || ! empty( $c[4] ) ) ? $saved[ $k ] : (string) $c[1];
			if ( 'llms_txt' === $k && '' === trim( $val ) ) {
				$val = holo_surf_llms_defaut();
			}
			echo '<tr><th scope="row"><label for="hs-' . esc_attr( $k ) . '">' . esc_html( $c[0] ) . '</label></th><td>';
			if ( 'textarea' === $type || 'textarea_court' === $type ) {
				echo '<textarea id="hs-' . esc_attr( $k ) . '" name="hs[' . esc_attr( $k ) . ']" rows="' . ( 'textarea' === $type ? 16 : 4 ) . '" class="large-text">' . esc_textarea( $val ) . '</textarea>';
			} elseif ( 'select' === $type ) {
				echo '<select id="hs-' . esc_attr( $k ) . '" name="hs[' . esc_attr( $k ) . ']">';
				foreach ( $c[3] as $ok => $ol ) {
					echo '<option value="' . esc_attr( $ok ) . '"' . selected( $val, $ok, false ) . '>' . esc_html( $ol ) . '</option>';
				}
				echo '</select>';
			} elseif ( 'prix' === $type ) {
				echo '<input id="hs-' . esc_attr( $k ) . '" name="hs[' . esc_attr( $k ) . ']" type="text" inputmode="decimal" class="small-text" value="' . esc_attr( $val ) . '"> €';
			} else {
				echo '<input id="hs-' . esc_attr( $k ) . '" name="hs[' . esc_attr( $k ) . ']" type="text" class="regular-text" value="' . esc_attr( $val ) . '">';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}
	submit_button( 'Enregistrer les réglages' );
	echo '</form></div>';
	if ( current_user_can( 'manage_options' ) ) {
		echo '<h2>Installation</h2><p>Recrée ce qui manque (pages, médias, menus, article modèle) sans toucher aux pages existantes.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="holo_surf_installer">';
		wp_nonce_field( 'holo_surf_installer' );
		submit_button( 'Relancer l\'installation', 'secondary' );
		echo '</form>';
	}
	echo '<style>.holo-reglages h2{margin-top:2.2em;padding-top:1em;border-top:1px solid #dcdcde}.holo-sommaire a{margin-right:14px}</style>';
}
