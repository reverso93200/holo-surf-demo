<?php
/**
 * Administration simplifiée pour Paul (rôle Éditeur) et commentaires désactivés.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

function holo_surf_est_paul() {
	return is_user_logged_in() && ! current_user_can( 'manage_options' );
}

/**
 * Tableau de bord : un seul encart avec les quatre actions utiles.
 */
function holo_surf_dashboard() {
	if ( holo_surf_est_paul() ) {
		global $wp_meta_boxes;
		$wp_meta_boxes['dashboard'] = array(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		remove_action( 'welcome_panel', 'wp_welcome_panel' );
	}
	wp_add_dashboard_widget( 'holo_surf_accueil', 'Holo Surf', 'holo_surf_dashboard_widget' );
}
add_action( 'wp_dashboard_setup', 'holo_surf_dashboard', 99 );

function holo_surf_dashboard_widget() {
	$n = wp_count_posts( 'holo_demande' );
	$n = isset( $n->private ) ? (int) $n->private : 0;
	$b = array(
		array( 'Écrire un article', admin_url( 'post-new.php' ), 'dashicons-edit' ),
		array( 'Modifier les tarifs', admin_url( 'admin.php?page=holo-surf-reglages#collectif' ), 'dashicons-tag' ),
		array( 'Voir les demandes' . ( $n ? ' (' . $n . ')' : '' ), admin_url( 'edit.php?post_type=holo_demande' ), 'dashicons-email-alt' ),
		array( 'Aide', admin_url( 'admin.php?page=holo-surf-aide' ), 'dashicons-sos' ),
	);
	echo '<div class="holo-dash">';
	foreach ( $b as $x ) {
		echo '<a class="holo-dash-btn" href="' . esc_url( $x[1] ) . '"><span class="dashicons ' . esc_attr( $x[2] ) . '" aria-hidden="true"></span>' . esc_html( $x[0] ) . '</a>';
	}
	echo '</div><p style="margin:14px 0 0">Le site : <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '</a></p>';
	echo '<style>.holo-dash{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.holo-dash-btn{display:flex;align-items:center;gap:10px;min-height:64px;padding:0 16px;background:#192A33;color:#fff;font-size:15px;font-weight:600;text-decoration:none;border-radius:4px}.holo-dash-btn:hover,.holo-dash-btn:focus{background:#D4AA63;color:#192A33}.holo-dash-btn .dashicons{font-size:22px;width:22px;height:22px}#holo_surf_accueil .inside{padding-bottom:16px}</style>';
}

/**
 * Menus inutiles masqués pour Paul.
 */
function holo_surf_menus_paul() {
	remove_menu_page( 'edit-comments.php' );
	if ( ! holo_surf_est_paul() ) {
		return;
	}
	foreach ( array( 'tools.php', 'rank-math', 'updraftplus', 'options-general.php', 'themes.php', 'wpseo_dashboard' ) as $m ) {
		remove_menu_page( $m );
	}
}
add_action( 'admin_menu', 'holo_surf_menus_paul', 999 );

/**
 * Page d'aide.
 */
function holo_surf_menu_aide() {
	add_submenu_page( 'holo-surf-reglages', 'Aide', 'Aide', 'edit_posts', 'holo-surf-aide', 'holo_surf_page_aide' );
}
add_action( 'admin_menu', 'holo_surf_menu_aide', 20 );

function holo_surf_page_aide() {
	$tel = 'Koino : contact via agence-koino.com';
	?>
	<div class="wrap" style="max-width:760px">
	<h1>Aide</h1>
	<h2>Écrire un article</h2>
	<ol>
		<li>Cliquez sur « Écrire un article » depuis le tableau de bord.</li>
		<li>Donnez un titre qui contient le lieu et le sujet (par exemple « Plage des Estagnots : vagues, marée, accès et niveau »).</li>
		<li>Écrivez le texte en paragraphes courts. Pour un intertitre, tapez « / » puis « Titre », niveau H2. Le sommaire de l'article se construit avec les intertitres H2 qui ont une ancre (réglage « Avancé » du bloc Titre).</li>
		<li>Dans la colonne de droite : choisissez une catégorie, ajoutez une image mise en avant (avec un texte alternatif qui décrit la photo) et un extrait de deux lignes.</li>
		<li>Cliquez sur « Publier ». L'article apparaît sur le blog et dans les encarts « Sur le blog » des pages.</li>
	</ol>
	<h2>Changer un prix</h2>
	<p>Menu « Réglages Holo Surf », section des cours ou de la location. Le nouveau prix s'affiche partout : tableaux, textes des pages, accueil et données lues par Google.</p>
	<h2>Les demandes de réservation</h2>
	<p>Chaque message envoyé depuis le site arrive par e-mail et reste enregistré dans « Demandes ». Répondez directement depuis votre messagerie.</p>
	<h2>Modifier un texte d'une page</h2>
	<p>Menu « Pages », ouvrez la page, cliquez dans le texte et modifiez-le. Les éléments entre crochets, comme <code>[holo_prix k="collectif_bs_1"]</code> ou <code>[holo_tel]</code>, affichent un prix ou une coordonnée des réglages : laissez-les en place.</p>
	<h2>Besoin d'aide ?</h2>
	<p><?php echo esc_html( $tel ); ?>.</p>
	</div>
	<?php
}

/**
 * Barre d'administration allégée.
 */
function holo_surf_admin_bar( $bar ) {
	$bar->remove_node( 'comments' );
	if ( holo_surf_est_paul() ) {
		$bar->remove_node( 'wp-logo' );
		$bar->remove_node( 'rank-math' );
	}
}
add_action( 'admin_bar_menu', 'holo_surf_admin_bar', 999 );

/**
 * Commentaires désactivés partout.
 */
function holo_surf_sans_commentaires() {
	foreach ( get_post_types() as $t ) {
		if ( post_type_supports( $t, 'comments' ) ) {
			remove_post_type_support( $t, 'comments' );
			remove_post_type_support( $t, 'trackbacks' );
		}
	}
}
add_action( 'init', 'holo_surf_sans_commentaires', 100 );
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
add_filter( 'comments_array', '__return_empty_array', 10 );
add_filter( 'feed_links_show_comments_feed', '__return_false' );
add_action(
	'admin_init',
	function () {
		global $pagenow;
		if ( 'edit-comments.php' === $pagenow || 'options-discussion.php' === $pagenow && holo_surf_est_paul() ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
		remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
	}
);
add_filter(
	'xmlrpc_methods',
	function ( $m ) {
		unset( $m['pingback.ping'], $m['pingback.extensions.getPingbacks'] );
		return $m;
	}
);

/**
 * Durcissement : XML-RPC coupé et éditeur de fichiers désactivé.
 */
add_filter( 'xmlrpc_enabled', '__return_false' );
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}
