<?php
/**
 * Codes courts alimentés par les réglages : prix, coordonnées, tableaux de tarifs.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Attributs class/style transmis à un lien.
 */
function holo_surf_attrs( $a ) {
	$out = '';
	foreach ( array( 'class', 'style' ) as $k ) {
		if ( ! empty( $a[ $k ] ) ) {
			$out .= ' ' . $k . '="' . esc_attr( $a[ $k ] ) . '"';
		}
	}
	return $out;
}

add_shortcode(
	'holo_prix',
	function ( $a ) {
		$a = shortcode_atts( array( 'k' => '' ), $a );
		return esc_html( holo_surf_prix_format( holo_surf_reglage( $a['k'] ) ) );
	}
);

add_shortcode(
	'holo_info',
	function ( $a ) {
		$a = shortcode_atts( array( 'k' => '' ), $a );
		$allowed = array( 'telephone', 'email', 'rue', 'code_postal', 'ville', 'langues', 'annee_tarifs' );
		return in_array( $a['k'], $allowed, true ) ? esc_html( holo_surf_reglage( $a['k'] ) ) : '';
	}
);

add_shortcode(
	'holo_tel',
	function ( $a ) {
		$a = shortcode_atts( array( 'class' => '', 'style' => '' ), $a );
		return '<a href="tel:' . esc_attr( holo_surf_reglage( 'telephone_intl' ) ) . '"' . holo_surf_attrs( $a ) . '>' . esc_html( holo_surf_reglage( 'telephone' ) ) . '</a>';
	}
);

add_shortcode(
	'holo_email',
	function ( $a ) {
		$a = shortcode_atts( array( 'class' => '', 'style' => '' ), $a );
		$e = holo_surf_reglage( 'email' );
		return '<a href="mailto:' . esc_attr( $e ) . '"' . holo_surf_attrs( $a ) . '>' . esc_html( $e ) . '</a>';
	}
);

add_shortcode(
	'holo_adresse',
	function ( $a ) {
		$a   = shortcode_atts( array( 'br' => '' ), $a );
		$sep = $a['br'] ? '<br>' : ', ';
		return esc_html( holo_surf_reglage( 'rue' ) ) . $sep . esc_html( trim( holo_surf_reglage( 'code_postal' ) . ' ' . holo_surf_reglage( 'ville' ) ) );
	}
);

add_shortcode(
	'holo_lien_avis',
	function () {
		return esc_url( holo_surf_reglage( 'avis' ) );
	}
);

/**
 * Coordonnées de la page Réserver.
 */
add_shortcode(
	'holo_coordonnees',
	function () {
		$tel = '<a href="tel:' . esc_attr( holo_surf_reglage( 'telephone_intl' ) ) . '">' . esc_html( holo_surf_reglage( 'telephone' ) ) . '</a>';
		$e   = holo_surf_reglage( 'email' );
		return '<dl class="info">
<div><dt>Téléphone et WhatsApp</dt><dd>' . $tel . '</dd></div>
<div><dt>E-mail</dt><dd><a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a></dd></div>
<div><dt>Adresse</dt><dd>' . esc_html( holo_surf_reglage( 'rue' ) ) . '<br>' . esc_html( trim( holo_surf_reglage( 'code_postal' ) . ' ' . holo_surf_reglage( 'ville' ) ) ) . '</dd></div>
<div><dt>Lieu des cours</dt><dd>Le plus souvent au Santocha, à Capbreton, selon les conditions et votre niveau.</dd></div>
<div><dt>Langues</dt><dd>' . esc_html( holo_surf_reglage( 'langues' ) ) . '</dd></div>
</dl>';
	}
);

/**
 * Tableau de prix (maquette : en-têtes sable, cases crème).
 */
function holo_surf_table( $caption, $label, $heads, $prices, $last_suffix = '' ) {
	$n    = count( $heads ) + 1;
	$out  = '<table class="tt" style="--n: ' . (int) $n . '">' . "\n" . '<caption>' . esc_html( $caption ) . '</caption>' . "\n<tbody>\n";
	$out .= '<tr><th scope="row">' . esc_html( $label ) . '</th>';
	foreach ( $heads as $h ) {
		$out .= '<td>' . esc_html( $h ) . '</td>';
	}
	$out .= "</tr>\n" . '<tr><th scope="row">Tarifs</th>';
	$last = count( $prices ) - 1;
	foreach ( $prices as $i => $p ) {
		if ( $i === $last && $last_suffix ) {
			$out .= '<td style="font-size: 22px">' . esc_html( holo_surf_prix_format( $p ) . $last_suffix ) . '</td>';
		} else {
			$out .= '<td>' . esc_html( holo_surf_prix_format( $p ) ) . '</td>';
		}
	}
	return $out . "</tr>\n</tbody>\n</table>";
}

add_shortcode(
	'holo_tarifs',
	function ( $a ) {
		$a = shortcode_atts( array( 'type' => 'collectif' ), $a );
		$r = 'holo_surf_reglage';
		switch ( $a['type'] ) {
			case 'collectif':
				$cours = array( '1', '2', '3', '4', '5', '6 et +' );
				$bs    = array();
				$hs    = array();
				for ( $i = 1; $i <= 6; $i++ ) {
					$bs[] = $r( 'collectif_bs_' . $i );
					$hs[] = $r( 'collectif_hs_' . $i );
				}
				$cur = holo_surf_saison_courante();
				$out = '<div class="hs-saisons">' . "\n" . '<div role="group" aria-label="Choisir la saison" style="display: flex; gap: 3px; margin-bottom: 3px">' . "\n";
				$out .= '<button type="button" class="tab" aria-pressed="' . ( 'bs' === $cur ? 'true' : 'false' ) . '" aria-controls="hs-tarifs-bs" style="flex: 1 1 0">Basse saison</button>' . "\n";
				$out .= '<button type="button" class="tab" aria-pressed="' . ( 'hs' === $cur ? 'true' : 'false' ) . '" aria-controls="hs-tarifs-hs" style="flex: 1 1 0">Juillet et août</button>' . "\n</div>\n";
				$out .= '<div class="tbox swap" id="hs-tarifs-bs"' . ( 'bs' === $cur ? '' : ' hidden' ) . '>' . holo_surf_table( 'Tarifs cours collectifs basse saison (hors juillet-août)', 'Nombre de cours', $cours, $bs, ' / cours' ) . "</div>\n";
				$out .= '<div class="tbox swap" id="hs-tarifs-hs"' . ( 'hs' === $cur ? '' : ' hidden' ) . '>' . holo_surf_table( 'Tarifs cours collectifs haute saison (juillet-août)', 'Nombre de cours', $cours, $hs, ' / cours' ) . "</div>\n</div>";
				return $out;
			case 'particulier':
			case 'coaching':
				$p = array();
				for ( $i = 1; $i <= 4; $i++ ) {
					$p[] = $r( $a['type'] . '_' . $i );
				}
				$cap = 'particulier' === $a['type'] ? 'Tarifs cours particulier' : 'Tarifs coaching vidéo';
				return '<div class="tbox">' . holo_surf_table( $cap, 'Nombre de personnes', array( '1', '2', '3', '4' ), $p ) . '</div>';
			case 'mousse':
			case 'hybride':
			case 'combinaison':
				$caps = array(
					'mousse'      => 'Location planche mousse',
					'hybride'     => 'Location planche hybride',
					'combinaison' => 'Location combinaison',
				);
				$p    = array();
				foreach ( array_keys( holo_surf_durees_location() ) as $k ) {
					$p[] = $r( $a['type'] . '_' . $k );
				}
				return '<div class="tbox">' . holo_surf_table( $caps[ $a['type'] ], 'Durée', array_values( holo_surf_durees_location() ), $p ) . '</div>';
		}
		return '';
	}
);
