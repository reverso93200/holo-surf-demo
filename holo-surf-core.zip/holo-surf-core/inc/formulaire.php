<?php
/**
 * Formulaire de réservation : envoi par e-mail, enregistrement dans « Demandes », anti-spam sans service externe.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Type de contenu privé pour les demandes reçues.
 */
function holo_surf_cpt_demandes() {
	register_post_type(
		'holo_demande',
		array(
			'labels'          => array(
				'name'               => 'Demandes',
				'singular_name'      => 'Demande',
				'menu_name'          => 'Demandes',
				'all_items'          => 'Toutes les demandes',
				'edit_item'          => 'Demande',
				'search_items'       => 'Chercher une demande',
				'not_found'          => 'Aucune demande pour le moment.',
				'not_found_in_trash' => 'Aucune demande dans la corbeille.',
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'menu_position'   => 4,
			'menu_icon'       => 'dashicons-email-alt',
			'supports'        => array( 'title', 'editor' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
			'show_in_rest'    => false,
		)
	);
}
add_action( 'init', 'holo_surf_cpt_demandes' );

/**
 * Listes de choix (textes de la maquette).
 */
function holo_surf_choix( $quoi, $variante = 'page' ) {
	if ( 'formule' === $quoi ) {
		$f = array( 'Cours collectifs', 'Cours particuliers', 'Coaching vidéo', 'Location de matériel', 'Sur mesure (groupe, EVG, EVJF, entreprise)' );
		if ( 'page' === $variante ) {
			$f[] = 'Autre question';
		}
		return $f;
	}
	if ( 'nombre' === $quoi ) {
		return array( '1', '2', '3', '4', '5 à 8', 'Plus de 8' );
	}
	return array( 'Jamais surfé', 'Débutant', 'Je me lève sur la planche', 'Je prends des vagues vertes', 'Confirmé' );
}

/**
 * Jeton horodaté signé : un envoi trop rapide trahit un robot.
 */
function holo_surf_jeton() {
	$t = time();
	return $t . '.' . substr( hash_hmac( 'sha256', (string) $t, wp_salt( 'nonce' ) ), 0, 16 );
}

function holo_surf_jeton_valide( $j ) {
	$p = explode( '.', (string) $j );
	if ( 2 !== count( $p ) ) {
		return false;
	}
	$ok  = hash_equals( substr( hash_hmac( 'sha256', $p[0], wp_salt( 'nonce' ) ), 0, 16 ), $p[1] );
	$age = time() - (int) $p[0];
	return $ok && $age >= 5 && $age <= DAY_IN_SECONDS;
}

/**
 * Champ de saisie.
 */
function holo_surf_champ( $id, $name, $label, $type, $old, $extra = '' ) {
	$v = isset( $old[ $name ] ) ? $old[ $name ] : '';
	return '<label for="' . esc_attr( $id ) . '" class="lbl">' . esc_html( $label ) . '</label><input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="fld" type="' . esc_attr( $type ) . '"' . $extra . ( '' !== $v ? ' value="' . esc_attr( $v ) . '"' : '' ) . '>';
}

function holo_surf_select( $id, $name, $label, $options, $old ) {
	$v   = isset( $old[ $name ] ) ? $old[ $name ] : '';
	$out = '<label for="' . esc_attr( $id ) . '" class="lbl">' . esc_html( $label ) . '</label><select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="fld">';
	foreach ( $options as $o ) {
		$out .= '<option' . selected( $v, $o, false ) . '>' . esc_html( $o ) . '</option>';
	}
	return $out . '</select>';
}

/**
 * Affichage du formulaire : [holo_reservation] (page Réserver) ou [holo_reservation variante="accueil"].
 */
function holo_surf_sc_reservation( $a ) {
	$a   = shortcode_atts( array( 'variante' => 'page' ), $a );
	$acc = 'accueil' === $a['variante'];
	$p   = $acc ? 'c-' : 'f-';
	$etat = isset( $_GET['demande'] ) ? sanitize_key( $_GET['demande'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$cle  = isset( $_GET['hsf'] ) ? sanitize_key( $_GET['hsf'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$old  = $cle ? get_transient( 'holo_form_' . $cle ) : array();
	$old  = is_array( $old ) ? $old : array();
	$self = remove_query_arg( array( 'demande', 'hsf' ) );

	$merci = '<div role="status" style="min-height: 420px; display: flex; flex-direction: column; justify-content: center; animation: up .7s cubic-bezier(.2,.7,.2,1) both">
<p style="margin: 0; font-family: \'Bebas Neue\', sans-serif; font-size: clamp(48px, 5vw, 72px); line-height: 0.92">À très vite dans les vagues !</p>
<p class="p" style="margin-top: 18px; max-width: 460px">Votre message est bien parti. Paul vous répond par e-mail pour caler votre session.</p>
<a href="' . esc_url( $self ) . '#reservation" class="lnk" style="margin-top: 26px; align-self: flex-start; font-size: 16.5px">Envoyer un autre message</a>
</div>';

	if ( 'ok' === $etat && ! $acc ) {
		return '<div id="reservation">' . $merci . '</div>';
	}
	$form_style = $acc ? 'flex: 1 1 480px; min-width: 0; background: #FFFFFF; padding: 40px; box-sizing: border-box; display: flex; flex-direction: column; gap: 18px' : 'display: flex; flex-direction: column; gap: 18px';
	if ( 'ok' === $etat && $acc ) {
		return '<div id="reservation" class="reveal cbox" style="' . esc_attr( $form_style ) . '">' . $merci . '</div>';
	}
	$row = '<div style="display: flex; flex-wrap: wrap; gap: 18px">';
	$col = '<div style="flex: 1 1 200px; min-width: 0">';

	$out  = '<form id="reservation"' . ( $acc ? ' class="reveal cbox"' : '' ) . ' aria-label="' . ( $acc ? 'Formulaire de contact' : 'Formulaire de réservation' ) . '" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="' . esc_attr( $form_style ) . '">' . "\n";
	if ( 'erreur' === $etat ) {
		$out .= '<p class="hs-form-msg" role="alert">Merci d\'indiquer votre prénom et une adresse e-mail valide, puis de renvoyer votre demande.</p>' . "\n";
	} elseif ( 'echec' === $etat ) {
		$out .= '<p class="hs-form-msg" role="alert">Le message n\'a pas pu partir. Écrivez directement à ' . esc_html( holo_surf_reglage( 'email' ) ) . ' ou appelez le ' . esc_html( holo_surf_reglage( 'telephone' ) ) . '.</p>' . "\n";
	}
	$out .= '<input type="hidden" name="action" value="holo_reservation"><input type="hidden" name="hs_t" value="' . esc_attr( holo_surf_jeton() ) . '"><input type="hidden" name="hs_retour" value="' . esc_url( $self ) . '"><input type="hidden" name="hs_variante" value="' . esc_attr( $a['variante'] ) . '">' . "\n";
	$out .= '<div class="hs-hp" aria-hidden="true"><label for="' . $p . 'site">Site web</label><input id="' . $p . 'site" name="site_web" type="text" tabindex="-1" autocomplete="off"></div>' . "\n";
	$out .= $row . $col . holo_surf_champ( $p . 'prenom', 'prenom', 'Prénom', 'text', $old, ' autocomplete="given-name" required' ) . '</div>' . $col . holo_surf_champ( $p . 'nom', 'nom', 'Nom de famille', 'text', $old, ' autocomplete="family-name"' ) . "</div>\n</div>\n";
	$out .= $row . $col . holo_surf_champ( $p . 'mail', 'email', 'E-mail', 'email', $old, ' autocomplete="email" required' ) . '</div>' . $col . holo_surf_champ( $p . 'tel', 'telephone', 'Téléphone', 'tel', $old, ' autocomplete="tel"' ) . "</div>\n</div>\n";
	if ( $acc ) {
		$out .= $row . $col . holo_surf_select( $p . 'formule', 'formule', 'Formule', holo_surf_choix( 'formule', 'accueil' ), $old ) . '</div>' . $col . holo_surf_champ( $p . 'date', 'date', 'Date souhaitée', 'date', $old ) . "</div>\n</div>\n";
		$out .= $row . $col . holo_surf_select( $p . 'nb', 'nombre', 'Nombre de surfeurs', holo_surf_choix( 'nombre' ), $old ) . '</div>' . $col . holo_surf_select( $p . 'niv', 'niveau', 'Niveau', holo_surf_choix( 'niveau' ), $old ) . "</div>\n</div>\n";
		$rows = 5;
	} else {
		$out .= '<div>' . holo_surf_select( $p . 'formule', 'formule', 'Je suis intéressé par', holo_surf_choix( 'formule', 'page' ), $old ) . "</div>\n";
		$out .= $row . $col . holo_surf_champ( $p . 'date', 'date', 'Date souhaitée', 'date', $old ) . '</div>' . $col . holo_surf_select( $p . 'nb', 'nombre', 'Nombre de surfeurs', holo_surf_choix( 'nombre' ), $old ) . "</div>\n</div>\n";
		$out .= '<div>' . holo_surf_select( $p . 'niv', 'niveau', 'Niveau', holo_surf_choix( 'niveau' ), $old ) . "</div>\n";
		$rows = 6;
	}
	$msg   = isset( $old['message'] ) ? $old['message'] : '';
	$out  .= '<div><label for="' . $p . 'msg" class="lbl">Message</label><textarea id="' . $p . 'msg" name="message" class="fld" rows="' . $rows . '" placeholder="Vos dates, le nombre de surfeurs, leur âge et leur niveau" style="padding: 12px 14px; line-height: 1.5; resize: vertical">' . esc_textarea( $msg ) . '</textarea></div>' . "\n";
	$legal = function_exists( 'hs_url' ) ? hs_url( 'Legal' ) . '#confidentialite' : home_url( '/mentions-legales#confidentialite' );
	$out  .= '<p style="margin: 0; font-size: 14px; line-height: 1.55; color: #55636A">Vos informations servent uniquement à répondre à votre demande. <a href="' . esc_url( $legal ) . '" style="color: #192A33">Politique de confidentialité</a></p>' . "\n";
	$btn   = $acc ? 'min-height: 58px; font-size: 23px' : 'min-height: 58px; font-size: 23px; align-self: flex-start; padding: 0 clamp(20px, 5vw, 40px)';
	$out  .= '<button type="submit" class="btn b-sand" style="' . $btn . '">Envoyer ma demande</button>' . "\n</form>";
	return $out;
}
add_shortcode( 'holo_reservation', 'holo_surf_sc_reservation' );

/**
 * Traitement de l'envoi.
 */
function holo_surf_traiter_reservation() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- formulaire public protégé par jeton signé et piège à robots.
	$retour = isset( $_POST['hs_retour'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['hs_retour'] ) ), home_url( '/' ) ) : home_url( '/' );
	$back   = function ( $etat, $extra = array() ) use ( $retour ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'demande' => $etat ), $extra ), $retour ) . '#reservation', 303 );
		exit;
	};
	// Robot : champ piège rempli ou envoi instantané. On répond comme si tout allait bien.
	if ( ! empty( $_POST['site_web'] ) || ! holo_surf_jeton_valide( isset( $_POST['hs_t'] ) ? sanitize_text_field( wp_unslash( $_POST['hs_t'] ) ) : '' ) ) {
		$back( 'ok' );
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$lim = 'holo_rl_' . md5( $ip );
	$n   = (int) get_transient( $lim );
	if ( $n >= 5 ) {
		$back( 'ok' );
	}
	set_transient( $lim, $n + 1, 10 * MINUTE_IN_SECONDS );

	$f = array();
	foreach ( array( 'prenom', 'nom', 'telephone', 'formule', 'date', 'nombre', 'niveau' ) as $k ) {
		$f[ $k ] = isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, 200 ) : '';
	}
	$f['email']   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$f['message'] = isset( $_POST['message'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ) ), 0, 5000 ) : '';
	// phpcs:enable

	if ( '' === $f['prenom'] || ! is_email( $f['email'] ) ) {
		$cle = wp_generate_password( 12, false );
		set_transient( 'holo_form_' . strtolower( $cle ), $f, 15 * MINUTE_IN_SECONDS );
		$back( 'erreur', array( 'hsf' => strtolower( $cle ) ) );
	}

	$date_txt = $f['date'] ? wp_date( 'd/m/Y', strtotime( $f['date'] ) ) : 'non précisée';
	$lignes   = array(
		'Prénom : ' . $f['prenom'],
		'Nom : ' . $f['nom'],
		'E-mail : ' . $f['email'],
		'Téléphone : ' . $f['telephone'],
		'Formule : ' . $f['formule'],
		'Date souhaitée : ' . $date_txt,
		'Nombre de surfeurs : ' . $f['nombre'],
		'Niveau : ' . $f['niveau'],
		'',
		'Message :',
		$f['message'],
	);
	$corps = implode( "\n", $lignes );
	$titre = trim( $f['prenom'] . ' ' . $f['nom'] ) . ', ' . $f['formule'] . ', ' . $date_txt;

	$id = wp_insert_post(
		array(
			'post_type'    => 'holo_demande',
			'post_status'  => 'private',
			'post_title'   => $titre,
			'post_content' => $corps,
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		foreach ( $f as $k => $v ) {
			update_post_meta( $id, '_hs_' . $k, $v );
		}
	}

	$to      = holo_surf_reglage( 'email_reception' );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . trim( $f['prenom'] . ' ' . $f['nom'] ) . ' <' . $f['email'] . '>' );
	$sent    = wp_mail( $to, 'Nouvelle demande de réservation : ' . trim( $f['prenom'] . ' ' . $f['nom'] ), $corps . "\n\nDemande envoyée depuis " . home_url( '/' ), $headers );
	if ( $id ) {
		update_post_meta( $id, '_hs_mail_envoye', $sent ? 'oui' : 'non' );
	}
	holo_surf_reponse_automatique( $f, $lignes );
	$back( ( $sent || $id ) ? 'ok' : 'echec' );
}
add_action( 'admin_post_nopriv_holo_reservation', 'holo_surf_traiter_reservation' );
add_action( 'admin_post_holo_reservation', 'holo_surf_traiter_reservation' );

/**
 * Colonnes de la liste des demandes.
 */
add_filter(
	'manage_holo_demande_posts_columns',
	function ( $c ) {
		return array(
			'cb'       => $c['cb'],
			'title'    => 'Demande',
			'hs_email' => 'E-mail',
			'hs_tel'   => 'Téléphone',
			'hs_mail'  => 'E-mail envoyé',
			'date'     => 'Reçue le',
		);
	}
);
add_action(
	'manage_holo_demande_posts_custom_column',
	function ( $col, $id ) {
		if ( 'hs_email' === $col ) {
			$e = get_post_meta( $id, '_hs_email', true );
			echo '<a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a>';
		} elseif ( 'hs_tel' === $col ) {
			echo esc_html( get_post_meta( $id, '_hs_telephone', true ) );
		} elseif ( 'hs_mail' === $col ) {
			echo esc_html( get_post_meta( $id, '_hs_mail_envoye', true ) );
		}
	},
	10,
	2
);

/**
 * Réponse automatique « Demande bien reçue » envoyée au visiteur (jamais aux robots : le piège arrête l'envoi plus haut).
 */
function holo_surf_reponse_automatique( $f, $lignes ) {
	if ( '1' !== (string) holo_surf_reglage( 'reponse_active' ) || ! is_email( $f['email'] ) ) {
		return false;
	}
	$recap = implode( "\n", $lignes );
	$vars  = array(
		'{prenom}'        => $f['prenom'],
		'{recapitulatif}' => $recap,
		'{telephone}'     => holo_surf_reglage( 'telephone' ),
		'{email}'         => holo_surf_reglage( 'email' ),
		'{adresse}'       => holo_surf_reglage( 'rue' ) . ', ' . trim( holo_surf_reglage( 'code_postal' ) . ' ' . holo_surf_reglage( 'ville' ) ),
	);
	$texte   = strtr( (string) holo_surf_reglage( 'reponse_texte' ), $vars );
	$sujet   = (string) holo_surf_reglage( 'reponse_sujet' );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: Holo Surf Capbreton <' . holo_surf_reglage( 'email' ) . '>' );
	return wp_mail( $f['email'], $sujet, $texte, $headers );
}

/**
 * Suppression automatique des demandes plus anciennes que la durée de conservation.
 */
function holo_surf_purger_demandes() {
	$mois = max( 1, (int) holo_surf_reglage( 'conservation_mois' ) );
	$old  = get_posts(
		array(
			'post_type'      => 'holo_demande',
			'post_status'    => 'any',
			'posts_per_page' => 200,
			'fields'         => 'ids',
			'date_query'     => array( array( 'before' => $mois . ' months ago' ) ),
		)
	);
	foreach ( $old as $id ) {
		wp_delete_post( $id, true );
	}
}
add_action( 'holo_surf_purge', 'holo_surf_purger_demandes' );
add_action(
	'init',
	function () {
		if ( ! wp_next_scheduled( 'holo_surf_purge' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'holo_surf_purge' );
		}
	}
);

/**
 * Nombre de demandes reçues ce mois-ci (tableau de bord de Paul).
 */
function holo_surf_demandes_du_mois() {
	$q = new WP_Query(
		array(
			'post_type'      => 'holo_demande',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'date_query'     => array( array( 'after' => wp_date( 'Y-m-01 00:00:00' ), 'inclusive' => true ) ),
		)
	);
	return (int) $q->found_posts;
}
