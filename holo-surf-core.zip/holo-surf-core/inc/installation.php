<?php
/**
 * Installation du site : médias, pages, article modèle, menus et réglages de lecture.
 * Les pages déjà présentes ne sont jamais écrasées.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

function holo_surf_activation() {
	holo_surf_installer();
}

/**
 * Données d'installation (générées depuis la maquette).
 */
function holo_surf_contenu() {
	$f = HOLO_SURF_CORE_DIR . 'content/contenu.json';
	return is_readable( $f ) ? json_decode( file_get_contents( $f ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

/**
 * Importe une image du dossier content/img dans la médiathèque.
 */
function holo_surf_importer_image( $file, $alt, $title ) {
	$src = HOLO_SURF_CORE_DIR . 'content/img/' . $file;
	if ( ! is_readable( $src ) ) {
		// Les photos sont livrées avec le thème Holo Surf.
		$src = get_theme_root() . '/holo-surf/assets/img/media/' . $file;
	}
	if ( ! is_readable( $src ) ) {
		return 0;
	}
	$up = wp_upload_bits( $file, null, file_get_contents( $src ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! empty( $up['error'] ) ) {
		return 0;
	}
	$type = wp_check_filetype( $up['file'] );
	$id   = wp_insert_attachment(
		array(
			'post_mime_type' => $type['type'],
			'post_title'     => $title,
			'post_status'    => 'inherit',
		),
		$up['file']
	);
	if ( ! $id || is_wp_error( $id ) ) {
		return 0;
	}
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $up['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return $id;
}

/**
 * Remplace les marqueurs d'adresse et d'image du contenu.
 */
function holo_surf_marqueurs( $html, $medias, $paths ) {
	$html = preg_replace_callback(
		'/\{\{url:(\w+)\}\}/',
		function ( $m ) use ( $paths ) {
			$p = isset( $paths[ $m[1] ] ) ? $paths[ $m[1] ] : '/';
			return '/' === $p ? home_url( '/' ) : home_url( $p );
		},
		$html
	);
	$html = preg_replace_callback(
		'/\{\{blog:([a-z0-9-]+)\}\}/',
		function ( $m ) {
			return home_url( '/blog/' . $m[1] );
		},
		$html
	);
	$html = preg_replace_callback(
		'/\{\{imgid:([0-9a-f]{32})\}\}/',
		function ( $m ) use ( $medias ) {
			return isset( $medias[ $m[1] ] ) ? (string) (int) $medias[ $m[1] ] : '0';
		},
		$html
	);
	return preg_replace_callback(
		'/\{\{img:([0-9a-f]{32})\}\}/',
		function ( $m ) use ( $medias ) {
			return isset( $medias[ $m[1] ] ) ? wp_get_attachment_url( $medias[ $m[1] ] ) : '';
		},
		$html
	);
}

/**
 * Routine d'installation (relançable : ne recrée que ce qui manque).
 */
function holo_surf_installer() {
	$data = holo_surf_contenu();
	if ( ! $data ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	kses_remove_filters();

	// Réglages généraux.
	update_option( 'blogname', 'Holo Surf Capbreton' );
	update_option( 'blogdescription', 'École de surf à Capbreton' );
	update_option( 'timezone_string', 'Europe/Paris' );
	update_option( 'date_format', 'j F Y' );
	update_option( 'default_comment_status', 'closed' );
	update_option( 'default_ping_status', 'closed' );
	update_option( 'default_pingback_flag', 0 );
	if ( false === get_option( HOLO_SURF_OPTION ) ) {
		add_option( HOLO_SURF_OPTION, array() );
	}
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/blog/%postname%' );

	// Médias.
	$medias = get_option( 'holo_surf_medias', array() );
	$medias = is_array( $medias ) ? $medias : array();
	foreach ( $data['images'] as $blob => $img ) {
		if ( ! empty( $medias[ $blob ] ) && get_post( $medias[ $blob ] ) ) {
			continue;
		}
		$id = holo_surf_importer_image( $img['file'], $img['alt'], $img['title'] );
		if ( $id ) {
			$medias[ $blob ] = $id;
			update_post_meta( $id, '_holo_blob', $blob );
		}
	}
	update_option( 'holo_surf_medias', $medias );
	if ( ! empty( $medias['038cdb79f92c60fc87e4bde1fc2e1bf6'] ) ) {
		update_option( 'holo_surf_og_image', $medias['038cdb79f92c60fc87e4bde1fc2e1bf6'] );
	}

	// Pages.
	$paths = $data['paths'];
	$ids   = get_option( 'holo_surf_pages', array() );
	$ids   = is_array( $ids ) ? $ids : array();
	foreach ( $data['pages'] as $key => $p ) {
		$existing = get_page_by_path( $p['slug'], OBJECT, 'page' );
		if ( $existing ) {
			$ids[ $key ] = $existing->ID;
			continue;
		}
		$id = wp_insert_post(
			wp_slash(
				array(
					'post_type'      => 'page',
					'post_status'    => 'publish',
					'post_title'     => $p['title'],
					'post_name'      => $p['slug'],
					'post_content'   => holo_surf_marqueurs( $p['content'], $medias, $paths ),
					'menu_order'     => $p['order'],
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				)
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			$ids[ $key ] = $id;
			holo_surf_meta_seo( $id, $p );
		}
	}
	update_option( 'holo_surf_pages', $ids );
	if ( ! empty( $ids['Main'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['Main'] );
	}
	if ( ! empty( $ids['Blog'] ) ) {
		update_option( 'page_for_posts', $ids['Blog'] );
	}
	if ( ! empty( $ids['Legal'] ) ) {
		update_option( 'wp_page_for_privacy_policy', $ids['Legal'] );
	}

	// Catégories du blog.
	$cats = array();
	foreach ( $data['categories'] as $slug => $name ) {
		$t = get_category_by_slug( $slug );
		if ( ! $t ) {
			$r = wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
			$cats[ $slug ] = is_wp_error( $r ) ? 0 : $r['term_id'];
		} else {
			$cats[ $slug ] = $t->term_id;
		}
	}
	$unc = get_category_by_slug( 'uncategorized' );
	if ( ! $unc ) {
		$unc = get_category_by_slug( 'non-classe' );
	}

	// Articles du blog.
	$articles = isset( $data['articles'] ) ? $data['articles'] : array( $data['article'] );
	foreach ( $articles as $a ) {
		if ( get_page_by_path( $a['slug'], OBJECT, 'post' ) ) {
			continue;
		}
		$thumb = 0;
		if ( ! empty( $a['thumb_blob'] ) && ! empty( $medias[ $a['thumb_blob'] ] ) ) {
			$thumb = (int) $medias[ $a['thumb_blob'] ];
		} elseif ( ! empty( $a['thumb'] ) ) {
			$thumb = holo_surf_importer_image( $a['thumb']['file'], $a['thumb']['alt'], $a['thumb']['title'] );
		}
		$pid = wp_insert_post(
			wp_slash(
				array(
					'post_type'      => 'post',
					'post_status'    => $a['status'],
					'post_title'     => $a['title'],
					'post_name'      => $a['slug'],
					'post_excerpt'   => $a['excerpt'],
					'post_date'      => $a['date'],
					'post_content'   => holo_surf_marqueurs( $a['content'], $medias, $paths ),
					'post_category'  => array( $cats[ $a['category'] ] ),
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				)
			)
		);
		if ( $pid && ! is_wp_error( $pid ) ) {
			if ( $thumb ) {
				set_post_thumbnail( $pid, $thumb );
			}
			holo_surf_meta_seo( $pid, $a );
			if ( ! empty( $a['schema'] ) ) {
				update_post_meta( $pid, '_holo_schema_extra', wp_slash( wp_json_encode( $a['schema'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			}
			if ( ! empty( $a['minutes'] ) ) {
				update_post_meta( $pid, '_holo_temps_lecture', (int) $a['minutes'] );
			}
		}
	}
	// L'article d'exemple de WordPress n'a rien à faire sur le site.
	$hello = get_page_by_path( 'hello-world', OBJECT, 'post' );
	if ( ! $hello ) {
		$hello = get_page_by_path( 'bonjour-tout-le-monde', OBJECT, 'post' );
	}
	if ( $hello ) {
		wp_delete_post( $hello->ID, true );
	}
	$sample = get_page_by_path( 'sample-page', OBJECT, 'page' );
	if ( ! $sample ) {
		$sample = get_page_by_path( 'page-d-exemple', OBJECT, 'page' );
	}
	if ( $sample ) {
		wp_delete_post( $sample->ID, true );
	}

	holo_surf_creer_menus( $ids, $data['menus'], $paths );
	holo_surf_reglages_koko();
	kses_init_filters();
	update_option( 'holo_surf_installe', HOLO_SURF_CORE_VERSION );
	flush_rewrite_rules( false );
	update_option( 'holo_surf_flush', 1 );
}

/**
 * Titre, description et fil d'Ariane pour Rank Math et pour l'affichage de secours.
 */
function holo_surf_meta_seo( $id, $p ) {
	if ( ! empty( $p['seo_title'] ) ) {
		update_post_meta( $id, '_holo_title', $p['seo_title'] );
		update_post_meta( $id, 'rank_math_title', $p['seo_title'] );
	}
	if ( ! empty( $p['description'] ) ) {
		update_post_meta( $id, '_holo_description', $p['description'] );
		update_post_meta( $id, 'rank_math_description', $p['description'] );
	}
	if ( ! empty( $p['keyword'] ) ) {
		update_post_meta( $id, 'rank_math_focus_keyword', $p['keyword'] );
	}
	if ( ! empty( $p['crumb'] ) ) {
		update_post_meta( $id, '_holo_fil_ariane', $p['crumb'] );
	}
	if ( ! empty( $p['noindex'] ) ) {
		update_post_meta( $id, 'rank_math_robots', array( 'noindex' ) );
	}
}

/**
 * Menus du thème (Apparence > Menus).
 */
function holo_surf_creer_menus( $ids, $menus, $paths ) {
	$locations = array();
	foreach ( $menus as $loc => $m ) {
		$menu = wp_get_nav_menu_object( $m['name'] );
		if ( $menu ) {
			$locations[ $loc ] = $menu->term_id;
			continue;
		}
		$mid = wp_create_nav_menu( $m['name'] );
		if ( is_wp_error( $mid ) ) {
			continue;
		}
		foreach ( $m['items'] as $i => $it ) {
			list( $label, $key, $anchor ) = $it;
			if ( '' === $anchor && ! empty( $ids[ $key ] ) && 'Main' !== $key ) {
				wp_update_nav_menu_item(
					$mid,
					0,
					array(
						'menu-item-title'     => $label,
						'menu-item-object'    => 'page',
						'menu-item-object-id' => $ids[ $key ],
						'menu-item-type'      => 'post_type',
						'menu-item-status'    => 'publish',
						'menu-item-position'  => $i + 1,
					)
				);
			} else {
				$p = isset( $paths[ $key ] ) ? $paths[ $key ] : '/';
				wp_update_nav_menu_item(
					$mid,
					0,
					array(
						'menu-item-title'    => $label,
						'menu-item-url'      => ( '/' === $p ? home_url( '/' ) : home_url( $p ) ) . $anchor,
						'menu-item-type'     => 'custom',
						'menu-item-status'   => 'publish',
						'menu-item-position' => $i + 1,
					)
				);
			}
		}
		$locations[ $loc ] = $mid;
	}
	$mods                       = get_option( 'theme_mods_holo-surf', array() );
	$mods                       = is_array( $mods ) ? $mods : array();
	$mods['nav_menu_locations'] = array_merge( isset( $mods['nav_menu_locations'] ) ? (array) $mods['nav_menu_locations'] : array(), $locations );
	update_option( 'theme_mods_holo-surf', $mods );
}

/**
 * Règles de réécriture régénérées au chargement qui suit l'installation.
 */
add_action(
	'init',
	function () {
		if ( get_option( 'holo_surf_flush' ) ) {
			delete_option( 'holo_surf_flush' );
			flush_rewrite_rules( false );
		}
	},
	99
);

/**
 * Relance manuelle (administrateur), depuis la page de réglages.
 */
add_action(
	'admin_post_holo_surf_installer',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Accès refusé.' );
		}
		check_admin_referer( 'holo_surf_installer' );
		holo_surf_installer();
		wp_safe_redirect( admin_url( 'admin.php?page=holo-surf-reglages&installe=1' ) );
		exit;
	}
);

/**
 * Koko Analytics : mesure sans cookie ni adresse IP, visites de l'équipe exclues, statistiques visibles par Paul.
 */
function holo_surf_reglages_koko() {
	$k = get_option( 'koko_analytics_settings', null );
	if ( ! is_array( $k ) || empty( $k['holo_surf'] ) ) {
		$k                       = is_array( $k ) ? $k : array();
		$k['tracking_method']    = 'none';
		$k['exclude_user_roles'] = array( 'administrator', 'editor' );
		$k['holo_surf']          = 1;
		update_option( 'koko_analytics_settings', $k, true );
	}
	$role = get_role( 'editor' );
	if ( $role && ! $role->has_cap( 'view_koko_analytics' ) ) {
		$role->add_cap( 'view_koko_analytics' );
	}
}
add_action(
	'activated_plugin',
	function ( $plugin ) {
		if ( 0 === strpos( $plugin, 'koko-analytics/' ) ) {
			holo_surf_reglages_koko();
		}
	}
);
