<?php
/**
 * Images : tailles responsives, WebP et AVIF automatiques à l'envoi, crédit photo,
 * objets ImageObject et images Open Graph 1200 × 630.
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Largeurs servies aux navigateurs (768 = taille « medium_large » de WordPress).
 */
function holo_surf_largeurs() {
	return array( 480, 768, 1080, 1440, 1920 );
}

add_action(
	'after_setup_theme',
	function () {
		foreach ( holo_surf_largeurs() as $w ) {
			if ( 768 !== $w ) {
				add_image_size( 'hs-' . $w, $w, 0, false );
			}
		}
	},
	20
);

/**
 * Les images envoyées en JPEG ou PNG sont déclinées en WebP.
 */
function holo_surf_format_sortie( $formats ) {
	$formats['image/jpeg'] = 'image/webp';
	$formats['image/png']  = 'image/webp';
	return $formats;
}
add_filter( 'image_editor_output_format', 'holo_surf_format_sortie' );

/**
 * Une copie AVIF de chaque taille est créée à l'envoi, si le serveur sait encoder l'AVIF.
 */
function holo_surf_creer_avif( $meta, $id ) {
	if ( defined( 'HOLO_SURF_IMPORT' ) || empty( $meta['file'] ) || ! wp_image_editor_supports( array( 'mime_type' => 'image/avif' ) ) ) {
		return $meta;
	}
	$up   = wp_get_upload_dir();
	$dir  = trailingslashit( $up['basedir'] ) . trailingslashit( dirname( $meta['file'] ) );
	$avif = array();
	$list = array( 'full' => basename( $meta['file'] ) );
	foreach ( (array) ( isset( $meta['sizes'] ) ? $meta['sizes'] : array() ) as $nom => $s ) {
		if ( 0 === strpos( $nom, 'hs-' ) || 'medium_large' === $nom ) {
			$list[ $nom ] = $s['file'];
		}
	}
	foreach ( $list as $nom => $fichier ) {
		$src = $dir . $fichier;
		$dst = preg_replace( '/\.\w+$/', '.avif', $src );
		$ed  = wp_get_image_editor( $src );
		if ( is_wp_error( $ed ) ) {
			continue;
		}
		$ed->set_quality( 55 );
		$r = $ed->save( $dst, 'image/avif' );
		if ( ! is_wp_error( $r ) ) {
			$avif[ $nom ] = basename( $dst );
		}
	}
	if ( $avif ) {
		update_post_meta( $id, '_holo_avif', $avif );
	}
	return $meta;
}
add_filter( 'wp_generate_attachment_metadata', 'holo_surf_creer_avif', 20, 2 );

/**
 * Suppression des copies AVIF et de l'image Open Graph avec l'image.
 */
add_action(
	'delete_attachment',
	function ( $id ) {
		$avif = get_post_meta( $id, '_holo_avif', true );
		$file = get_attached_file( $id );
		if ( is_array( $avif ) && $file ) {
			foreach ( $avif as $f ) {
				wp_delete_file( trailingslashit( dirname( $file ) ) . basename( $f ) );
			}
		}
	}
);

/**
 * Champ « Crédit photo » dans la médiathèque.
 */
add_filter(
	'attachment_fields_to_edit',
	function ( $fields, $post ) {
		$fields['holo_credit'] = array(
			'label' => 'Crédit photo',
			'input' => 'text',
			'value' => get_post_meta( $post->ID, '_holo_credit', true ),
			'helps' => 'Nom du photographe, repris dans les données structurées (par exemple Hugo Mouille).',
		);
		return $fields;
	},
	10,
	2
);
add_filter(
	'attachment_fields_to_save',
	function ( $post, $attachment ) {
		if ( isset( $attachment['holo_credit'] ) ) {
			update_post_meta( $post['ID'], '_holo_credit', sanitize_text_field( $attachment['holo_credit'] ) );
		}
		return $post;
	},
	10,
	2
);

/**
 * Pièce jointe d'une adresse d'image (taille réduite comprise).
 */
function holo_surf_id_image( $src ) {
	static $cache = array();
	if ( isset( $cache[ $src ] ) ) {
		return $cache[ $src ];
	}
	$id = attachment_url_to_postid( $src );
	if ( ! $id ) {
		$id = attachment_url_to_postid( preg_replace( '/-(\d+x\d+|\d+)(\.(?:webp|avif|jpe?g|png))$/i', '$2', $src ) );
	}
	$cache[ $src ] = (int) $id;
	return $cache[ $src ];
}

/**
 * ImageObject d'une pièce jointe, avec le crédit du photographe s'il est connu.
 */
function holo_surf_image_object( $id, $page_url = '' ) {
	$meta = wp_get_attachment_metadata( $id );
	$url  = wp_get_attachment_url( $id );
	if ( ! $url ) {
		return null;
	}
	$o = array(
		'@type'      => 'ImageObject',
		'@id'        => ( $page_url ? $page_url : home_url( '/' ) ) . '#image-' . $id,
		'url'        => $url,
		'contentUrl' => $url,
	);
	if ( is_array( $meta ) && ! empty( $meta['width'] ) ) {
		$o['width']  = (int) $meta['width'];
		$o['height'] = (int) $meta['height'];
	}
	$alt = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
	if ( $alt ) {
		$o['caption'] = $alt;
	}
	$credit = trim( (string) get_post_meta( $id, '_holo_credit', true ) );
	if ( $credit ) {
		$o['creditText']      = $credit;
		$o['creator']         = array( '@type' => 'Person', 'name' => $credit );
		$o['copyrightNotice'] = '© ' . $credit . ', pour Holo Surf Capbreton';
		$o['copyrightHolder'] = array( '@type' => 'Person', 'name' => $credit );
	}
	return $o;
}

/**
 * Images de la médiathèque présentes dans un contenu, dans l'ordre.
 */
function holo_surf_images_du_contenu( $html ) {
	$up  = wp_get_upload_dir();
	$ids = array();
	if ( preg_match_all( '/<img\b[^>]*\ssrc="([^"]+)"/', $html, $m ) ) {
		foreach ( $m[1] as $src ) {
			if ( 0 !== strpos( $src, $up['baseurl'] ) ) {
				continue;
			}
			$id = holo_surf_id_image( $src );
			if ( $id && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}
	}
	return $ids;
}

/* ------------------------------------------------------------------ Open Graph 1200 × 630 */

/**
 * Image principale d'une page ou d'un article : image à la une, sinon première image du contenu.
 */
function holo_surf_image_principale( $post_id ) {
	$t = (int) get_post_thumbnail_id( $post_id );
	if ( $t ) {
		return $t;
	}
	$post = get_post( $post_id );
	if ( ! $post ) {
		return 0;
	}
	$html = preg_replace_callback(
		'/\{\{img:([0-9a-f]{32})\}\}/',
		function () {
			return '';
		},
		$post->post_content
	);
	$ids = holo_surf_images_du_contenu( $html );
	return $ids ? $ids[0] : (int) get_option( 'holo_surf_og_image' );
}

/**
 * Image Open Graph 1200 × 630 recadrée depuis l'image principale (créée une fois, puis réutilisée).
 * Renvoie [url, largeur, hauteur, id de l'image d'origine] ou null.
 */
function holo_surf_og( $post_id ) {
	$att = holo_surf_image_principale( $post_id );
	if ( ! $att ) {
		return null;
	}
	$cache = get_post_meta( $post_id, '_holo_og', true );
	$up    = wp_get_upload_dir();
	if ( is_array( $cache ) && (int) $cache['att'] === $att && file_exists( trailingslashit( $up['basedir'] ) . $cache['file'] ) ) {
		return array( trailingslashit( $up['baseurl'] ) . $cache['file'], 1200, 630, $att );
	}
	$src = get_attached_file( $att );
	if ( ! $src || ! file_exists( $src ) ) {
		return null;
	}
	$ed = wp_get_image_editor( $src );
	if ( is_wp_error( $ed ) ) {
		return null;
	}
	$s = $ed->get_size();
	$r = 1200 / 630;
	if ( $s['width'] / $s['height'] > $r ) {
		$h = $s['height'];
		$w = (int) round( $h * $r );
		$x = (int) round( ( $s['width'] - $w ) / 2 );
		$y = 0;
	} else {
		$w = $s['width'];
		$h = (int) round( $w / $r );
		$x = 0;
		// Les visages sont le plus souvent dans le haut de l'image : cadrage au tiers supérieur.
		$y = (int) round( ( $s['height'] - $h ) * 0.3 );
	}
	$ed->crop( $x, $y, $w, $h, 1200, 630 );
	$ed->set_quality( 82 );
	$rel  = 'og/og-' . $post_id . '-' . $att . '.jpg';
	$dest = trailingslashit( $up['basedir'] ) . $rel;
	wp_mkdir_p( dirname( $dest ) );
	remove_filter( 'image_editor_output_format', 'holo_surf_format_sortie' ); // l'image Open Graph reste en JPEG
	$res = $ed->save( $dest, 'image/jpeg' );
	add_filter( 'image_editor_output_format', 'holo_surf_format_sortie' );
	if ( is_wp_error( $res ) ) {
		return null;
	}
	update_post_meta( $post_id, '_holo_og', array( 'att' => $att, 'file' => $rel ) );
	return array( trailingslashit( $up['baseurl'] ) . $rel, 1200, 630, $att );
}

/**
 * Identifiant du contenu affiché (accueil, blog ou page/article).
 */
function holo_surf_id_affiche() {
	if ( is_front_page() ) {
		return (int) get_option( 'page_on_front' );
	}
	if ( is_home() ) {
		return (int) get_option( 'page_for_posts' );
	}
	return is_singular() ? (int) get_queried_object_id() : 0;
}

/**
 * L'image Open Graph est recréée quand le contenu change.
 */
add_action(
	'save_post',
	function ( $id ) {
		delete_post_meta( $id, '_holo_og' );
	}
);
