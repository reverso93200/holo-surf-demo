/* Holo Surf : contenus tiers (Windguru, SHOM) chargés seulement à la demande du visiteur. */
(function () {
	'use strict';
	var d = document;
	function windguru(box) {
		var spot = box.getAttribute('data-spot');
		var m = box.getAttribute('data-modele') || '100';
		var mw = box.getAttribute('data-vagues') || '84';
		var uid = 'wg_fwdg_' + spot + '_' + m + '_' + Date.now();
		var holder = d.createElement('div');
		holder.className = 'hs-embed-frame';
		var anchor = d.createElement('script');
		anchor.id = uid;
		holder.appendChild(anchor);
		box.appendChild(holder);
		var args = ['s=' + spot, 'm=' + m, 'mw=' + mw, 'uid=' + uid, 'wj=knots', 'tj=c', 'waj=m', 'tij=cm', 'odh=0', 'doh=24', 'fhours=240', 'hrsm=2', 'vt=forecasts', 'lng=fr', 'idbs=1',
			'p=WINDSPD,GUST,SMER,HTSGW,PERPW,DIRPW,TMPE,CDC,APCP1s'];
		var s = d.createElement('script');
		s.src = 'https://www.windguru.cz/js/widget.php?' + args.join('&');
		s.async = true;
		holder.appendChild(s);
	}
	function shom(box) {
		var port = box.getAttribute('data-port') || 'CAPBRETON';
		var big = box.clientWidth >= 700;
		var f = d.createElement('iframe');
		f.title = 'Horaires des marées du SHOM';
		f.loading = 'lazy';
		f.style.height = (big ? 920 : 370) + 'px';
		f.setAttribute('scrolling', 'no');
		f.srcdoc = '<!doctype html><html><head><meta charset="utf-8"><base target="_blank"><style>body{margin:0}</style></head><body><script src="https://services.data.shom.fr/hdm/vignette/' + (big ? 'grande' : 'petite') + '/' + encodeURIComponent(port) + '?locale=fr"><\/script></body></html>';
		box.appendChild(f);
		var src = d.createElement('p');
		src.className = 'hs-embed-src';
		src.textContent = 'Prédictions officielles du SHOM, service hydrographique et océanographique de la Marine.';
		box.appendChild(src);
	}
	d.querySelectorAll('.hs-embed').forEach(function (box) {
		var btn = box.querySelector('.hs-embed-btn');
		if (!btn) { return; }
		btn.addEventListener('click', function () {
			var ph = box.querySelector('.hs-embed-ph');
			if (ph) { ph.remove(); }
			box.classList.add('is-loaded');
			if (box.getAttribute('data-embed') === 'windguru') { windguru(box); } else { shom(box); }
		});
	});
})();
