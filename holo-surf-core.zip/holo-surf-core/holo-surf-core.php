<?php
/**
 * Plugin Name: Holo Surf Core
 * Plugin URI: https://www.holosurfcapbreton.com/
 * Description: Réglages de l'école (coordonnées, saison, tarifs), formulaire de réservation, données structurées, redirections et installation du site Holo Surf Capbreton.
 * Version: 1.1.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Koino
 * Author URI: https://agence-koino.com
 * License: GPL-2.0-or-later
 * Text Domain: holo-surf-core
 *
 * @package holo-surf-core
 */

defined( 'ABSPATH' ) || exit;

define( 'HOLO_SURF_CORE_VERSION', '1.1.0' );
define( 'HOLO_SURF_CORE_DIR', plugin_dir_path( __FILE__ ) );

require HOLO_SURF_CORE_DIR . 'inc/reglages.php';
require HOLO_SURF_CORE_DIR . 'inc/shortcodes.php';
require HOLO_SURF_CORE_DIR . 'inc/formulaire.php';
require HOLO_SURF_CORE_DIR . 'inc/schema.php';
require HOLO_SURF_CORE_DIR . 'inc/seo.php';
require HOLO_SURF_CORE_DIR . 'inc/admin.php';
require HOLO_SURF_CORE_DIR . 'inc/integrations.php';
require HOLO_SURF_CORE_DIR . 'inc/installation.php';

register_activation_hook( __FILE__, 'holo_surf_activation' );
